package com.smart.android.ad_app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test
import java.io.File

class HaierUserAgentInstallerTest {

    @Test
    fun `installer supports patched aar channels`() {
        assertTrue(HaierUserAgentInstaller.supportsFlavor("hq008"))
        assertTrue(HaierUserAgentInstaller.supportsFlavor("hq008XHSX"))
        assertTrue(HaierUserAgentInstaller.supportsFlavor("tcl_aishang"))
        assertTrue(HaierUserAgentInstaller.supportsFlavor("ad_ytx01"))
        assertTrue(HaierUserAgentInstaller.supportsFlavor("ad_ytx01_sxk"))
        assertTrue(HaierUserAgentInstaller.supportsFlavor("ad_ytx01_jx"))
        assertTrue(HaierUserAgentInstaller.supportsFlavor("ad_album_101_001"))
        assertTrue(HaierUserAgentInstaller.supportsFlavor("hq008Noneu"))
        assertTrue(HaierUserAgentInstaller.supportsFlavor("hq008Noneuc2"))
        assertTrue(HaierUserAgentInstaller.supportsFlavor("tcl_poly"))
        assertTrue(HaierUserAgentInstaller.supportsFlavor("haier_lsap"))
        assertTrue(HaierUserAgentInstaller.supportsFlavor("addy_hq1002"))
        assertTrue(HaierUserAgentInstaller.supportsFlavor("addy_jams"))
        assertTrue(HaierUserAgentInstaller.supportsFlavor("google_ad_tv_desktop"))
        assertTrue(HaierUserAgentInstaller.supportsFlavor("google_ad_tv_desktop_jm"))
        assertTrue(HaierUserAgentInstaller.supportsFlavor("google_ad_tv_desktop_ytx"))
        assertTrue(HaierUserAgentInstaller.supportsFlavor("google_ad_tv_desktop_007"))
        assertTrue(HaierUserAgentInstaller.supportsFlavor("google_ad_tv_desktop_v260904_1"))
        assertTrue(HaierUserAgentInstaller.supportsFlavor("google_ad_tv_desktop_tpmaotai1935"))
        assertTrue(HaierUserAgentInstaller.supportsFlavor("google_ad_tv_lockscreen"))
        assertTrue(HaierUserAgentInstaller.supportsFlavor("google_ad_tv_lockscreen_hq002"))

        assertFalse(HaierUserAgentInstaller.supportsFlavor("unsupported_flavor"))
    }

    @Test
    fun `installer replaces abnormal process user agent for supported flavor`() {
        withRestoredHttpAgent {
            System.setProperty(
                "http.agent",
                "Dalvik/2.1.0 (Linux; U; Android 11.1; TV BOX Build/QP1A.191105.004)"
            )

            val result = HaierUserAgentInstaller.installForProcess(
                flavor = "haier_lsap",
                sdkInt = 30,
                logger = {}
            )

            assertNotNull(result)
            assertTrue(result!!.changed)
            assertEquals(
                "Dalvik/2.1.0 (Linux; U; Android 11; X96_NEXT Build/RP1A.200720.009)",
                System.getProperty("http.agent")
            )
            assertEquals(result, HaierUserAgentInstaller.currentResult())
        }
    }

    @Test
    fun `installer preserves normal process user agent`() {
        withRestoredHttpAgent {
            val original =
                "Dalvik/2.1.0 (Linux; U; Android 11; Sony BRAVIA Build/SONY_11_001)"
            System.setProperty("http.agent", original)

            val result = HaierUserAgentInstaller.installForProcess(
                flavor = "addy_hq1002",
                sdkInt = 30,
                logger = {}
            )

            assertNotNull(result)
            assertFalse(result!!.changed)
            assertEquals(original, System.getProperty("http.agent"))
        }
    }

    @Test
    fun `installer ignores unsupported flavor`() {
        withRestoredHttpAgent {
            val original = "bad"
            System.setProperty("http.agent", original)

            val result = HaierUserAgentInstaller.installForProcess(
                flavor = "unsupported_flavor",
                sdkInt = 30,
                logger = {}
            )

            assertNull(result)
            assertNull(HaierUserAgentInstaller.currentResult())
            assertEquals(original, System.getProperty("http.agent"))
        }
    }

    @Test
    fun `application installs user agent before base context attachment`() {
        val source = readProjectFile("app/src/main/java/com/smart/android/ad_app/APP.kt")
        val methodIndex = source.indexOf("override fun attachBaseContext(base: Context)")
        val installIndex = source.indexOf(
            "HaierUserAgentInstaller.installForCurrentProcess(BuildConfig.FLAVOR)",
            startIndex = methodIndex
        )
        val superIndex = source.indexOf("super.attachBaseContext(base)", startIndex = methodIndex)

        assertTrue("APP 必须实现 attachBaseContext", methodIndex >= 0)
        assertTrue("UA 安装调用必须存在", installIndex > methodIndex)
        assertTrue("UA 安装必须早于 super.attachBaseContext", installIndex < superIndex)
    }

    private fun withRestoredHttpAgent(block: () -> Unit) {
        val previous = System.getProperty("http.agent")
        try {
            block()
        } finally {
            if (previous == null) {
                System.clearProperty("http.agent")
            } else {
                System.setProperty("http.agent", previous)
            }
        }
    }

    private fun readProjectFile(relativePath: String): String {
        val workingDir = File(System.getProperty("user.dir") ?: ".")
        val projectRoot = generateSequence(workingDir) { it.parentFile }
            .firstOrNull { File(it, relativePath).exists() }
        if (projectRoot == null) {
            fail("无法定位项目根目录: ${workingDir.absolutePath}")
        }
        return File(projectRoot, relativePath).readText()
    }
}
