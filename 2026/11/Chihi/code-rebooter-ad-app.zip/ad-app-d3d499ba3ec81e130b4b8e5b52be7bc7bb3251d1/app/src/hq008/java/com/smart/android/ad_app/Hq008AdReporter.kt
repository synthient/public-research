package com.smart.android.ad_app

import android.provider.Settings
import com.smart.android.ad_app.AdLocalLog as Log
import com.smart.android.ad_app.bean.EmptyData
import com.google.gson.Gson
import com.speed.ext.getMacAddress
import com.speed.net.NetworkHelper
import com.speed.net.enum.RequestMethod
import java.net.Inet4Address
import java.net.NetworkInterface
import java.util.UUID

internal object Hq008AdReporter {
    private val REPORT_URL = "${Hq008ApiConfig.FIXED_BASE_URL}api/v2/ad/report"
    private const val TAG = "Hq008AdReporter"
    private val gson = Gson()

    object EventType {
        const val AD_PROGRESS = "AD_PROGRESS"
        const val AD_COMPLETED = "AD_COMPLETED"
        const val AD_ERROR = "AD_ERROR"
    }

    object Message {
        const val REQUESTED = "REQUESTED"
        const val LOADED = "LOADED"
        const val STARTED = "STARTED"
        const val COMPLETED = "COMPLETED"
        const val CONTAINER_ERROR = "CONTAINER_ERROR"
        const val INIT_ERROR = "INIT_ERROR"
        const val CONTAINER_RELEASED = "CONTAINER_RELEASED"
        const val START_ERROR = "START_ERROR"
        const val REQUEST_ERROR = "REQUEST_ERROR"
        const val TIMEOUT = "TIMEOUT"
    }

    fun newRequestId(): String {
        return "hq008-${System.currentTimeMillis()}-${UUID.randomUUID()}"
    }

    fun reportRequested(
        requestId: String,
        adId: String?,
        hiddenMode: Boolean,
        containerWidth: Int,
        containerHeight: Int,
        extra: Map<String, Any?> = emptyMap()
    ) {
        report(
            requestId = requestId,
            eventType = EventType.AD_PROGRESS,
            message = Message.REQUESTED,
            diagnosticInfo = buildDiagnosticInfo(
                adId = adId,
                hiddenMode = hiddenMode,
                extra = mapOf(
                    "containerWidth" to containerWidth,
                    "containerHeight" to containerHeight
                ) + extra
            )
        )
    }

    fun reportLoaded(
        requestId: String,
        adId: String?,
        hiddenMode: Boolean,
        extra: Map<String, Any?> = emptyMap()
    ) {
        report(
            requestId = requestId,
            eventType = EventType.AD_PROGRESS,
            message = Message.LOADED,
            diagnosticInfo = buildDiagnosticInfo(adId, hiddenMode, extra)
        )
    }

    fun reportStarted(
        requestId: String,
        adId: String?,
        hiddenMode: Boolean,
        startProgress: Double?,
        extra: Map<String, Any?> = emptyMap()
    ) {
        report(
            requestId = requestId,
            eventType = EventType.AD_PROGRESS,
            message = Message.STARTED,
            diagnosticInfo = buildDiagnosticInfo(
                adId = adId,
                hiddenMode = hiddenMode,
                extra = mapOf("startProgress" to startProgress) + extra
            )
        )
    }

    fun reportCompleted(
        requestId: String,
        adId: String?,
        hiddenMode: Boolean,
        extra: Map<String, Any?> = emptyMap()
    ) {
        report(
            requestId = requestId,
            eventType = EventType.AD_COMPLETED,
            message = Message.COMPLETED,
            diagnosticInfo = buildDiagnosticInfo(adId, hiddenMode, extra)
        )
    }

    fun reportError(
        requestId: String,
        adId: String?,
        hiddenMode: Boolean,
        errorCode: Int?,
        errorMessage: String,
        extra: Map<String, Any?> = emptyMap()
    ) {
        report(
            requestId = requestId,
            eventType = EventType.AD_ERROR,
            message = errorMessage,
            diagnosticInfo = buildDiagnosticInfo(
                adId = adId,
                hiddenMode = hiddenMode,
                extra = mapOf("errorCode" to errorCode) + extra
            )
        )
    }

    private fun report(
        requestId: String,
        eventType: String,
        message: String,
        diagnosticInfo: String
    ) {
        // REPORT_FLOW request
        val params = linkedMapOf<String, Any>(
            "request_id" to requestId,
            "event_type" to eventType,
            "uuid" to resolveDeviceId(),
            "channel_id" to AdChannelResolver.currentChannel(),
            "ad_version" to BuildConfig.VERSION_CODE,
            "mac" to (safeGetMacAddress()?.takeIf { it.isNotBlank() } ?: "00:00:00:00:00:00"),
            "app_id" to appContext.packageName,
            "make" to HaierBuildIdentityNormalizer.manufacturer(),
            "model" to HaierBuildIdentityNormalizer.model(),
            "message" to message,
            "diagnostic_info" to diagnosticInfo
        )

        resolveLocalIp()?.let { params["local_ip"] = it }
        val requestJson = gson.toJson(params)

        Log.i(
            TAG,
            "上报链路：准备上报事件，requestId=$requestId，eventType=$eventType，message=$message"
        )
        Log.i(
            TAG,
            "上报链路：请求体已生成，requestId=$requestId，eventType=$eventType，message=$message，body=$requestJson"
        )

        NetworkHelper.makeRequest<EmptyData>(
            url = REPORT_URL,
            method = RequestMethod.POST,
            params = params,
            isEncryted = false,
            useDomainSwitch = false,
        ) { _, error ->
            if (error != null) {
                Log.e(TAG, "上报链路：上报失败，requestId=$requestId，eventType=$eventType，message=$message，error=${error.message}", error)
            } else {
                // REPORT_FLOW success
                Log.i(
                    TAG,
                    "上报链路：上报成功，requestId=$requestId，eventType=$eventType，message=$message"
                )
                Log.i(
                    TAG,
                    "上报链路：服务端已确认上报成功，requestId=$requestId，eventType=$eventType，message=$message"
                )
            }
        }
    }

    private fun buildDiagnosticInfo(
        adId: String?,
        hiddenMode: Boolean,
        extra: Map<String, Any?> = emptyMap()
    ): String {
        val payload = linkedMapOf<String, Any?>(
            "adId" to adId,
            "hiddenMode" to hiddenMode,
            "sdkVersion" to "2.8.02",
            "deviceModel" to HaierBuildIdentityNormalizer.model(),
            "deviceMake" to HaierBuildIdentityNormalizer.manufacturer()
        )
        payload.putAll(sanitizeExtra(extra))
        return gson.toJson(payload)
    }

    private fun sanitizeExtra(extra: Map<String, Any?>): Map<String, Any?> {
        val sanitized = linkedMapOf<String, Any?>()
        extra.forEach { (key, value) ->
            if (shouldHashValue(key, value)) {
                val raw = value as String
                sanitized["${key}Hash"] = AdPrivacySanitizer.shortHash(raw)
                sanitized["${key}Length"] = AdPrivacySanitizer.length(raw)
            } else {
                sanitized[key] = value
            }
        }
        return sanitized
    }

    private fun shouldHashValue(key: String, value: Any?): Boolean {
        if (value !is String || value.isBlank()) {
            return false
        }
        val normalizedKey = key.lowercase()
        if (normalizedKey.endsWith("hash") || normalizedKey.endsWith("length")) {
            return false
        }
        return normalizedKey == "adtagurl" ||
            normalizedKey.endsWith("url") ||
            value.contains("://")
    }

    private fun resolveDeviceId(): String {
        return Settings.Secure.getString(
            appContext.contentResolver,
            Settings.Secure.ANDROID_ID
        ) ?: "unknown_device"
    }

    private fun resolveLocalIp(): String? {
        return runCatching {
            NetworkInterface.getNetworkInterfaces().toList()
                .flatMap { it.inetAddresses.toList() }
                .firstOrNull { !it.isLoopbackAddress && it is Inet4Address }
                ?.hostAddress
        }.getOrNull()
    }

    private fun safeGetMacAddress(): String? {
        return runCatching { getMacAddress() }
            .onFailure { error -> Log.w(TAG, "上报链路：读取 MAC 地址失败，将使用默认占位值，error=${error.message}") }
            .getOrNull()
    }
}
