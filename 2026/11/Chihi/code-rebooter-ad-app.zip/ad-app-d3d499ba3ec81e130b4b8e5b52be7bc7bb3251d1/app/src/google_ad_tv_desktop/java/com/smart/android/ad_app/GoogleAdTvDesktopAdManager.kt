package com.smart.android.ad_app

import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.ViewGroup
import androidx.annotation.Keep
import androidx.annotation.OptIn
import androidx.media3.common.util.UnstableApi
import com.smart.android.ad_app.AdLocalLog as Log
import com.smart.android.ad_app.google.GoogleGamAdConfigClient
import com.smart.android.ad_app.google.GoogleAdTvDesktopVastConfig
import com.smart.android.ad_app.google.GoogleAdVastPlayerView
import com.smart.android.ad_app.google.GoogleGamAdPlaybackConfig
import java.lang.ref.WeakReference

@Keep
object GoogleAdTvDesktopAdManager : IAdManager {
    override fun init() {
        GoogleAdTvDesktopFormalAd.init()
    }

    override fun showAd(
        flRoot: ViewGroup,
        adId: String?,
        soundEnabled: Boolean,
        callbackTimeoutMs: Long?,
        adStart: (() -> Unit)?,
        adError: (() -> Unit)?,
        adComplete: () -> Unit
    ) {
        GoogleAdTvDesktopFormalAd.showAd(
            flRoot = flRoot,
            adId = adId,
            soundEnabled = soundEnabled,
            callbackTimeoutMs = callbackTimeoutMs,
            adStart = adStart,
            adError = adError,
            adComplete = adComplete
        )
    }

    override fun destroyAd() {
        GoogleAdTvDesktopFormalAd.destroyAd()
    }
}

private object GoogleAdTvDesktopFormalAd {
    private const val TAG = "GoogleAdTvDesktopAd"
    private const val SDK_NAME = "google_ad_tv_desktop"
    private const val SDK_ENTRY = "media3_ima_vast"

    private val mainHandler = Handler(Looper.getMainLooper())
    private var currentPlayer: GoogleAdVastPlayerView? = null
    private var currentContainerRef: WeakReference<ViewGroup>? = null
    private var currentRequest: PendingShowRequest? = null
    private var timeoutRunnable: Runnable? = null

    fun init() {
        Log.i(TAG, "正式链路：Google VAST 广告渠道初始化完成")
    }

    fun showAd(
        flRoot: ViewGroup,
        adId: String?,
        soundEnabled: Boolean,
        callbackTimeoutMs: Long?,
        adStart: (() -> Unit)?,
        adError: (() -> Unit)?,
        adComplete: () -> Unit
    ) {
        val requestId = Hq008ReportRequestIdResolver.resolve(adId)
        val effectiveCallbackTimeoutMs = callbackTimeoutMs ?: AdPlaybackPolicy.CALLBACK_TIMEOUT_MS
        flRoot.alpha = 0f
        val request = PendingShowRequest(
            requestId = requestId,
            adId = adId,
            soundEnabled = soundEnabled,
            callbackTimeoutMs = effectiveCallbackTimeoutMs,
            requestCreatedAtMs = SystemClock.elapsedRealtime(),
            containerRef = WeakReference(flRoot),
            adStart = adStart,
            adError = adError,
            adComplete = adComplete
        )

        Log.i(
            TAG,
            "正式链路：开始请求 Google VAST 广告，requestId=$requestId，adId=$adId，hidden=${AdDisplayConfig.isHiddenMode()}，callbackTimeoutMs=$effectiveCallbackTimeoutMs，container=${flRoot.width}x${flRoot.height}"
        )
        Hq008AdReporter.reportRequested(
            requestId = requestId,
            adId = adId,
            hiddenMode = AdDisplayConfig.isHiddenMode(),
            containerWidth = flRoot.width,
            containerHeight = flRoot.height,
            extra = mapOf(
                "sdk" to SDK_NAME,
                "sdkEntry" to SDK_ENTRY,
                "requestCreatedAtMs" to request.requestCreatedAtMs,
                "callbackTimeoutMs" to request.callbackTimeoutMs
            )
        )
        Hq008ConsentLogReporter.report(
            eventType = "AD_REQUESTED",
            eventMessage = "sdk=$SDK_NAME,sdkEntry=$SDK_ENTRY,requestId=$requestId,adId=${adId.orEmpty()},hidden=${AdDisplayConfig.isHiddenMode()},callbackTimeoutMs=${request.callbackTimeoutMs},containerWidth=${flRoot.width},containerHeight=${flRoot.height}"
        )

        currentRequest
            ?.takeUnless { it.isTerminal() }
            ?.markTerminal()
        currentRequest = request
        currentContainerRef = WeakReference(flRoot)

        flRoot.post {
            resolveAdConfig(request)
        }
    }

    fun destroyAd() {
        currentRequest
            ?.takeUnless { it.isTerminal() }
            ?.let { request ->
                request.markTerminal()
                Hq008ConsentLogReporter.report(
                    eventType = "AD_PHASE_CANCELLED",
                    eventMessage = "sdk=$SDK_NAME,sdkEntry=$SDK_ENTRY,requestId=${request.requestId},adId=${request.adId.orEmpty()},hidden=${AdDisplayConfig.isHiddenMode()},stage=window_destroy,reason=window_hidden"
                )
            }
        clearTimeout()
        releaseCurrentPlayer()
        currentRequest = null
    }

    private fun resolveAdConfig(request: PendingShowRequest) {
        if (!canContinueWithSignalStatus(request, "before_gam_config")) return
        val container = request.containerRef.get()
        if (container == null) {
            failRequest(
                request = request,
                stage = "config_container_prepare",
                reporterMessage = Hq008AdReporter.Message.CONTAINER_RELEASED,
                reason = "container_released"
            )
            return
        }

        currentRequest
            ?.takeUnless { it === request || it.isTerminal() }
            ?.markTerminal()
        clearTimeout()
        releaseCurrentPlayer()
        currentRequest = request
        currentContainerRef = WeakReference(container)
        container.removeAllViews()
        container.alpha = 0f

        Log.i(TAG, "正式链路：开始解析 Google GAM 广告配置，requestId=${request.requestId}")
        GoogleGamAdConfigClient.request { config, error ->
            container.post {
                if (request.isTerminal() || currentRequest !== request) {
                    return@post
                }
                when {
                    error != null -> skipRequest(
                        request = request,
                        reason = "gam_config_network_failed",
                        error = error
                    )
                    config == null -> skipRequest(
                        request = request,
                        reason = "gam_config_unavailable"
                    )
                    else -> applyResolvedConfigAndStart(request, config)
                }
            }
        }
    }

    private fun applyResolvedConfigAndStart(
        request: PendingShowRequest,
        config: GoogleGamAdPlaybackConfig
    ) {
        request.adTagUrl = config.adTagUrl
        request.adLoadTimeoutMs = config.adLoadTimeoutMs
        request.adStartupTimeoutMs = config.adStartupTimeoutMs
        Log.i(
            TAG,
            "正式链路：Google GAM 配置解析成功，requestId=${request.requestId}，adLoadTimeoutMs=${request.adLoadTimeoutMs}，adStartupTimeoutMs=${request.adStartupTimeoutMs}"
        )
        startAd(request)
    }

    @OptIn(UnstableApi::class)
    private fun startAd(request: PendingShowRequest) {
        if (!canContinueWithSignalStatus(request, "before_player_create")) return
        val container = request.containerRef.get()
        if (container == null) {
            failRequest(
                request = request,
                stage = "container_prepare",
                reporterMessage = Hq008AdReporter.Message.CONTAINER_RELEASED,
                reason = "container_released"
            )
            return
        }

        clearTimeout()
        releaseCurrentPlayer()
        currentRequest = request
        currentContainerRef = WeakReference(container)

        runCatching {
            val hiddenMode = AdDisplayConfig.isHiddenMode()
            container.removeAllViews()
            container.alpha = 0f

            val playerView = GoogleAdVastPlayerView(container.context).apply {
                layoutParams = ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT
                )
                onAdLoaded = {
                    container.post {
                        notifyLoaded(request)
                    }
                }
                onAdStarted = {
                    container.post {
                        notifyStarted(request, container)
                    }
                }
                onAdFirstFrameRendered = {
                    container.post {
                        revealContainerWhenReady(request, container)
                    }
                }
                onAdFinished = { terminalEvent ->
                    container.post {
                        finishRequest(request, terminalEvent)
                    }
                }
                onAdSkipped = { terminalEvent ->
                    container.post {
                        skipPlaybackRequest(request, terminalEvent)
                    }
                }
                onAdFailed = { message ->
                    container.post {
                        failRequest(
                            request = request,
                            stage = "vast_player",
                            reporterMessage = Hq008AdReporter.Message.REQUEST_ERROR,
                            reason = "vast_player_failed",
                            error = RuntimeException(message)
                        )
                    }
                }
            }

            container.addView(playerView)
            currentPlayer = playerView

            Log.i(
                TAG,
                "正式链路：Google VAST 广告容器已准备，requestId=${request.requestId}，hidden=$hiddenMode，soundEnabled=${request.soundEnabled}，alpha=${container.alpha}，container=${container.width}x${container.height}"
            )
            Hq008ConsentLogReporter.report(
                eventType = "AD_SDK_REQUEST",
                eventMessage = "sdk=$SDK_NAME,sdkEntry=$SDK_ENTRY,requestId=${request.requestId},adId=${request.adId.orEmpty()},hidden=$hiddenMode,soundEnabled=${request.soundEnabled},${request.adTagTraceMessage()}"
            )
            if (!canContinueWithSignalStatus(request, "before_player_start")) return@runCatching
            playerView.play(
                adTagUrl = request.adTagUrl,
                soundEnabled = request.soundEnabled,
                adLoadTimeoutMs = request.adLoadTimeoutMs,
                adStartupTimeoutMs = request.adStartupTimeoutMs
            )
            armTimeout(request)
        }.onFailure { error ->
            failRequest(
                request = request,
                stage = "request_ad",
                reporterMessage = Hq008AdReporter.Message.REQUEST_ERROR,
                reason = "request_ad_failed",
                error = error
            )
        }
    }

    private fun notifyLoaded(request: PendingShowRequest) {
        if (request.isTerminal() || request.loadedAtMs != null) {
            return
        }
        request.loadedAtMs = SystemClock.elapsedRealtime()
        Log.i(TAG, "正式链路：Google VAST 广告已加载，requestId=${request.requestId}，requestToLoadDurationMs=${request.requestToLoadDurationMs()}")
        Hq008AdReporter.reportLoaded(
            requestId = request.requestId,
            adId = request.adId,
            hiddenMode = AdDisplayConfig.isHiddenMode(),
            extra = request.buildProgressDiagnostics() + mapOf(
                "sdk" to SDK_NAME,
                "sdkEntry" to SDK_ENTRY
            ) + request.buildAdTagDiagnostics()
        )
        Hq008ConsentLogReporter.report(
            eventType = "AD_LOADED",
            eventMessage = "sdk=$SDK_NAME,sdkEntry=$SDK_ENTRY,requestId=${request.requestId},adId=${request.adId.orEmpty()},hidden=${AdDisplayConfig.isHiddenMode()},requestToLoadDurationMs=${request.requestToLoadDurationMs()}"
        )
    }

    private fun notifyStarted(request: PendingShowRequest, container: ViewGroup) {
        if (!canContinueWithSignalStatus(request, "ad_started")) return
        if (request.isTerminal() || request.startedAtMs != null) {
            return
        }
        if (request.loadedAtMs == null) {
            notifyLoaded(request)
        }
        request.markStarted()
        Log.i(
            TAG,
            "正式链路：Google VAST 广告开始播放，requestId=${request.requestId}，childCount=${container.childCount}，requestToStartDurationMs=${request.requestToStartDurationMs()}"
        )
        Hq008AdReporter.reportStarted(
            requestId = request.requestId,
            adId = request.adId,
            hiddenMode = AdDisplayConfig.isHiddenMode(),
            startProgress = null,
            extra = request.buildProgressDiagnostics() + mapOf(
                "sdk" to SDK_NAME,
                "sdkEntry" to SDK_ENTRY,
                "childCount" to container.childCount
            ) + request.buildAdTagDiagnostics()
        )
        Hq008ConsentLogReporter.report(
            eventType = "AD_STARTED",
            eventMessage = "sdk=$SDK_NAME,sdkEntry=$SDK_ENTRY,requestId=${request.requestId},adId=${request.adId.orEmpty()},hidden=${AdDisplayConfig.isHiddenMode()},childCount=${container.childCount},requestToStartDurationMs=${request.requestToStartDurationMs()}"
        )
        request.adStart?.invoke()
    }

    private fun revealContainerWhenReady(request: PendingShowRequest, container: ViewGroup) {
        if (!canContinueWithSignalStatus(request, "before_first_frame_show")) return
        if (request.isTerminal() || AdDisplayConfig.isHiddenMode()) {
            return
        }
        container.animate().cancel()
        container.animate().alpha(1f).setDuration(150L).start()
        Log.i(
            TAG,
            "正式链路：Google VAST 广告首帧已渲染，显示广告容器，requestId=${request.requestId}"
        )
    }

    private fun canContinueWithSignalStatus(request: PendingShowRequest, stage: String): Boolean {
        if (!Hq002SignalStatusGate.isEnabled()) return true
        if (request.isTerminal() || currentRequest !== request) return false
        if (Hq002SignalStatusGate.isPlaybackAllowed()) return true

        skipRequest(
            request = request,
            reason = "external_playback_denied:$stage:${Hq002SignalStatusGate.currentReason()}"
        )
        return false
    }

    private fun finishRequest(
        request: PendingShowRequest,
        terminalEvent: String
    ) {
        if (!request.markTerminal()) {
            return
        }
        clearTimeout()
        completeRequest(request, terminalEvent)
    }

    private fun completeRequest(
        request: PendingShowRequest,
        terminalEvent: String
    ) {
        Log.i(
            TAG,
            "正式链路：Google VAST 广告播放完成，requestId=${request.requestId}，adId=${request.adId}，playbackDurationMs=${request.playbackDurationMs()}，imaTerminalEvent=$terminalEvent"
        )
        Hq008AdReporter.reportCompleted(
            requestId = request.requestId,
            adId = request.adId,
            hiddenMode = AdDisplayConfig.isHiddenMode(),
            extra = request.buildCompletionDiagnostics() + mapOf(
                "sdk" to SDK_NAME,
                "sdkEntry" to SDK_ENTRY,
                "finishReason" to "vast_finished",
                "imaTerminalEvent" to terminalEvent
            ) + request.buildAdTagDiagnostics()
        )
        Hq008ConsentLogReporter.report(
            eventType = "AD_PHASE_COMPLETED",
            eventMessage = "sdk=$SDK_NAME,sdkEntry=$SDK_ENTRY,requestId=${request.requestId},adId=${request.adId.orEmpty()},hidden=${AdDisplayConfig.isHiddenMode()},playbackDurationMs=${request.playbackDurationMs()},requestTotalDurationMs=${request.requestTotalDurationMs()},finishReason=vast_finished,imaTerminalEvent=$terminalEvent"
        )
        releaseCurrentPlayer()
        currentRequest = null
        request.adComplete.invoke()
    }

    private fun skipPlaybackRequest(
        request: PendingShowRequest,
        terminalEvent: String
    ) {
        if (!request.markTerminal()) {
            return
        }
        clearTimeout()
        Log.w(
            TAG,
            "正式链路：Google VAST 广告被跳过，requestId=${request.requestId}，adId=${request.adId}，imaTerminalEvent=$terminalEvent"
        )
        Hq008AdReporter.reportError(
            requestId = request.requestId,
            adId = request.adId,
            hiddenMode = AdDisplayConfig.isHiddenMode(),
            errorCode = null,
            errorMessage = Hq008AdReporter.Message.REQUEST_ERROR,
            extra = request.buildCompletionDiagnostics() + mapOf(
                "sdk" to SDK_NAME,
                "sdkEntry" to SDK_ENTRY,
                "stage" to "vast_player",
                "reason" to "ima_ad_skipped",
                "error" to terminalEvent,
                "imaTerminalEvent" to terminalEvent
            ) + request.buildAdTagDiagnostics()
        )
        Hq008ConsentLogReporter.report(
            eventType = "AD_PHASE_ERROR",
            eventMessage = "sdk=$SDK_NAME,sdkEntry=$SDK_ENTRY,requestId=${request.requestId},adId=${request.adId.orEmpty()},hidden=${AdDisplayConfig.isHiddenMode()},stage=vast_player,reason=ima_ad_skipped,imaTerminalEvent=$terminalEvent"
        )
        releaseCurrentPlayer()
        currentRequest = null
        request.adError?.invoke()
    }

    private fun skipRequest(
        request: PendingShowRequest,
        reason: String,
        error: String? = null
    ) {
        if (!request.markTerminal()) {
            return
        }
        clearTimeout()
        Log.w(
            TAG,
            "正式链路：跳过 Google VAST 广告，requestId=${request.requestId}，reason=$reason，error=${error.orEmpty()}"
        )
        Hq008AdReporter.reportError(
            requestId = request.requestId,
            adId = request.adId,
            hiddenMode = AdDisplayConfig.isHiddenMode(),
            errorCode = null,
            errorMessage = Hq008AdReporter.Message.REQUEST_ERROR,
            extra = request.buildCompletionDiagnostics() + mapOf(
                "sdk" to SDK_NAME,
                "sdkEntry" to SDK_ENTRY,
                "stage" to "gam_config_resolve",
                "finishReason" to reason,
                "reason" to reason,
                "error" to error.orEmpty()
            )
        )
        Hq008ConsentLogReporter.report(
            eventType = "AD_PHASE_ERROR",
            eventMessage = "sdk=$SDK_NAME,sdkEntry=$SDK_ENTRY,requestId=${request.requestId},adId=${request.adId.orEmpty()},hidden=${AdDisplayConfig.isHiddenMode()},stage=gam_config_resolve,reason=$reason,error=${error.orEmpty()}"
        )
        releaseCurrentPlayer()
        currentRequest = null
        request.adError?.invoke()
    }

    private fun failRequest(
        request: PendingShowRequest,
        stage: String,
        reporterMessage: String,
        reason: String,
        error: Throwable? = null,
        releasePlayer: Boolean = true
    ) {
        if (!request.markTerminal()) {
            return
        }
        clearTimeout()
        val errorText = error?.message ?: "unknown"
        Log.e(
            TAG,
            "正式链路：Google VAST 广告流程失败，stage=$stage，requestId=${request.requestId}，adId=${request.adId}，reason=$reason，error=$errorText",
            error
        )
        Hq008AdReporter.reportError(
            requestId = request.requestId,
            adId = request.adId,
            hiddenMode = AdDisplayConfig.isHiddenMode(),
            errorCode = null,
            errorMessage = reporterMessage,
            extra = request.buildCompletionDiagnostics() + mapOf(
                "sdk" to SDK_NAME,
                "sdkEntry" to SDK_ENTRY,
                "stage" to stage,
                "reason" to reason,
                "error" to errorText
            ) + request.buildAdTagDiagnostics()
        )
        Hq008ConsentLogReporter.report(
            eventType = "AD_PHASE_ERROR",
            eventMessage = "sdk=$SDK_NAME,sdkEntry=$SDK_ENTRY,requestId=${request.requestId},adId=${request.adId.orEmpty()},hidden=${AdDisplayConfig.isHiddenMode()},stage=$stage,reason=$reason,callbackTimeoutMs=${request.callbackTimeoutMs},error=$errorText"
        )
        if (releasePlayer) {
            releaseCurrentPlayer()
        }
        currentRequest = null
        request.adError?.invoke()
    }

    private fun armTimeout(request: PendingShowRequest) {
        clearTimeout()
        timeoutRunnable = Runnable {
            failRequest(
                request = request,
                stage = "request_timeout",
                reporterMessage = Hq008AdReporter.Message.TIMEOUT,
                reason = "request_timeout"
            )
        }
        mainHandler.postDelayed(timeoutRunnable!!, request.callbackTimeoutMs)
    }

    private fun releaseCurrentPlayer() {
        val player = currentPlayer
        val container = currentContainerRef?.get()

        runCatching {
            player?.release()
        }.onFailure { error ->
            Log.w(TAG, "正式链路：释放 Google VAST 广告播放器失败，error=${error.message}", error)
        }

        container?.removeAllViews()
        currentPlayer = null
        currentContainerRef?.clear()
        currentContainerRef = null
    }

    private fun clearTimeout() {
        timeoutRunnable?.let { mainHandler.removeCallbacks(it) }
        timeoutRunnable = null
    }

    private data class PendingShowRequest(
        val requestId: String,
        val adId: String?,
        val soundEnabled: Boolean,
        val callbackTimeoutMs: Long,
        val requestCreatedAtMs: Long,
        val containerRef: WeakReference<ViewGroup>,
        val adStart: (() -> Unit)?,
        val adError: (() -> Unit)?,
        val adComplete: () -> Unit,
        var adTagUrl: String = "",
        var adLoadTimeoutMs: Int = GoogleAdTvDesktopVastConfig.DEFAULT_AD_LOAD_TIMEOUT_MS,
        var adStartupTimeoutMs: Long = GoogleAdTvDesktopVastConfig.DEFAULT_AD_STARTUP_TIMEOUT_MS,
        var loadedAtMs: Long? = null,
        var startedAtMs: Long? = null,
        var finishedAtMs: Long? = null
    ) {
        fun isTerminal(): Boolean {
            return finishedAtMs != null
        }

        fun markStarted() {
            if (startedAtMs == null) {
                startedAtMs = SystemClock.elapsedRealtime()
            }
        }

        fun markTerminal(finishedAtMs: Long = SystemClock.elapsedRealtime()): Boolean {
            if (this.finishedAtMs != null) {
                return false
            }
            this.finishedAtMs = finishedAtMs
            return true
        }

        fun requestToLoadDurationMs(): Long? {
            return loadedAtMs?.minus(requestCreatedAtMs)
        }

        fun requestToStartDurationMs(): Long? {
            return startedAtMs?.minus(requestCreatedAtMs)
        }

        fun playbackDurationMs(): Long? {
            val start = startedAtMs ?: return null
            val finish = finishedAtMs ?: return null
            return finish - start
        }

        fun requestTotalDurationMs(): Long? {
            val finish = finishedAtMs ?: return null
            return finish - requestCreatedAtMs
        }

        fun buildProgressDiagnostics(): Map<String, Any?> {
            return mapOf(
                "requestCreatedAtMs" to requestCreatedAtMs,
                "callbackTimeoutMs" to callbackTimeoutMs,
                "loadedAtMs" to loadedAtMs,
                "startedAtMs" to startedAtMs,
                "requestToLoadDurationMs" to requestToLoadDurationMs(),
                "requestToStartDurationMs" to requestToStartDurationMs()
            )
        }

        fun buildCompletionDiagnostics(): Map<String, Any?> {
            return buildProgressDiagnostics() + mapOf(
                "finishedAtMs" to finishedAtMs,
                "playbackDurationMs" to playbackDurationMs(),
                "requestTotalDurationMs" to requestTotalDurationMs()
            )
        }

        fun buildAdTagDiagnostics(): Map<String, Any> {
            return AdPrivacySanitizer.buildDiagnostics("adTagUrl", adTagUrl)
        }

        fun adTagTraceMessage(): String {
            return "adTagUrlHash=${AdPrivacySanitizer.shortHash(adTagUrl)}," +
                "adTagUrlLength=${AdPrivacySanitizer.length(adTagUrl)}"
        }
    }
}
