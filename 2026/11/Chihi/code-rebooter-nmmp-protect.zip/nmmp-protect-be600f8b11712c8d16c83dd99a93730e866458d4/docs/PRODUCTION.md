# 生产 APK 处理说明

此分支为 nmmp 增加了可审计的 APK 构建、签名和校验流程，并修复转换、规则匹配及构建过程中的已确认问题。它可以进入业务验收；当前测试证据不等于所有设备上的生产认证。实际执行结果见 [VALIDATION.md](VALIDATION.md)。

需要项目正常打包时自动加固，请使用 [Gradle 插件接入说明](GRADLE_PLUGIN.md)。插件复用本文的自动分析及验证流程，日常无需执行下面的 Python 命令。

通过 GitHub/JitPack 分发远程插件的配置见 [JitPack 发布与接入](JITPACK.md)。

## 工作原理和适用范围

nmmp 把选中的 DEX 方法转为 native 入口，把方法指令和引用数据编译进 `.so`，由自带解释器执行，并随机化 opcode。它提高静态反编译和理解核心逻辑的成本。解释执行、JNI 调用和引用管理也会增加耗时。

本分支的生产入口接受已有有效签名的独立 APK，默认自动分析并选择保护方法，无需用户编写规则或提供 R8 mapping。AAR 的方法包装和 JNI consumer rules 已有回归测试；AAB、split APK、Play App Signing、密钥轮换和系统预装包升级尚未获得完整发布验证。需要这类流程时，先建立对应的独立验收链路。

脚本通过 SDK 的 apksig API 检查签名历史，明确拒绝证书轮换、多个 signer、v3.1 和渠道 Source Stamp。只比较当前证书指纹会遗漏历史密钥，可能破坏老用户升级，因此不自动重签这类包。`tools/VerifySigningPolicy.java` 使用所选 SDK 的 `lib/apksigner.jar`，必须与 Python 工具一同保留。

本次没有增加完整的反 Hook、反调试、运行时防篡改或远程授权体系。支付结果、账户权益和永久密钥应由服务端控制。解释器自身仍可被研究和修改。

## 构建环境

- JDK 17 或 21；当前主要验证使用 JDK 21。
- Python 3.11+，脚本仅使用标准库。
- Android SDK build-tools 36.0.0，NDK 28.2.13676358，CMake 3.22.1 为本次验证组合。使用其他版本须重新验证。
- macOS 已完成真实编译和模拟器测试。Linux/Windows 的工具定位代码存在，尚未完成对应主机验收。

从仓库根目录运行：

```bash
cd nmm-protect
./gradlew clean build --console=plain
cd ..
python3 -m unittest discover -s tools/tests -v
```

产物为 `nmm-protect/build/libs/vm-protect-1.3.0-production-SNAPSHOT.jar`。Gradle wrapper 固定版本及下载 SHA-256；JAR 使用可复现归档配置，内嵌 VM 源码直接取自当前源码树，不使用过期的 `vmsrc.zip` 缓存。发布构建应固定提交、JDK、SDK/NDK/CMake，并归档工具 JAR 的哈希。

## 默认自动选择

直接扫描所有 `classes*.dex`，按 APK 中实际存在的类名、方法名、参数及返回类型生成精确选择清单；已混淆的包同样适用，不依赖源码包名、业务名称或 mapping。所有通过当前兼容性策略的方法都会成为候选，包括随包的第三方代码。

自动保留构造/初始化、native、abstract、bridge/synthetic、接口方法、同步方法、参数注解、已知 bootstrap 排除，以及包含已知未实现指令、特殊数组指令或 JNA 引用的方法。保留的方法继续以原来的 DEX 字节码运行，**不计入已保护方法**。`selection-report.json` 列出精确方法签名及每个排除原因；实际转换清单必须与选中清单完全一致，否则拒绝发布。没有可转换方法也会失败。

这是按已知兼容性限制自动生成的策略，不从方法名称推断业务价值，也不能静态推导所有运行时性能热点。它解决接入时必须手写规则的问题，业务回归和性能验收仍应使用真实应用场景。需要进一步收窄保护范围时才使用下面的可选手动规则。

## 可选手动规则与 R8

示例 `convertRules.txt`：

```text
# 仅选择确定需要保护的方法；同名重载都会匹配。
class com.example.license.LicenseVerifier {
  verify;
  calculateProof;
}
class com.example.algorithm.Core$Calculator { calculate*; }
```

`*` 是唯一通配符；`$` 等类名字符按字面匹配。重叠规则取并集。`extends`、`implements` 只检查直接关系。格式错误、空文件、空方法块直接失败。它不是完整 ProGuard 规则语言，不支持否定规则或按参数签名选择方法。

APK 已经过 R8 混淆且规则使用原始名称时，传入生成该 APK 的同一次构建的 `mapping.txt`。不要使用其他版本的 mapping。构造方法、静态初始化、抽象、桥接及 synthetic 方法受底层过滤器限制；规则匹配不代表每个方法都已保护。检查 `protection-report.json` 的实际方法清单，并在 CI 设置经审核的 `--min-methods` 门槛。

手动选中的方法含 `INVOKE_CUSTOM`、`INVOKE_POLYMORPHIC`（含 RANGE 形式）、`CONST_METHOD_HANDLE`、`CONST_METHOD_TYPE`、odex 专用指令或不支持的 filled-new-array 类型时，转换失败并报告方法和指令。自动模式会保留这些方法并记录原因；手动模式不会悄悄缩减用户指定的范围。Kotlin 协程、动态反射及新字节码特性必须用实际业务代码验收。

AAR 内生成的 consumer rules 会保留 JNI 直接引用的类和成员，并保留原有规则；运行时计算出的反射名称仍需要应用自己的 keep 规则。AAR 应在下游应用启用 R8 的 release 构建中验证。

AAR 路径不能完整回写某些 D8 脱糖产生的辅助代码。检测到不支持的转换时会拒绝处理，建议对应用完成 D8/R8 后的最终 APK 进行加固。

## 生成发布目录

由 CI 的秘密变量提供 `NMMP_KEYSTORE_PASSWORD`，不要把密码写入脚本、版本库或命令行。以下路径是示例：

```bash
python3 tools/production_protect.py \
  --input /build/app-release.apk \
  --output /releases/app/2026-09-23-001 \
  --keystore /secure/app.jks \
  --alias app \
  --ks-pass-env NMMP_KEYSTORE_PASSWORD
```

工具 JAR 默认使用仓库构建产物。SDK 按环境变量及主机常见路径查找，NDK/CMake 默认使用环境变量或 SDK 中最新稳定版本；所有路径仍可用 `--tool`、`--sdk`、`--ndk`、`--cmake`、`--build-tools` 显式固定。机器只需安装一次工具链，不必为每个项目配置保护规则。CI 建议固定已验收的工具链版本。

添加 `--rules /build/convertRules.txt` 切换为手动模式，必要时再添加 `--mapping /build/mapping.txt`。自动模式不需要 mapping，提供时仅归档其哈希，不影响按 DEX 实际名称选择。独立 key 密码通过 `--key-pass-env` 指定。纯 Java APK 默认生成四种 ABI，可用 `--abis arm64-v8a armeabi-v7a` 收窄；已有 native 库则自动保留原 ABI 集合。原签名私钥不能从 APK 推导，必须由构建方提供。

底层 Java CLI 同样默认自动选择：`java -jar vm-protect.jar apk input.apk`；显式 `--auto` 等效。它输出未签名转换产物，正式发布仍使用上面的完整流程。

输出必须是尚不存在的新目录。脚本隔离每次执行，防止并发任务写同一个版本目录；所有检查通过后才重命名发布目录。原 APK 不会被原地改写。进程异常退出或校验失败返回非零状态，不产生成功发布目录。进程被强制终止可能遗留锁；确认对应任务已结束后才可清理 `.<版本目录名>.lock`。

普通失败会在输出目录的父目录保留权限受限的 `.<版本目录名>.failed-*.log`，错误信息给出具体路径。子进程完整输出写入磁盘，内存只保留有限尾部；超时会终止进程树。CI 应按内部构建日志策略保留和清理失败日志。

自动分析报告已生成但后续失败时，还会保留 `.<版本目录名>.failed-*.selection.json`。它仅用于排查排除原因，标记为未经发布验证的诊断信息，不代表已经完成加固。

发布检查包括：

1. 原包签名有效、ZIP 路径与条目合法，没有重复条目或二次 nmmp 加固。
2. 转换方法数满足门槛，报告的输入 SHA-256 与本次输入一致；自动模式的扫描统计、排除统计与实际转换方法集合严格一致。
3. 每个 ABI 都有两份 VM 库，所有 native 库的 ELF 架构、段边界、PT_LOAD 对齐有效。
4. `.so` 未压缩且 ZIP 数据起点按 16 KB 对齐；Manifest、资源和已有 native 库内容保持一致。
5. 先 zipalign 再签名，最终通过 apksigner 和 zipalign 检查，输出签名证书 SHA-256 集合与输入完全相同。

**原 APK 中存在仅支持 4 KB 对齐的第三方 `.so` 时会拒绝处理。** zipalign 只能修正 ZIP 布局，不能修正 ELF 链接布局；需要库提供方重新编译。静态 16 KB 检查通过后，仍须在真正的 16 KB 系统上运行验证。

## 产物、验收和回滚

成功目录包含 `app.apk`、`release.json`、`protection-report.json`、`native-symbols/`、`build.log`，自动模式另有 `selection-report.json`。只有 `app.apk` 是分发包。方法清单、符号和日志属于内部材料，应与 mapping 一起限制访问并长期保存，用于 native 崩溃定位。

`release.json` 记录输入、输出、工具、规则和 mapping 的 SHA-256，签名证书指纹、ABI、实际转换数和工具链版本，并记录 `selection_mode` 和自动选择报告哈希。自动模式没有手写规则，`rules_sha256` 为 null。生成 APK 使用 opcode 随机化，因此重复加固不要求 APK 字节完全相同。

投产前，用实际 release 包验证目标 ABI、最低和最新 Android、16 KB 系统、实际渠道安装与升级，覆盖支付、登录、后台任务、反射/序列化、冷启动和长时间运行。比较加固前后的启动耗时、关键方法 P95/P99、CPU、内存、ANR、native crash 和包体；本仓库的微型 fixture 不提供业务性能结论。全量转换通常会放大解释器开销，应以测量结果调整规则。

先灰度发布并保留上一版产物。停止灰度可以继续分发已留存版本；已升级设备通常不能直接安装较低 versionCode。需要用相同签名和更高 versionCode 构建恢复版本，并再次完成正常校验。

## 许可证

`nmm-protect` 使用 GPLv3，VM 使用 Apache-2.0。分发修改后的 GPL 工具需满足相应源码和许可证义务；将 VM 集成到产品时应保留 Apache 许可证、版权及适用 NOTICE。上游说明工具转换的业务输出不因此自动适用 GPL，但仍应依据实际打包内容和分发方式核对依赖许可证。本分支保留原有许可证。
