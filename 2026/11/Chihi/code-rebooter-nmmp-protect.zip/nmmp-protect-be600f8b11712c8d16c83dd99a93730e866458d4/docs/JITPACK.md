# GitHub / JitPack 接入

发布仓库为 [code-rebooter/nmmp-protect](https://github.com/code-rebooter/nmmp-protect)，固定版本 `v1.0.0` 已由 JitPack 构建并提供下载。实际远程坐标为 `com.github.code-rebooter:nmmp-protect:v1.0.0`，验证记录见 [VALIDATION.md](VALIDATION.md)。

## 应用接入

使用远程依赖时，将原来指向本地 nmmp 的 `pluginManagement.includeBuild(...)` 接入替换为下面的配置。保留项目现有的插件仓库和其他配置：

```groovy
// settings.gradle
pluginManagement {
    repositories {
        maven {
            url = uri('https://jitpack.io')
            content { includeModule('com.github.code-rebooter', 'nmmp-protect') }
        }
        google()
        mavenCentral()
        gradlePluginPortal()
    }
    resolutionStrategy.eachPlugin {
        if (requested.id.id == 'com.nmmedit.protect') {
            useModule("com.github.code-rebooter:nmmp-protect:${requested.version}")
        }
    }
}
```

在应用模块中指定已发布的固定 tag 或 commit：

```groovy
// app/build.gradle
plugins {
    // 保留原来的 Android、Kotlin 等插件。
    id 'com.nmmedit.protect' version 'v1.0.0'
}
```

映射配置只需添加一次。之后继续执行 `assembleRelease` 或对应渠道的 release 构建，升级插件时只修改版本号。加固 APK 仍位于 `app/build/outputs/nmmp/<变体>/apk/`，签名仍复用原项目配置。

如果使用 Kotlin DSL，对应配置为：

```kotlin
// settings.gradle.kts
pluginManagement {
    repositories {
        maven {
            url = uri("https://jitpack.io")
            content { includeModule("com.github.code-rebooter", "nmmp-protect") }
        }
        google()
        mavenCentral()
        gradlePluginPortal()
    }
    resolutionStrategy {
        eachPlugin {
            if (requested.id.id == "com.nmmedit.protect") {
                useModule("com.github.code-rebooter:nmmp-protect:${requested.version}")
            }
        }
    }
}
```

```kotlin
// app/build.gradle.kts
plugins {
    // 保留原来的 Android、Kotlin 等插件。
    id("com.nmmedit.protect") version "v1.0.0"
}
```

仓库名或 GitHub 账号变更时，修改仓库过滤和 `useModule` 中的 `com.github.账号:仓库名`。`com.nmmedit.protect` 是插件 ID。这里通过 `useModule` 直接定位实现包，不需要额外的插件 marker。

已验证组合为 AGP 8.13.2 / Gradle 8.14.3 / JDK 17。应用构建机需要 Python 3.11+ 和 Android SDK/NDK/CMake，release 需要已有签名配置；当前入口保护 APK，构建 AAB 会明确失败。完整要求和可选配置见 [GRADLE_PLUGIN.md](GRADLE_PLUGIN.md)。

本配置面向公开 GitHub 仓库。私有仓库需要先完成 JitPack 的仓库访问授权和依赖读取认证。

## 维护者发布

仓库根目录的 `jitpack.yml` 选择 OpenJDK 17，并执行 `tools/jitpack_publish.sh`。脚本从 `nmm-protect` 子目录运行 Gradle wrapper，使用 JitPack 提供的环境变量：

| 变量 | 示例 | 用途 |
| --- | --- | --- |
| `GROUP` | `com.github.code-rebooter` | GitHub 所有者对应的 group |
| `ARTIFACT` | `nmmp-protect` | GitHub 仓库名 |
| `VERSION` | `v1.0.0` | 本次固定 tag 或 commit |

脚本先在构建机本地发布 `GROUP.ARTIFACT:gradle-plugin:VERSION`。JitPack 检测到只有一个发布模块，会将远程 POM、Gradle module metadata 和下载路径改写为 **`GROUP:ARTIFACT:VERSION`**。因此消费方必须使用本页的仓库级坐标；带 `:gradle-plugin:` 的本地坐标不能用于这个远程版本。此行为已通过实际构建日志、HTTP 下载和消费方解析验证。

工具引擎、Python 脚本及原许可证都内嵌在插件 JAR 中，消费方无需下载源码仓库。源码包可通过 `-sources.jar` 下载；当前 JitPack 改写的 metadata 中 `sourcesElements` 文件名误指向二进制 JAR，IDE 自动附加源码可能失败，插件运行使用的 `apiElements` / `runtimeElements` 不受影响。

后续版本将验证后的代码推送到仓库并创建新的固定 tag，之后在 [JitPack](https://jitpack.io/#code-rebooter/nmmp-protect) 查询该版本，确认构建成功。首次依赖解析可能触发远程构建，需要等 JitPack 完成。确认依赖能实际下载后，再更新业务项目的插件版本；不要移动已发布的 tag。

`v1.0.0` 的 [构建日志](https://jitpack.io/com/github/code-rebooter/nmmp-protect/v1.0.0/build.log)、[POM](https://jitpack.io/com/github/code-rebooter/nmmp-protect/v1.0.0/nmmp-protect-v1.0.0.pom) 和 [插件 JAR](https://jitpack.io/com/github/code-rebooter/nmmp-protect/v1.0.0/nmmp-protect-v1.0.0.jar) 均可直接读取。

JitPack 只负责构建和发布插件，不需要业务 APK、业务签名密钥、Android SDK、NDK 或模拟器。业务应用构建机仍需 Python 3.11+ 和 Android SDK/NDK/CMake，其他支持范围见 [GRADLE_PLUGIN.md](GRADLE_PLUGIN.md)。

## 本地验证发布链路

在仓库根目录执行：

```bash
python3 integration/build_jitpack_smoke.py --sdk "$ANDROID_SDK_ROOT"
```

脚本将插件发布到隔离的 `.validation/jitpack-smoke/maven` 仓库，检查坐标、元数据、Java 17 字节码、许可证和内嵌工具，然后创建不使用 `includeBuild` 的独立 Android 项目，完成真实加固并校验签名、保护清单和 APK。所有签名均使用脚本生成的临时 fixture 密钥。

仅验证不依赖 Android SDK 的发布阶段：

```bash
python3 integration/build_jitpack_smoke.py --publish-only
```

本地验证不会推送 GitHub 或触发 JitPack。生成的 `summary.json` 明确记录 `hosted_jitpack_verified: false`，远程构建和实际下载需要单独验证。

JitPack 官方依据：[构建配置和环境变量](https://docs.jitpack.io/building/)、[多模块依赖坐标](https://docs.jitpack.io/)。
