# 验证记录

首轮日期：2026-09-22；自动模式增量验证：2026-09-23。分支：`production-hardening`。上游基线：`7a5802081a97900955dca78689443436e1d694a1`。

本仓库位于 WanApp 之外。测试使用独立 APK、临时签名密钥和专用模拟器；未操作真实业务签名或连接的客户设备。所有测试 APK、符号、日志和临时密钥位于被 Git 忽略的 `.validation/`。

## 主机与工具链

macOS x86_64，JDK 21.0.8，Python 3.14.2，Gradle 8.14.3，protobuf Gradle plugin 0.9.5，R8 8.13.17。SDK build-tools 36.0.0，NDK 28.2.13676358 / Clang 19，CMake 3.22.1。

## 自动化检查

| 检查 | 结果 | 主要覆盖 |
| --- | --- | --- |
| `./gradlew clean build --console=plain` | 60 项通过，0 失败，0 跳过 | apkprotect 44 项、arsc 16 项 |
| Python unittest | 21 项通过 | ELF/ZIP 校验、ABI/VM 缺失、签名失败、零转换、日志、锁、超时、既有版本保留 |
| 真正的 D8/R8 AAR 测试 | 包含在 Java 测试中 | JNI consumer rules、成员继承、包装方法、生成辅助类拒绝 |
| AAR JVM 执行测试 | 包含在 Java 测试中 | 新增/已有静态初始化块、参数槽、返回类型、方法元数据 |
| 真实签名轮换测试 | 通过 | 普通签名包接受；具有有效 A→B 轮换链的包明确拒绝 |
| 四 ABI 的 native 编译及静态校验 | 通过 | armeabi-v7a、arm64-v8a、x86、x86_64 |

原版核心测试被整体跳过；本分支恢复执行，并修复依赖 `/home/mao/` 的测试。规则/映射、路径清理、未支持指令、AAR 初始化和 multidex 拒绝等修复均有失败复现或回归测试。仍有上游弃用 API 与 Gradle 9 迁移警告；当前 wrapper 固定在已验证版本。

签名轮换检查使用 Android SDK 官方 apksig API。审查曾复现“当前证书相同但重新签名丢失历史链”，因此本分支拒绝该场景，不把当前证书一致等同于完整升级兼容。

## 运行时与发布流程

模拟器为独立创建的 `NmmpProductionValidation`，显式序列号 `emulator-5580`，Android API 31、x86_64、4096 字节内存页。安装包设置 `extractNativeLibs=false`，覆盖从 APK 直接加载 native 库。

fixture 包含普通及宽参数、整数/浮点/布尔/byte/char/short 返回、字符串、数组、异常捕获、switch、继承及 super 调用，以及重复的四线程并发执行。原版和加固版须通过相同的断言。转换报告记录 11 个实际转换方法。

独立发布脚本执行真实 Java 转换、NDK 编译、zipalign、apksigner，验证 Manifest/资源/已有 native 字节保持一致，生成符号与外部报告。运行记录包括正常安装原包、执行 instrumentation、同签名覆盖升级到加固包，再执行 instrumentation。

最终产物哈希与复现性结果见本文末尾的产物记录。原始 XML 统计保存在 `.validation/java-test-summary.json`，XML 副本在 `.validation/final-test-results/`；最终安装报告在 `.validation/install-upgrade-final.txt`，签名轮换记录在 `.validation/signing-policy-results.txt`。

## 复现命令

仓库根目录下执行，SDK 路径按实际安装位置替换：

```bash
python3 integration/build_smoke.py --sdk "$ANDROID_SDK_ROOT" --output .validation/smoke

env NMMP_SMOKE_PASSWORD=android python3 tools/production_protect.py \
  --input .validation/smoke/input.apk \
  --tool nmm-protect/build/libs/vm-protect-1.3.0-production-SNAPSHOT.jar \
  --rules integration/smoke/convertRules.txt \
  --output .validation/release-new \
  --sdk "$ANDROID_SDK_ROOT" \
  --ndk "$ANDROID_SDK_ROOT/ndk/28.2.13676358" \
  --cmake "$ANDROID_SDK_ROOT/cmake/3.22.1" \
  --keystore .validation/smoke/smoke.jks --alias smoke \
  --ks-pass-env NMMP_SMOKE_PASSWORD

python3 integration/run_smoke.py --serial emulator-5580 \
  --original .validation/smoke/input.apk --protected .validation/release-new/app.apk \
  --report .validation/install-upgrade-new.txt

python3 integration/check_signing_policy.py --sdk "$ANDROID_SDK_ROOT" \
  --input .validation/smoke/input.apk --report .validation/signing-policy-new.txt
```

`android` 仅为仓库生成的临时 fixture key 密码。安装测试脚本必须指向提前启动的专用模拟器，且拒绝非 `emulator-` 序列号。

## 尚未完成的产品验收

- 未运行真实 16 KB 系统。ELF 和 APK 静态对齐通过不能替代该项。
- arm64、arm32、x86 已编译并静态检查，当前运行时覆盖仅 x86_64/API 31。
- 未使用 WanApp 的 release 包验证支付、第三方 SDK、反射、后台行为或渠道安装。
- 未建立业务性能、ANR、native crash、长时间运行和灰度发布指标；微型 fixture 的耗时不能用于估算业务性能。
- AAR 有专项回归但没有完整设备矩阵；AAB/Play App Signing/split APK 不是当前生产入口。
- Linux/Windows 主机、最低/最新 Android、密钥轮换、系统预装升级和渠道 Source Stamp 需要独立验收或实现。

这些是实际投产前仍需完成的验收范围。当前交付是经过回归和有限运行验证的生产工程基础，不宣称完整商业加固服务的覆盖度或不可破解性。

## 2026-09-22 产物记录

工具 JAR 在同一 JDK 下连续两次 clean 构建的 SHA-256 一致。发布包使用第二轮实现完成后的最终代码，归档于 `.validation/release-final/`。

- 输入 APK SHA-256：`bcfee38cca9ee46d79c0f4b0ce91f424b852ade0626446f0e4693314436c9d76`
- 工具 JAR SHA-256：`303ffd9ba8656bcef2f04968b0bdb9679cc0a8a856b375eb9cc3e61e47962a47`
- 加固并签名 APK SHA-256：`19a696d088b32b1f677296929f5b0da7a38cdb3a582a08d831ea1ae7c9543d4a`

## 2026-09-23：默认自动选择增量验证

省略 `--rules`、`--mapping`、`--tool`、`--sdk`、`--ndk`、`--cmake`，仅提供输入、输出及临时签名凭据，生产流程自动发现本机工具链并完成四 ABI 构建、签名与发布检查。

- 原 smoke APK 扫描 25 个方法，自动选择并转换 18 个，保留 6 个构造方法和 1 个 synthetic 方法。实际运行覆盖扩大到 main、instrumentation 回调和 lambda 包装类。
- 自动清单按完整方法签名匹配，不依赖业务包名或 mapping。Java 回归验证同名不同返回类型、多 DEX、短混淆名称、保留未支持指令的原始代码、参数注解、同步/接口方法及跨 DEX 的 JNA 继承/成员类型。
- 自动选择数、方法集合、排除原因和输入哈希均由生产脚本验证。缺失、重复、重叠、类型错误或与实际转换不一致的报告会阻止签名/发布。手动规则和 mapping 流程的回归仍保留。
- 已完成独立模拟器 API 31/x86_64/4 KB 的原包安装、instrumentation、覆盖升级及加固版 instrumentation，两个阶段均返回 `INSTRUMENTATION_CODE: -1`。
- 新增失败诊断保留测试：即使零选择或后续转换失败，已有排除清单也会保留为权限受限的 unverified 诊断文件，便于查看原因。
- 补充的 DEX35+DEX39 输入复现了上游重打包沿用主 DEX 版本的缺陷。正常生产路径现按每个输入 DEX 的 opcode 版本重写，JUnit 验证新指令与版本均被保留。

静态策略不会保证任意 APK 的运行时兼容性或性能最优；本页原有真实业务/设备/16 KB 验收限制继续适用。工具自动生成规则不等于自动推断业务价值。

增量最终检查：Java **68 项通过**（apkprotect 52、arsc 16，0 失败、0 跳过）；Python **46 项通过**。多 DEX 真实流程扫描 26 项、选择并转换 18 项、保留 8 项，四 ABI 编译和签名检查通过；原版及覆盖升级后的 instrumentation 均通过。记录在 `.validation/install-upgrade-auto-multidex.txt` 和 `.validation/release-auto-multidex/`。

新增的不支持指令方法用于验证字节码保留、DEX 版本和打包；设备上的 instrumentation 执行原 smoke 流程，未调用该新增方法。该方法的保留证据来自读取输出 DEX 的回归断言。

- 自动模式工具 JAR SHA-256：`7dfad4d0ccc874606632393fd0a99648b5c08c80b9bdad2fd0d39fe26761673f`
- 多 DEX 加固并签名 APK SHA-256：`caa57d2248f2c5110a11e59ffd5633422372f4e8bd00be2c6833d951279bf3b7`
- 自动选择报告 SHA-256：`40a9f77bb8ba0828a4a8b204af4742aeb9d996a059338efc69b057d2427be7f4`

## 2026-09-23：Gradle 自动 release 加固

新增 `com.nmmedit.protect` 插件，独立 fixture 只在 settings 加入 composite build、应用模块声明插件并保留原 Android 签名配置，执行普通 `assembleDemoRelease` 即完成自动保护。未修改 WanApp。验证组合为 AGP 8.13.2、Gradle 8.14.3、JDK 21、Python 3.14.2 及前述 SDK/NDK/CMake。

- 完整 `./gradlew build --console=plain` 通过，共 **79 项 JVM 测试**：apkprotect 52、arsc 16、Gradle 插件 11；0 失败、0 错误、0 跳过。Python 回归 **46 项通过**。
- 真实 Gradle 流程完成 12 次调用，包括 6 次成功的加固构建、1 次正常 debug 构建和 5 次预期失败。六次加固均实际转换 18 个方法。覆盖初次构建、重复构建、另一渠道的签名、build type 覆盖渠道签名、失败后的恢复，以及请求配置缓存。
- `SingleArtifact.APK` 的实际消费者得到加固目录，APK 元数据指向加固文件，原 DEX 的 baseline profile 引用已移除。debug APK 不包含 NMMP 库。
- 自带一个 16 KB 对齐的 x86_64 测试库时，不填写 `nmmp.abis` 也能自动保留原 ABI 并完成保护，避免默认强制四 ABI 破坏已有 native 应用。此轮插件真实编译及运行范围为 x86_64；引擎此前已完成四 ABI 编译。
- 独立质量审查发现 AAB 生命周期检查可被直接产物消费者绕过，真实 Gradle 任务复现后新增 BUNDLE 产物转换拒绝任务，并拦截直接签名任务。新增测试包含跳过上游签名时仍拒绝直接产物消费者。
- 缺少签名、请求 AAB、直接读取 BUNDLE、直接执行 Bundle 签名、使用不存在的 Python 路径均被拒绝。上一次成功后再次失败时，旧加固 APK 被清除；修复配置后正常恢复。
- 启用 `--configuration-cache` 的真实构建成功，并报告 `Configuration cache entry discarded because incompatible task was found`。插件签名配置字段为 transient、`@Internal`；独立子进程测试验证密码仅通过环境传递，失败输出及保存日志会脱敏。
- API 31/x86_64/4096 字节页的专用模拟器上，原始 AGP release 包安装和 instrumentation 通过；使用同一签名覆盖升级至插件加固包后，instrumentation 再次通过。日志为 `.validation/install-upgrade-gradle.txt`。

完整 Gradle 流程可用 `python3 integration/build_gradle_smoke.py --sdk "$ANDROID_SDK_ROOT"` 重现。日志和统计位于 `.validation/gradle-smoke/acceptance/`，测试统计另存于 `.validation/gradle-java-test-summary.json`。产物使用临时 fixture 密钥，最终扫描 26 个方法、转换 18 个、保留 8 个。

- 插件 JAR SHA-256：`c63184643f269aaf5af00a61536423b0d288a4f29b9d8f658062b5f4381b7bf0`
- 最终插件加固 APK SHA-256：`a4eb035b5a1341fecbf15ccbc97e7dfdb8e98117af56091eb4e9d5c36caf5021`

已核对插件 JAR 内嵌引擎、生产脚本、APK 校验器和签名策略助手的哈希与最终 APK 发布记录一致。本次没有发布到 Maven/Plugin Portal，使用本地 composite build 接入。其他 AGP 版本、主机平台、设备矩阵及实际业务性能仍受本页验收范围限制。

## 2026-09-23：JitPack 发布配置与独立 Maven 消费方

新增仓库根目录 `jitpack.yml` 和 `tools/jitpack_publish.sh`，使用 Java 17 从嵌套 Gradle 构建发布 `gradle-plugin` 模块。先复现了原构建忽略发布 group/version、仍写入固定 `com.nmmedit` 坐标的问题，再加入可覆盖的发布坐标并验证实际产物。

- 使用 Amazon Corretto 17.0.13 完成完整 `./gradlew build`：79 项 JVM 测试，0 失败、0 错误、0 跳过；包括 11 项插件测试和插件属性校验。
- 实际发布到隔离的本地 Maven 仓库，坐标为 `com.github.nmmp-fixture.nmmp-protect:gradle-plugin:jitpack-smoke`。POM、Gradle module metadata、sources JAR 和 Java 17 插件字节码均已检查；POM 不依赖未发布的内部模块。
- 插件包包含加固引擎、三个生产辅助文件以及原 GPL/Apache 许可证。缺少 GROUP、ARTIFACT 或 VERSION 时，发布脚本在调用 Gradle 前拒绝执行。
- 独立 Android 消费方只通过 Maven 仓库和 `useModule` 解析插件，未使用 `includeBuild` 或指向 nmmp 的源码目录。Java 17 / AGP 8.13.2 下的真实 release 构建、自动转换 18 个方法、x86_64 native 编译、签名和产物检查通过。
- 实际 APK 使用的引擎及辅助文件哈希与 Maven 插件 JAR 内的文件完全一致，签名与独立临时 fixture 密钥一致。记录在 `.validation/jitpack-smoke/summary.json`、`publication.log` 和 `consumer-build.log`；完整构建日志为 `.validation/jitpack-full-build.log`。

发布插件 JAR SHA-256：`4105ac60de83527f86b7fba501cda18c9ff455b63b7b74acda4332185bf5851a`。独立消费方加固 APK SHA-256：`48d3a6691da11ecb90e46d61d2a33ac9c231656b9f94d9d71b988f076a72014a`。

上述阶段是本地 Maven 发布和独立消费方的验证，其 `hosted_jitpack_verified` 为 false。随后完成的实际远程验证见下节。

## 2026-09-23：GitHub / JitPack 真实发布验证

用户提供公开仓库 `https://github.com/code-rebooter/nmmp-protect.git` 后，将已验证代码推送到 `main`，发布固定标签 **`v1.0.0`**，标签对应提交 `0dc85be74a9ab5ed55d62e884de33eaed34d7441`。本地 `origin` 仍指向原作者仓库，新增 `distribution` 指向用户仓库。文档修正随后单独推送到 main，未移动版本标签。

- JitPack 使用 Java 17.0.12 成功执行发布脚本，Gradle 构建 44 秒，退出码 0；[公开构建日志](https://jitpack.io/com/github/code-rebooter/nmmp-protect/v1.0.0/build.log) 列出了实际产物。构建 API 返回 `status: ok` 及上述提交。
- 实际远程坐标是 **`com.github.code-rebooter:nmmp-protect:v1.0.0`**。JitPack 将唯一发布模块改写到仓库级坐标；先前假设的 `com.github.code-rebooter.nmmp-protect:gradle-plugin:v1.0.0` 对应 POM 实测 HTTP 404。接入文档已修正。
- 实际下载了 POM、module metadata、插件 JAR 和 sources JAR，核对坐标、Java 17 字节码、插件描述符、内嵌引擎/辅助文件/许可证，以及没有未发布模块依赖。远程二进制 JAR 与先前本地验证的 JAR SHA-256 完全一致。
- 独立 Android 项目仅以 `https://jitpack.io` 解析 NMMP 插件，没有 `includeBuild` 或本地 Maven 回退。Gradle 日志明确记录从 JitPack 下载 POM、module 和 JAR。Java 17 / AGP 8.13.2 / Gradle 8.14.3 下，`:app:assembleRelease :app:verifyPublishedPlugin` 成功，47 项任务实际执行。
- 真实自动加固转换 18 个方法，完成 x86_64 native 构建。最终 APK 产物路径、元数据、自动选择清单、转换清单、签名、ABI/ELF/ZIP 检查均通过。实际执行的引擎和辅助文件哈希与远程插件内嵌文件一致；签名使用独立临时 fixture 密钥。
- 首次带 `--refresh-dependencies` 的验证遇到 Maven Central HTTP 403，停止该调用后正常构建通过，沿用已缓存的 AGP 依赖。NMMP 的 POM/module/JAR 为本次从 JitPack 首次下载；没有手工注入 Gradle 缓存或替换为本地插件。
- 从接入文档直接提取 Groovy 和 Kotlin DSL 配置，分别通过 `help` 和 `:app:tasks --all` 检查；Kotlin 示例实际注册了 `nmmpProtectRelease` 和 AAB 拒绝任务。Kotlin 校验缺少缓存依赖且 Central 主站返回 403，使用临时 init script 将 Central 路由到 Google 公开镜像后通过；JitPack 地址和文档配置保持原样。该 init script 仅用于本机验证，不属于插件接入要求。

记录保存在 `.validation/jitpack-hosted/`：`status.json`、`build.log`、`consumer-build.log` 和 `summary.json`。汇总中 `hosted_jitpack_verified` 和 `consumer_verified` 均为 true。

- 远程插件 JAR SHA-256：`4105ac60de83527f86b7fba501cda18c9ff455b63b7b74acda4332185bf5851a`
- 远程 sources JAR SHA-256：`0c52fe33315a233b09a0f609d6d001b85fcc0ee6b502315539c50fcfe5f6ff82`
- 远程消费方加固 APK SHA-256：`74a26bb36e97e35a1ca172fe8322bfabb17b408258d477ebdd3335eb777b1023`

JitPack 改写的 `sourcesElements` metadata 文件名误指向二进制 JAR，直接下载的 sources JAR 内容正确；该托管元数据问题可能影响 IDE 自动附加源码，未影响实际插件解析和构建。此次新增的是发布与下载验证，没有新增设备运行、业务 APK 或性能验收；本页既有运行时覆盖范围继续适用。
