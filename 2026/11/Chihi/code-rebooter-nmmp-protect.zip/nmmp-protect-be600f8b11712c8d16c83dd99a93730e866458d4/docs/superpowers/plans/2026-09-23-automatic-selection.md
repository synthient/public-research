# Automatic APK selection implementation plan

**Goal:** Make normal APK processing automatic without user-authored rules or mappings.

**Architecture:** A Java selector inspects the actual DEX method definitions and returns an exact-signature filter and auditable exclusions. ApkProtect prepares it after all DEX classes are loaded, compares the conversion result against the plan, and writes the external selection report. Python makes manual rules optional and verifies/archives the automatic report before signing/publication.

**Tech stack:** Existing dexlib2, Gson, JUnit 4, Python unittest, Android SDK/NDK and a private emulator.

- [x] Add failing Java tests under `nmm-protect/apkprotect/src/test/java/com/nmmedit/apkprotect/AutomaticSelectionTest.java`: overload-specific selection, incompatible instructions retained, multidex and obfuscated identifiers, zero selection, structural exclusions and report/hash correctness.
- [x] Implement `AutomaticSelection.java`, wire default/--auto APK CLI and ApkProtect preflight/report reconciliation. Keep explicit rules strict. Share instruction support checks where useful so automatic selection matches converter limitations.
- [x] Independently update `tools/production_protect.py` and Python tests: optional rules, machine tool discovery, auto command, selection report validation and archival, rejection of missing/mismatched coverage. Do not alter signing or ELF requirements.
- [x] Run Java and Python regressions, then real default-mode APK processing and private-emulator install/upgrade. Audit generated selection and exclusions. Retest explicit manual mode as needed.
- [x] Review spec compliance and code independently, fix findings, update production/validation docs, commit on production-hardening and leave a clean checkout. Keep fixture outputs ignored and stop the private emulator.

Validation: `./gradlew build --console=plain`; `python3 -m unittest discover -s tools/tests -v`; production invocation omitting --rules and --mapping; fixture runner against explicit emulator serial. Tests must demonstrate native conversion and retention, not just count planner output.
