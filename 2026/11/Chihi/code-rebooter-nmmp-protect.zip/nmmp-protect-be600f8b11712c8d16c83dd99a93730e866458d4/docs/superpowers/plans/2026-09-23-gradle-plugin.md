# Gradle plugin implementation plan

> Use subagent-driven-development for the bounded plugin implementation while the controller builds the independent acceptance fixture. Use test-driven-development and independent specification/quality review.

**Goal:** Applying a Gradle plugin makes normal release APK builds automatically protect and verify the final artifact.

**Architecture:** A new `nmm-protect/gradle-plugin` project embeds the existing protection tools, transforms SingleArtifact.APK, and reuses AGP's merged signing configuration. An independent Android fixture verifies the normal build/install behavior without modifying WanApp.

**Tech Stack:** Groovy, Gradle 8.14.3, AGP 8.13.2, JUnit/Gradle TestKit, Python 3.11+, existing SDK/NDK/CMake.

- [x] Implement plugin and meaningful failing/passing tests in `nmm-protect/gradle-plugin`. Add the project to `nmm-protect/settings.gradle`. Bundle the protector and production runner through `processResources`, register plugin `com.nmmedit.protect`, wire release APK transform, expose limited environment overrides, use merged variant signing, reject unsupported outputs, and retain verified output metadata/reports. Run `./gradlew :gradle-plugin:test :gradle-plugin:validatePlugins --console=plain` from `nmm-protect`.
- [x] Create `integration/gradle-smoke` and `integration/build_gradle_smoke.py` as a self-contained fixture generator/runner. Use an ignored temporary output and disposable keystore, source existing instrumentation regression code, apply the plugin through composite `includeBuild`, and build debug plus flavored release using AGP 8.13.2. Assert actual APK artifact wiring, successful protection reports, unchanged signer, repeat build behavior, and meaningful missing-signing/bundle failures. Capture logs under `.validation/`.
- [x] Exercise the final signed fixture with the existing explicit-serial install/upgrade runner when the dedicated emulator is available. Independently review specification compliance and then code quality. Fix confirmed findings and run affected tests; run the complete required build and Python regressions once final changes settle.
- [x] Document two-file initial setup, unchanged build commands, output location, prerequisites and verified support in `docs/GRADLE_PLUGIN.md`, link from `README.md` and `docs/PRODUCTION.md`, update `docs/VALIDATION.md` and `docs/WORKLOG.md`, commit locally on `production-hardening`, and leave the checkout clean.

Success requires real compiled/protected artifacts, not merely successful task registration. No Maven/Plugin Portal publication, real signing credentials, WanApp edits or production deployment are part of this work.
