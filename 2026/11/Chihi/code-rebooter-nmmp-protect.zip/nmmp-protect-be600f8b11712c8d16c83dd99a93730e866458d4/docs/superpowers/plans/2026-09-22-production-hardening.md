# nmmp Production Engineering Implementation Plan

> For agentic workers: use subagent-driven-development for bounded independent implementation and requesting-code-review for review. Continue through authorized tasks without permission checkpoints.

**Goal:** Deliver a tested, auditable production APK processing path and repair confirmed upstream conversion/build failures.

**Architecture:** Preserve Java DEX conversion and JNI interpreter; add focused packaging/process helpers and a strict Python release pipeline. Build tooling owns reproducible VM source assembly; production tooling owns staging, signing and artifact verification.

**Tech Stack:** Java/JUnit 4, Gradle, ASM, dexlib2, CMake/NDK, Python 3 unittest, Android SDK command-line tools.

## Tasks

- [x] 1. Establish build baseline; enable core tests and repair nonportable fixtures. Update Gradle/build configuration for installed JDKs, reproducible JARs, and generated VM source resources. Files: nmm-protect/build.gradle, apkprotect/build.gradle, arsc/build.gradle, wrapper properties, existing AsmUtilsTest. Run `./gradlew clean build --console=plain`; verify core test XML contains executed cases, no blanket exclusions.
- [x] 2. Fix AAR method conversion and consumer rules with regression tests. Files: aar/asm/MethodToNativeVisitor.java, aar/AarProtect.java and tests. Use ASM-generated parent/child collisions; assert transformed class has both original wrapper and registered private native, correct static/instance invocation and IRETURN/LRETURN/FRETURN/DRETURN/ARETURN/RETURN. Verify user annotations survive and referenced names remain protected after downstream R8.
- [x] 3. Repair rule and mapping correctness with failing tests. Files: dex2c/filters/SimpleRules.java, ProguardMappingConfig.java and tests. Exercise nested `$` names, literal regex metacharacters, overlapping class rules, blank/comment lines, malformed/unclosed blocks and unmapped methods. Assert no accidental broadening, crashes, or order-dependent selection.
- [x] 4. Fix native subprocess execution, host tool discovery and explicit 16 KB linker settings. Files: BuildNativeLib.java, util process helper, mksrc CMake templates. Regress child filling stderr, nonzero exit and timeout using a tiny Java subprocess; use temporary toolchain layouts for host selection. Compile native fixture for armeabi-v7a, arm64-v8a, x86, x86_64 and inspect PT_LOAD alignment.
- [x] 5. Repair APK packaging and add coverage preflight/report. Files: ApkProtect.java, focused packaging helper, CLI shared preflight, tests. Use real ZIP entries to assert STORED native libraries and 16384-aligned payload offsets. Preserve other resources, remove old signing entries, reject VM name collisions and zero-method selection before native compilation; include input hash and selected/converted counts in external report.
- [x] 6. Add strict production APK runner with self-contained unittest coverage. Files: tools/production_protect.py, tools/tests/test_production_protect.py. Stage input/tool/config per invocation, require rules, execute Java/zipalign/apksigner without a shell, verify ELF load segments and APK payload alignment, verify input/output signer digest equality, reject overwriting unless explicitly selected and publish after success. Test success plus unsigned input, mismatch, invalid ELF, missing ABI, nonzero tool exit and preservation of existing release.
- [x] 7. Build deterministic Android integration fixture and run original/protected behavior comparison on a disposable emulator. Keep the fixture, build outputs and debug signing material outside WanApp; do not operate on connected customer devices. Verify host checks even if emulator is unavailable; record exact limitations rather than inferring runtime success.
- [x] 8. Independent spec and code review; fix material findings. Document usage and actual test evidence in docs/PRODUCTION.md and docs/VALIDATION.md, archive symbols/report locally, inspect final diff and git status, commit reviewable changes on production-hardening without pushing or deploying.

## Validation commands

`env JAVA_HOME=/Users/zengyue/Library/Java/JavaVirtualMachines/corretto-17.0.13/Contents/Home ./gradlew clean build --console=plain`

`python3 -m unittest discover -s tools/tests -v`

`python3 tools/production_protect.py --help`

Record test counts from XML and output artifact SHA-256; a build task marked SKIPPED is not evidence of a passing test suite.
