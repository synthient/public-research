# GitHub and JitPack distribution

The user selected GitHub/JitPack as the available remote distribution mechanism. Suggested repository name: nmmp-protect. The user will create the repository; no upstream push is intended.

Publish the self-contained gradle-plugin Maven publication from the nested nmm-protect build. JitPack uses its GROUP, ARTIFACT and VERSION environment variables to assign `GROUP.ARTIFACT:gradle-plugin:VERSION`, following its documented multi-module coordinates. Local composite builds retain their existing group/version. Only the implementation publication is needed; consumer pluginManagement maps com.nmmedit.protect to this module through resolutionStrategy.useModule, avoiding assumptions about JitPack rewriting plugin marker coordinates.

The JitPack build uses JDK 17 and the checked-in Gradle wrapper. It packages the embedded engine and Python helpers without requiring an Android SDK, native compilation, signing keys, or an emulator on JitPack. End users continue to need their normal Android/Python/native toolchain. Publication metadata includes project description and GPL licensing; the repository contains corresponding source and original VM license.

Validate publication into an isolated local Maven repository with JitPack-shaped coordinates, inspect the actual POM/module/JAR and resource content, then build a separate Android application using only that Maven artifact. The consumer must not use includeBuild or source paths into nmmp. Perform a real automatic signed APK build and verify coverage, signatures and final artifact resolution. Preserve local-composite behavior. Documentation must distinguish local simulation from an actual hosted JitPack build.

Complete and commit the local configuration before any remote publication. Use the GitHub destination the user supplies; do not overwrite upstream origin or choose repository visibility for them. After an authorized push, use a fixed commit/tag and verify the actual JitPack artifact before claiming remote availability.
