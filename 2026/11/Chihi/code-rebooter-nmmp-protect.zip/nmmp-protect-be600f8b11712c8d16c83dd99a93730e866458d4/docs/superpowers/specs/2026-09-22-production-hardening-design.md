# nmmp production engineering design

The user authorized production-oriented optimization of maoabc/nmmp, explicitly outside WanApp. This checkout is independent at ../nmmp, branch production-hardening, based on upstream 7a5802081a97900955dca78689443436e1d694a1. No WanApp source, signing material, or connected customer devices will be modified as part of development.

## Approach

Retain the existing interpreter and command-line formats while making their correctness, packaging and failure behavior testable. A replacement VM would multiply semantic and maintenance risk; merely wrapping the unmodified upstream leaves confirmed packaging and conversion defects. Implement targeted repairs plus a strict production APK pipeline. APK is the production acceptance path; AAR receives conversion regression fixes and documented R8 constraints. AAB remains available but is not declared production validated without a bundletool/device matrix.

## Required behavior

* Build and run real core tests on supported JDK 17/21. Produce a deterministically packaged tool JAR with current VM sources built from source, not a stale archive cache.
* Generate native libraries with explicit 16 KB ELF alignment and supported ABI coverage; package every uncompressed APK native library with 16 KB ZIP alignment. Preserve input non-code entries and remove invalidated signatures. Validate all prebuilt native libraries instead of assuming rebuilding the VM fixes them.
* Correct AAR collision wrappers, preserving calling convention, return categories and public method metadata. Include consumer rules needed for JNI references in transformed code.
* Compile class/method selection patterns once, treat names literally apart from the documented wildcard, union overlapping rules deterministically, reject malformed rules and handle incomplete R8 mappings without null dereferences.
* Fail clearly for unsupported selected instructions and zero converted methods. Report protection coverage; do not label a package protected merely because a VM library was added.
* Avoid child-process pipe deadlocks; propagate nonzero exits, timeouts and interruption. Discover host NDK tools on macOS/Linux/Windows rather than assuming linux-x86_64.
* Production APK processing uses a private temporary workspace and explicit rules. Verify native ELF/ZIP properties, align before signing, verify signatures and certificate continuity, compute SHA-256 only after signing, and publish artifacts only after all checks pass. Keystore passwords are supplied through named environment variables to apksigner, not literal command-line secrets. Preserve the previous release on failure.
* Document licensing, supported commands, regression coverage, rollback, native symbols and remaining device acceptance requirements. No claims of unbreakable protection or universal Android compatibility.

## Verification

Self-contained JVM regression tests exercise conversion and packaging defects. Python runner tests use real ZIP/ELF fixtures and fake external tools only for failure injection. An integration fixture executes original and transformed business methods on a disposable emulator if available, including exceptions, inheritance, primitive/wide returns, arrays and repeated calls. Compile four native ABIs with NDK r28 and inspect ELF load segments. Production acceptance additionally requires the actual fleet, Android 6/system-signature upgrades, 16 KB device execution and business/performance regression. Those cannot be inferred from host tests.
