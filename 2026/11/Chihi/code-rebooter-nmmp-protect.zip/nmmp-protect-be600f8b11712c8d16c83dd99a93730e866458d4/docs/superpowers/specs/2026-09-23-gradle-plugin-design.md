# Automatic release APK Gradle plugin

The user selected a Gradle plugin: configure once, then normal release builds automatically protect their APK. Work stays in this independent nmmp checkout; WanApp is read-only context.

## User contract

Register this checkout through `pluginManagement { includeBuild("../nmmp/nmm-protect") }` and apply `com.nmmedit.protect` to the Android application module. The plugin builds/bundles its protector and Python runner automatically. No manually built JAR, protection rules, mapping, or repeated signing configuration is required. Existing release signing configuration supplies credentials, including product-flavor overrides. Default debug builds do not invoke protection.

Keep using `assembleRelease` or the existing flavored release task. Protected APKs become the final AGP APK artifact, and their location is printed. Separate internal reports and native symbols are retained under the module build directory. A protection failure fails assembly and invalidates the previous task output. Installation through AGP must consume the protected artifact.

## Architecture and scope

Add `nmm-protect/gradle-plugin` with a Groovy Gradle plugin. Bundle the root protector fat JAR and the three production runner source files as resources. Invoke the existing verified pipeline using a discovered Python 3.11+ interpreter and the Gradle JVM. SDK location comes from AGP, while NDK/CMake discovery reuses the runner. The machine needs installed SDK, NDK, CMake and Python; missing prerequisites produce actionable errors. Do not silently accept SDK licenses or download unpinned runtimes.

Use AGP's public SingleArtifact.APK transform API. Resolve signing from AGP's merged legacy application variant, rather than guessing flavor precedence. Support the verified AGP 8.13.2 / Gradle 8.14.3 / JDK 17+ combination first, reject unsupported AGP majors, and document the actual validation envelope. Guard AAB, dynamic features and split outputs rather than claiming protection for them.

The transform validates input APK metadata, handles one standalone APK, invokes the runner in a private temporary directory and publishes the checked APK plus corrected AGP metadata. Reports live separately. The output must not reference original APKs or original DEX baseline profiles. Both normal assembly and AGP consumers depend on the transform.

Do not put passwords in command arguments, logs, Gradle task inputs or shared build caches. Protection tasks are non-cacheable and always validate their output; configuration cache is explicitly unsupported for these tasks because merged signing configuration must remain in memory. Secrets are passed only in the child environment. No real production keys or user devices are used during validation.

## Acceptance

Test plugin application and release/debug task wiring with real AGP, flavor-specific signing resolution, repeat builds, missing signing and runner failures, unsupported bundle/split paths, metadata rewriting, and final artifact consumption. Build a fixture with a disposable key using only the documented plugin application; verify native conversion, signatures, report hashes and protected metadata. Exercise install/upgrade using only a dedicated fixture emulator if available. Keep the existing 68 Java and 46 Python tests green, then perform independent specification and quality reviews.
