# Work log

2026-09-22 — Independent checkout `../nmmp`, branch `production-hardening`, upstream `7a5802081a97900955dca78689443436e1d694a1`.

- Restored upstream-disabled core tests and removed a nonportable `/home/mao` fixture dependency. Final full JDK 21 clean build passed 44 apkprotect and 16 arsc tests, no failures or skips.
- Upgraded Gradle to 8.14.3 with pinned distribution SHA-256, protobuf plugin to 0.9.5, and R8 to 8.13.17. VM source resources are assembled from checked-out sources. Two clean JAR builds produced identical SHA-256.
- Fixed native subprocess output handling, nonzero exits, timeouts, interrupt preservation and host-specific NDK strip discovery. Compiled four ABIs using NDK r28 and checked both VM libraries for 16 KB ELF/ZIP alignment.
- Added canonical ZIP extraction bounds and non-following cleanup. A symlink-cleanup test reproduced deletion outside the target directory before the repair.
- Repaired literal wildcard handling, overlapping positive rules, rule syntax validation and R8 mapping of object/array descriptors. Regression failures were observed before fixes.
- Added actual method coverage reporting and zero-conversion rejection. Real APK integration caught metadata being cleared before reporting; cached lightweight method names resolve this.
- Fixed AAR wrapper/native registration and JNI consumer rules with real downstream R8 checks. Independent review reproduced invalid generated initializer stack bounds and absent D8 companion classes. Initializer generation is fixed; unsupported desugaring, selected native interface methods and multidex AAR are now refused.
- Rejected unimplemented CONST_METHOD_TYPE / CONST_METHOD_HANDLE before native generation, with method-specific errors and real DEX regressions.
- Added isolated, locked, atomic APK release runner with resource/native preservation, original signer continuity, ELF/ZIP/ABI validation, conversion threshold, symbol/report archival, bounded process output and private retained failure logs. Python suite passed 21 tests.
- Independent review reproduced loss of certificate rotation history despite equal current fingerprints. Added SDK apksig API policy verification and real temporary-key signing regression: valid ordinary input accepted; valid A-to-B rotation rejected.
- Actual fixture release converted 11 methods and passed normal installation, instrumentation and same-signer upgrade on the private API 31 x86_64 / 4 KB emulator. Final report and artifact hashes are recorded in docs/VALIDATION.md and ignored .validation outputs.
- CLI help succeeds and missing-input subcommands return a nonzero exit code. No WanApp files, actual signing keys, customer devices, upstream branches or external deployments were changed.

See docs/PRODUCTION.md for usage and docs/VALIDATION.md for exact acceptance limits. Real 16 KB systems, business release packages, target device matrices and performance/crash/ANR budgets still require product acceptance; these are not implied by fixture success.

2026-09-23 — User clarified that project rule authoring and routine adaptation belong in the tool.

- Added default automatic APK selection using all input DEX methods and exact signatures. No required manual rules or mapping, and no package-name ownership guesses.
- Known-incompatible methods stay in original DEX form with explicit exclusion reasons; selected and converted descriptor sets must agree. Manual rules remain available with strict unsupported-instruction errors.
- Added toolchain discovery and selection-report validation/archival. Failed automatic runs retain the available selection diagnostics separately from successful releases.
- Real no-rule fixture run built all four ABIs, selected 18/25 methods, and passed normal install/upgrade instrumentation. Static policy excludes six constructors and one synthetic method in that fixture.
- Spec review found JNA member-signature omissions; added failing regression and included field value types plus invoked method parameters/return types.
- Mixed-version multidex integration exposed retained DEX39 instructions being rewritten with DEX35 opcodes; fixed normal output to preserve each source DEX's version and added failing/passing regression.
- Final validation passed 68 Java tests and 46 Python tests. The mixed-version fixture selected 18/26 methods, built four ABIs, and passed original/protected installation and instrumentation on API 31 x86_64. The extra retained DEX39 method was checked in bytecode tests, not invoked on the device.
- Independent specification and code-quality reviews completed with no remaining material findings. Production and validation documentation now describe the automatic invocation, exclusions, and acceptance limits; the private emulator has been stopped.

2026-09-23 — User selected a Gradle plugin for one-time setup and automatic release protection.

- Added `com.nmmedit.protect` as a bundled Gradle plugin, using AGP's APK transform and the existing verified runner. Release and flavored release assembly automatically protect the final APK, reuse merged signing configuration, and fail on protection errors. Debug is unaffected.
- Real AGP integration required `toTransformMany` for APK artifacts. Fixed default ABI handling to defer to input native libraries and added both a regression and a real native-input build.
- Twelve real Gradle calls verified six protected builds plus debug and five expected failures: flavor/build-type signing, repeat builds, default native ABI discovery, missing signing, bundle rejection, stale-output removal, failure recovery and configuration-cache discard.
- Full build passed 79 JVM tests (including 11 plugin tests); Python passed 46 tests. Original/protected release instrumentation and same-signer upgrade passed on the private API 31/x86_64 emulator. Validation records include plugin and final APK hashes and bundled-resource consistency.
- Added the independent fixture and two-file setup guide in docs/GRADLE_PLUGIN.md. WanApp, real signing keys, connected user devices, external package registries and deployment channels were not modified.

- Specification review approved the plugin. Quality review identified a direct BUNDLE-consumer bypass; reproduced it with real AGP, added artifact-level rejection plus direct-signing guards, and verified both new regressions and the complete final integration flow.
- Final API 31 install/upgrade verification passed after the bundle-guard repair; the dedicated emulator was stopped. All final staged checks passed before the local commit.

2026-09-23 — User selected GitHub/JitPack remote distribution and is creating the target repository.

- Added a root JitPack entry point using Java 17 and the checked-in wrapper. Optional publication coordinates follow JitPack GROUP/ARTIFACT/VERSION while preserving the existing local build defaults. Published sources and license metadata accompany the bundled plugin.
- Reproduced the previous fixed-coordinate publication, then verified exact JitPack-shaped coordinates and complete standalone Maven artifacts in an isolated local repository.
- Added an independent Maven consumer fixture with no included/source nmmp build. Java 17 release assembly protected 18 methods and passed native, signature, metadata and embedded-resource hash checks. Full Java 17 build passed all 79 JVM tests.
- Documented pluginManagement useModule mapping and release preparation in docs/JITPACK.md. No upstream push, GitHub repository creation, hosted JitPack build, or remote availability claim was made; the user has not yet supplied the created repository URL.

2026-09-23 — User supplied `https://github.com/code-rebooter/nmmp-protect.git` for publication.

- Confirmed the repository was public, empty and writable, preserved upstream origin, and added distribution remote. Pushed main and immutable `v1.0.0` at `0dc85be74a9ab5ed55d62e884de33eaed34d7441`.
- JitPack built the plugin successfully under Java 17. Actual hosting rewrote the single published module to `com.github.code-rebooter:nmmp-protect:v1.0.0`; the previously assumed module URL returned 404. Corrected the consumer guide and added Kotlin DSL examples.
- Downloaded real hosted metadata, binary and sources. The binary hash exactly matches the locally verified publication. A separate Android consumer downloaded the plugin from JitPack and successfully protected 18 methods, compiled x86_64 native code and verified the final artifact, signatures and embedded-resource hashes. Evidence is in `.validation/jitpack-hosted/` and docs/VALIDATION.md.
- Kept the tag fixed while updating main documentation. Recorded JitPack's sources-variant filename rewrite issue and the unchanged device/business acceptance limits; no application/runtime implementation changed during publication.
