# Gradle 自动加固接入

把插件加进应用模块后，正常构建 `release` APK 就会自动加固、重新签名和校验。规则由工具生成，签名复用当前构建变体的配置；`debug` 不触发加固。

需要通过 GitHub/JitPack 下载远程插件，请使用 [JitPack 接入说明](JITPACK.md)。下面是直接使用本地源码仓库的方式。

## 一次性接入

保留本仓库完整目录。以下示例适用于应用仓库与 `nmmp` 位于同一父目录的情况。

在应用根目录的 `settings.gradle` 已有 `pluginManagement` 块内加入：

```groovy
pluginManagement {
    includeBuild('../nmmp/nmm-protect')
    // 保留项目原来的 repositories 等配置。
}
```

在应用模块的 `app/build.gradle` 已有 `plugins` 块中加入：

```groovy
plugins {
    // 保留项目原来的 Android、Kotlin 等插件。
    id 'com.nmmedit.protect'
}
```

Kotlin DSL 对应写法为 `includeBuild("../nmmp/nmm-protect")` 和 `id("com.nmmedit.protect")`。这里通过本地 composite build 解析插件，无需填写插件版本或发布到 Maven。Gradle 会自动构建并打包加固引擎，无需另外执行 Python 命令或手动构建工具 JAR。

应用应已有有效的 release `signingConfig`。插件读取 AGP 合并后的实际变体配置，因此渠道自己的签名以及 build type 的覆盖配置都会生效，不需要把密码再填进 `nmmp` 块。签名凭据仍由项目原有的本地/CI 凭据方式提供。

## 日常使用

继续使用原来的构建命令：

```bash
./gradlew :app:assembleRelease
```

有渠道的项目继续使用对应命令，例如：

```bash
./gradlew :app:assembleDemoRelease
```

构建会自动执行 `nmmpProtectRelease` 或 `nmmpProtectDemoRelease`。加固失败时，整个构建失败。需要分发的是构建日志指向的 APK，默认目录为：

```text
app/build/outputs/nmmp/release/apk/
app/build/outputs/nmmp/demoRelease/apk/
```

这些目录包含加固 APK 和 Android 构建系统使用的 `output-metadata.json`。插件把加固结果接入正式 APK 产物接口，下游 Gradle 任务应从 `SingleArtifact.APK` 取得结果。已有 CI 若硬编码读取旧的 `build/outputs/apk` 路径，需要一次性改成上述路径，避免分发中间产物。

同一变体的 `reports/` 目录保留实际保护清单、排除原因、构建记录、日志及 native 符号。它们用于内部核对和崩溃定位，无需随 APK 分发。

## 环境与范围

首次机器配置需要 JDK 17+、Python 3.11+、Android SDK Build Tools、NDK 和 CMake。插件复用 Gradle 的 Java 和 AGP 的 SDK 路径，自动查找已安装的 Python、NDK 和 CMake；它不静默下载工具或接受 SDK 许可证。当前开发验证目标为 AGP 8.13.2、Gradle 8.14.3、JDK 21，SDK Build Tools 36.0.0、NDK 28.2.13676358、CMake 3.22.1。

此入口针对 `com.android.application` 的 `release` 构建类型及独立 APK。AAB、动态功能模块和拆分 APK 不在本次支持范围内；插件必须明确拒绝相关发布路径。其他构建类型不会默认纳入保护。原生产流程对签名轮换、多 signer、Source Stamp 和已有 native 库 16 KB 对齐的要求仍适用。

加固任务每次执行都会重新保护和校验，不使用共享构建缓存；签名密码不作为任务输入或命令行参数。带加固任务的构建即使开启 `--configuration-cache`，也会在结束时丢弃该缓存条目。这是当前读取合并签名配置的限制，验证结果见 [VALIDATION.md](VALIDATION.md)。

已有工具链需要显式固定时可以配置：

```groovy
nmmp {
    pythonExecutable = '/absolute/path/to/python3'
    ndkDirectory = file('/absolute/path/to/android-sdk/ndk/28.2.13676358')
    cmakeDirectory = file('/absolute/path/to/android-sdk/cmake/3.22.1')
}
```

纯 Java APK 可额外设置 `abis = ['arm64-v8a', 'armeabi-v7a']`；已有 native 库的 APK 必须保留原 ABI 集合。上述 `nmmp` 配置均为可选，普通接入只需前面的两处插件声明。

## 仓库自测

独立示例位于 `integration/gradle-smoke`，不依赖业务项目或真实签名。测试脚本生成一次性 fixture 密钥，运行正常 debug/release 构建及多个失败场景：

```bash
python3 integration/build_gradle_smoke.py --sdk "$ANDROID_SDK_ROOT"
```

日志及 APK 位于被 Git 忽略的 `.validation/gradle-smoke/`。业务投产前仍需使用实际 release 包完成目标设备、覆盖升级及性能验收；自动接入不替代这些验收。
