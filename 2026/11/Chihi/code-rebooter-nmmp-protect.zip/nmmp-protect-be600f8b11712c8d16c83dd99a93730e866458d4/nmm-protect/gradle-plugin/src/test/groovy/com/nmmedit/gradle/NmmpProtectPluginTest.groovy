package com.nmmedit.gradle

import org.gradle.testfixtures.ProjectBuilder
import org.gradle.testkit.runner.GradleRunner
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder

import static org.junit.Assert.*

class NmmpProtectPluginTest {
    @Rule public TemporaryFolder temporary = new TemporaryFolder()
    @Test
    void pluginCanBeAppliedBeforeAndroidAndCreatesItsExtension() {
        def project = ProjectBuilder.builder().build()
        try {
            project.pluginManager.apply('com.nmmedit.protect')
        } catch (Exception failure) {
            fail("The NMMP plugin must be available and apply successfully: ${failure.message}")
        }
        assertNotNull(project.extensions.findByName('nmmp'))
        assertNull(project.tasks.findByName('nmmpProtectDebug'))
    }

    @Test
    void realAgpWiresReleaseArtifactsAndUsesMergedFlavorSigning() {
        def directory = temporary.newFolder('android')
        new File(directory, 'settings.gradle').text = '''
pluginManagement {
    repositories { google(); mavenCentral(); gradlePluginPortal() }
    resolutionStrategy.eachPlugin {
        if (requested.id.id == 'com.android.application') useModule('com.android.tools.build:gradle:' + requested.version)
    }
}
rootProject.name = 'plugin-contract'
'''
        new File(directory, 'local.properties').text = "sdk.dir=${System.getenv('ANDROID_HOME') ?: System.getProperty('user.home') + '/Library/Android/sdk'}\n"
        new File(directory, 'build.gradle').text = '''
plugins {
    id 'com.android.application'
    id 'com.nmmedit.protect'
}
android {
    namespace 'com.example.contract'
    compileSdk 35
    defaultConfig { minSdk 23 }
    signingConfigs {
        alphaKey { storeFile file('alpha.jks'); storePassword 'alpha-store-secret'; keyAlias 'alpha'; keyPassword 'alpha-key-secret' }
        betaKey { storeFile file('beta.jks'); storePassword 'beta-store-secret'; keyAlias 'beta'; keyPassword 'beta-key-secret' }
    }
    flavorDimensions 'brand'
    productFlavors {
        alpha { dimension 'brand'; signingConfig signingConfigs.alphaKey }
        beta { dimension 'brand'; signingConfig signingConfigs.betaKey }
    }
}
nmmp { abis = ['x86_64'] }
def artifacts = [:]
androidComponents.onVariants(androidComponents.selector().withBuildType('release')) { variant ->
    artifacts[variant.name] = variant.artifacts.get(com.android.build.api.artifact.SingleArtifact.APK.INSTANCE)
}
tasks.register('checkContract') {
    doLast {
        assert tasks.findByName('nmmpProtectAlphaDebug') == null
        assert tasks.findByName('nmmpProtectBetaDebug') == null
        ['alpha', 'beta'].each { flavor ->
            def protect = tasks.findByName('nmmpProtect' + flavor.capitalize() + 'Release')
            assert protect != null : 'Release protection task must exist'
            assert protect.signingConfiguration.keyAlias == flavor
            assert protect.abis.get() == ['x86_64']
            assert !protect.compatibleWithConfigurationCache
            assert artifacts[flavor + 'Release'].get().asFile == protect.outputDirectory.get().asFile
            assert protect.outputDirectory.get().asFile.path.endsWith('/outputs/nmmp/' + flavor + 'Release/apk')
            def stale = new File(protect.outputDirectory.get().asFile, 'old.apk')
            stale.parentFile.mkdirs()
            stale.text = 'previous successful APK'
            protect.actions.first().execute(protect)
            assert !stale.exists() : 'Invalidate outputs before AGP reads potentially invalid input metadata'
            assert tasks.getByName('assemble' + flavor.capitalize() + 'Release').taskDependencies
                .getDependencies(tasks.getByName('assemble' + flavor.capitalize() + 'Release')).contains(protect)
        }
    }
}
'''
        GradleRunner.create().withProjectDir(directory).withPluginClasspath()
            .withArguments('checkContract', '--offline', '--stacktrace', '--console=plain',
                '--gradle-user-home', new File(System.getProperty('user.home'), '.gradle').absolutePath).build()
    }
}
