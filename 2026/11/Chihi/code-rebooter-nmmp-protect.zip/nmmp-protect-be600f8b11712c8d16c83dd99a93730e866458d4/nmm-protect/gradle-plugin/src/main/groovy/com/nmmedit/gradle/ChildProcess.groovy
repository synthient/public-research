package com.nmmedit.gradle

import org.gradle.api.GradleException

import java.nio.file.Files
import java.util.concurrent.TimeUnit

/** No shell, no command echo, and only redacted diagnostics leave the private capture. */
final class ChildProcess {
    static String redact(String text, Map<String, String> secrets) {
        String result = text
        secrets.values().findAll { it }.collectMany { [it] + it.readLines() }
            .findAll { it }.unique().sort { -it.length() }.each { result = result.replace(it, '[REDACTED]') }
        result
    }

    static String tail(File file) {
        if (!file.isFile()) return ''
        new RandomAccessFile(file, 'r').withCloseable { source ->
            source.seek(Math.max(0L, source.length() - 65536L))
            byte[] bytes = new byte[(int) (source.length() - source.filePointer)]
            source.readFully(bytes)
            new String(bytes, 'UTF-8')
        }
    }

    static void stop(Process process) {
        // Collect descendants before stopping the parent, including runner-created process groups.
        List<ProcessHandle> children = process.descendants().toList()
        children.reverseEach { it.destroyForcibly() }
        process.destroyForcibly()
        process.waitFor(5, TimeUnit.SECONDS)
    }

    static String run(List<String> command, Map<String, String> secrets, File log, int timeoutSeconds) {
        log.parentFile.mkdirs()
        File capture = Files.createTempFile('nmmp-process-', '.log').toFile()
        Process process = null
        String failure = null
        boolean interrupted = false
        try {
            ProcessBuilder builder = new ProcessBuilder(command.collect { it.toString() })
            builder.environment().putAll(secrets)
            builder.environment().put('JAVA_HOME', System.getProperty('java.home'))
            builder.redirectErrorStream(true).redirectOutput(capture)
            try {
                process = builder.start()
            } catch (IOException ignored) {
                throw new GradleException("Could not start ${command[0]}. Install Python 3.11+ or set nmmp.pythonExecutable to its executable")
            }
            try {
                if (!process.waitFor(timeoutSeconds, TimeUnit.SECONDS)) {
                    stop(process)
                    failure = "NMMP process timed out after ${timeoutSeconds} seconds"
                } else if (process.exitValue() != 0) {
                    failure = "NMMP process failed (exit ${process.exitValue()})"
                }
            } catch (InterruptedException ignored) {
                interrupted = true
                stop(process)
                failure = 'NMMP process interrupted'
            }
            // Preserve the complete log while keeping memory and failure messages bounded.
            log.withWriter('UTF-8') { target ->
                capture.withReader('UTF-8') { source ->
                    source.eachLine { line -> target.write(redact(line, secrets)); target.write('\n') }
                }
            }
            String output = tail(log)
            if (failure) throw new GradleException("${failure}. Log: ${log}\n${output.takeRight(4000)}")
            return output
        } finally {
            if (process?.isAlive()) stop(process)
            capture.delete()
            if (interrupted) Thread.currentThread().interrupt()
        }
    }

    static String python(String override, File directory) {
        List<String> candidates = override ? [override] : ['python3', 'python3.13', 'python3.12', 'python3.11', 'python']
        for (String executable : candidates) {
            File log = new File(directory, 'python-version.log')
            try {
                String version = run([executable, '-c', 'import sys; print("NMMP_PYTHON_OK" if sys.version_info >= (3, 11) else "NMMP_PYTHON_TOO_OLD")'], [:], log, 10)
                if (version.trim() == 'NMMP_PYTHON_OK') return executable
            } catch (GradleException ignored) {
                if (Thread.currentThread().isInterrupted()) throw ignored
            }
        }
        throw new GradleException('NMMP requires Python 3.11+. Install it on PATH or set nmmp.pythonExecutable to an installed Python 3.11+ executable' + (override ? " (configured: ${override})" : ''))
    }
}
