package com.nmmedit.gradle

import groovy.json.JsonOutput
import groovy.json.JsonSlurper
import org.gradle.api.GradleException
import org.gradle.testfixtures.ProjectBuilder
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder

import java.nio.file.Files

import static org.junit.Assert.*

class ProtectionSafetyTest {
    @Rule public TemporaryFolder temporary = new TemporaryFolder()

    Map metadata(String name = 'original.apk') {
        [version: 3, artifactType: [type: 'APK', kind: 'Directory'], applicationId: 'com.example.test',
         variantName: 'release', elements: [[type: 'SINGLE', filters: [], attributes: [], versionCode: 7,
         versionName: '1.7', outputFile: name]], baselineProfiles: [[minApi: 28, baselineProfiles: ['old.dm']]]]
    }

    File input(Map value = metadata()) {
        File directory = temporary.newFolder()
        new File(directory, 'original.apk').text = 'input fixture'
        new File(directory, 'output-metadata.json').text = JsonOutput.toJson(value)
        directory
    }

    @Test void rewritesStandaloneMetadataAndDropsOriginalDexProfileReferences() {
        File directory = input()
        def parsed = ApkMetadata.read(directory, 'release')
        File output = temporary.newFolder()
        ApkMetadata.write(parsed, output, 'app-release-protected.apk')
        Map actual = new JsonSlurper().parse(new File(output, 'output-metadata.json')) as Map
        assertEquals('app-release-protected.apk', actual.elements[0].outputFile)
        assertEquals(7, actual.elements[0].versionCode)
        assertEquals('com.example.test', actual.applicationId)
        assertFalse(actual.containsKey('baselineProfiles'))
        assertEquals('original.apk', new JsonSlurper().parse(new File(directory, 'output-metadata.json')).elements[0].outputFile)
    }

    @Test void rejectsSplitOutputsAndEscapingOrMissingApks() {
        [metadata('../outside.apk'), metadata('/tmp/outside.apk'), metadata('nested/outside.apk'),
         metadata('C:\\outside.apk'), metadata('missing.apk')].each { value ->
            assertThrows(GradleException) { ApkMetadata.read(input(value), 'release') }
        }
        Map splits = metadata()
        splits.elements << new LinkedHashMap(splits.elements[0])
        assertThrows(GradleException) { ApkMetadata.read(input(splits), 'release') }
        Map filtered = metadata()
        filtered.elements[0].filters = [[filterType: 'ABI', value: 'x86_64']]
        assertThrows(GradleException) { ApkMetadata.read(input(filtered), 'release') }
    }

    @Test void rejectsSymlinkApkAndWrongVariant() {
        File directory = input()
        new File(directory, 'original.apk').delete()
        Files.createSymbolicLink(new File(directory, 'original.apk').toPath(), temporary.newFile('outside.apk').toPath())
        assertThrows(GradleException) { ApkMetadata.read(directory, 'release') }
        assertThrows(GradleException) { ApkMetadata.read(input(), 'otherRelease') }
    }

    @Test void missingSigningClearsPreviousSuccessfulArtifactOnEveryAttempt() {
        def project = ProjectBuilder.builder().withProjectDir(temporary.newFolder()).build()
        def task = project.tasks.create('protect', ProtectApkTask)
        task.variantName.set('release')
        task.inputDirectory.set(input())
        task.outputDirectory.set(new File(project.buildDir, 'protected'))
        task.reportsDirectory.set(new File(project.buildDir, 'reports'))
        File stale = new File(task.outputDirectory.get().asFile, 'app-release-protected.apk')
        stale.parentFile.mkdirs()
        stale.text = 'stale output'
        def error = assertThrows(GradleException) { task.protect() }
        assertTrue(error.message.contains('signingConfig'))
        assertFalse(stale.exists())
        stale.parentFile.mkdirs()
        stale.text = 'another stale output'
        assertThrows(GradleException) { task.protect() }
        assertFalse(stale.exists())
        assertFalse(task.compatibleWithConfigurationCache)
    }

    @Test void passesSecretsOnlyInEnvironmentAndRedactsFailureLogs() {
        File script = temporary.newFile('child.py')
        script.text = '''import os, sys
print(os.environ['NMMP_STORE_PASSWORD'])
print(os.environ['NMMP_KEY_PASSWORD'])
sys.exit(13)
'''
        File log = temporary.newFile('runner.log')
        List command = ['python3', script.absolutePath]
        Map secrets = ['NMMP_STORE_PASSWORD': 'distinct-store-secret', 'NMMP_KEY_PASSWORD': 'distinct-key-secret']
        def error = assertThrows(GradleException) { ChildProcess.run(command, secrets, log, 10) }
        assertTrue(error.message.contains('13'))
        assertFalse(error.message.contains('distinct-store-secret'))
        assertFalse(log.text.contains('distinct-store-secret'))
        assertFalse(log.text.contains('distinct-key-secret'))
        assertFalse(command.join(' ').contains('secret'))
    }

    @Test void killsTimedOutChildAndReportsMissingExecutable() {
        File script = temporary.newFile('slow.py')
        script.text = 'import time\ntime.sleep(30)\n'
        File log = temporary.newFile('slow.log')
        long started = System.nanoTime()
        def error = assertThrows(GradleException) { ChildProcess.run(['python3', script.absolutePath], [:], log, 1) }
        assertTrue(error.message.contains('timed out'))
        assertTrue((System.nanoTime() - started) / 1e9 < 10)
        def missing = assertThrows(GradleException) { ChildProcess.run(['/missing/nmmp-python'], [:], log, 1) }
        assertTrue(missing.message.contains('Could not start'))
    }

    @Test void publishesOnlyCheckedResultAndRemovesItWhenNextRunnerFails() {
        def project = ProjectBuilder.builder().withProjectDir(temporary.newFolder()).build()
        def task = project.tasks.create('protect', ProtectApkTask)
        task.variantName.set('release')
        task.inputDirectory.set(input())
        task.outputDirectory.set(new File(project.buildDir, 'protected'))
        task.reportsDirectory.set(new File(project.buildDir, 'reports'))
        task.sdkDirectory.set(temporary.newFolder())
        task.signingConfiguration = [storeFile: temporary.newFile('test.jks'), storePassword: 'store-fixture-secret',
                                     keyAlias: 'fixture', keyPassword: 'key-fixture-secret']
        File python = temporary.newFile('fake-python')
        python.text = '''#!/usr/bin/env python3
import hashlib, json, os, pathlib, sys
if '-c' in sys.argv:
    print('NMMP_PYTHON_OK')
    sys.exit(0)
args = sys.argv
assert '--abis' not in args, 'Default ABI selection must defer to the runner and preserve existing native ABIs'
assert os.environ['NMMP_STORE_PASSWORD'] == 'store-fixture-secret'
assert os.environ['NMMP_KEY_PASSWORD'] == 'key-fixture-secret'
assert not any('fixture-secret' in arg for arg in args)
source = pathlib.Path(args[args.index('--input') + 1])
result = pathlib.Path(args[args.index('--output') + 1])
result.mkdir()
apk = result / 'app.apk'
apk.write_bytes(b'checked result')
(result / 'release.json').write_text(json.dumps({'schema_version': 1,
    'input_sha256': hashlib.sha256(source.read_bytes()).hexdigest(),
    'output_sha256': hashlib.sha256(apk.read_bytes()).hexdigest()}))
(result / 'build.log').write_text('safe fixture log')
'''
        assertTrue(python.setExecutable(true))
        task.pythonExecutable.set(python.absolutePath)
        task.protect()
        File output = new File(task.outputDirectory.get().asFile, 'app-release-protected.apk')
        assertEquals('checked result', output.text)
        assertTrue(new File(task.reportsDirectory.get().asFile, 'release.json').isFile())
        assertFalse(new File(task.reportsDirectory.get().asFile, 'app.apk').exists())
        python.text = python.text.replace('args = sys.argv', "print(os.environ['NMMP_STORE_PASSWORD']); sys.exit(23)\nargs = sys.argv")
        def error = assertThrows(GradleException) { task.protect() }
        assertTrue(error.message.contains('exit 23'))
        assertFalse(error.message.contains('store-fixture-secret'))
        assertFalse(output.exists())
        assertFalse(new File(task.reportsDirectory.get().asFile, 'release.json').exists())
        assertTrue(java.lang.reflect.Modifier.isTransient(ProtectApkTask.getDeclaredField('signingConfiguration').modifiers))
        assertNotNull(ProtectApkTask.getMethod('getSigningConfiguration').getAnnotation(org.gradle.api.tasks.Internal))
    }
}
