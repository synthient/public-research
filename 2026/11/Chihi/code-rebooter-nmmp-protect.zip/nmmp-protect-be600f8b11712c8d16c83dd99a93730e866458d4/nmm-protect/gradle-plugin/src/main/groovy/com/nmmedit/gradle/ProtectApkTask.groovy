package com.nmmedit.gradle

import groovy.json.JsonSlurper
import org.gradle.api.DefaultTask
import org.gradle.api.GradleException
import org.gradle.api.file.DirectoryProperty
import org.gradle.api.provider.ListProperty
import org.gradle.api.provider.Property
import org.gradle.api.tasks.*
import org.gradle.work.DisableCachingByDefault

import java.nio.file.Files
import java.nio.file.Path
import java.nio.file.StandardCopyOption
import java.security.MessageDigest
import com.android.build.api.artifact.ArtifactTransformationRequest

@DisableCachingByDefault(because = 'Signing credentials stay in memory and every protected release must be verified again')
abstract class ProtectApkTask extends DefaultTask {
    @InputFiles @PathSensitive(PathSensitivity.RELATIVE)
    abstract DirectoryProperty getInputDirectory()
    @OutputDirectory abstract DirectoryProperty getOutputDirectory()
    @OutputDirectory abstract DirectoryProperty getReportsDirectory()
    @Internal abstract DirectoryProperty getSdkDirectory()
    @Internal abstract DirectoryProperty getNdkDirectory()
    @Internal abstract DirectoryProperty getCmakeDirectory()
    @Input @Optional abstract Property<String> getPythonExecutable()
    @Input abstract Property<String> getVariantName()
    @Input abstract ListProperty<String> getAbis()
    @Input abstract Property<Integer> getMinimumMethods()
    @Input abstract Property<Integer> getTimeoutSeconds()
    @Input abstract Property<Boolean> getHasDynamicFeatures()

    // Neither task snapshots nor the configuration-cache serializer may persist this object.
    private transient Object signingConfiguration
    @Internal Object getSigningConfiguration() { signingConfiguration }
    void setSigningConfiguration(Object value) { signingConfiguration = value }
    @Internal ArtifactTransformationRequest<ProtectApkTask> transformationRequest

    ProtectApkTask() {
        abis.convention([])
        minimumMethods.convention(1)
        timeoutSeconds.convention(900)
        hasDynamicFeatures.convention(false)
        outputs.upToDateWhen { false }
        outputs.doNotCacheIf('Release signing and verification must run for every request') { true }
        notCompatibleWithConfigurationCache('NMMP uses the in-memory merged AGP signingConfig; credentials must not be serialized')
    }

    static void removeTree(File directory) {
        if (!Files.exists(directory.toPath(), java.nio.file.LinkOption.NOFOLLOW_LINKS)) return
        Files.walk(directory.toPath()).withCloseable { paths ->
            paths.sorted(Comparator.reverseOrder()).forEach { Files.delete(it) }
        }
    }

    static String digest(File file) {
        MessageDigest hash = MessageDigest.getInstance('SHA-256')
        file.withInputStream { stream ->
            byte[] buffer = new byte[65536]
            int count
            while ((count = stream.read(buffer)) != -1) hash.update(buffer, 0, count)
        }
        hash.digest().encodeHex().toString()
    }

    private Map<String, String> signingSecrets() {
        Object signing = signingConfiguration
        if (signing == null || signing.storeFile == null || !signing.storeFile.isFile() ||
            signing.storePassword == null || !signing.keyAlias || signing.keyPassword == null) {
            throw new GradleException("NMMP ${variantName.get()} requires a complete existing Android signingConfig (storeFile, storePassword, keyAlias and keyPassword). Configure release signing in android; do not repeat credentials in nmmp")
        }
        ['NMMP_STORE_PASSWORD': signing.storePassword.toString(), 'NMMP_KEY_PASSWORD': signing.keyPassword.toString()]
    }

    private void unpack(File runtime) {
        runtime.mkdirs()
        ['vm-protect.jar', 'production_protect.py', 'apk_validation.py', 'VerifySigningPolicy.java'].each { name ->
            InputStream source = ProtectApkTask.classLoader.getResourceAsStream('nmmp-runtime/' + name)
            if (source == null) throw new GradleException("NMMP plugin distribution is missing bundled ${name}; rebuild or reinstall the plugin")
            source.withCloseable { Files.copy(it, new File(runtime, name).toPath()) }
        }
    }

    private void copyReports(File source, File destination, Map<String, String> secrets) {
        if (!source.isDirectory()) return
        Files.walk(source.toPath()).withCloseable { paths ->
            paths.forEach { Path path ->
                Path relative = source.toPath().relativize(path)
                if (!relative.toString() || relative.toString() == 'app.apk') return
                if (Files.isSymbolicLink(path)) throw new GradleException('NMMP runner output unexpectedly contains a symbolic link')
                File target = new File(destination, relative.toString())
                if (Files.isDirectory(path)) {
                    target.mkdirs()
                } else {
                    target.parentFile.mkdirs()
                    if (path.fileName.toString().endsWith('.log')) {
                        target.withWriter('UTF-8') { writer ->
                            path.toFile().eachLine('UTF-8') { line -> writer.write(ChildProcess.redact(line, secrets)); writer.write('\n') }
                        }
                    } else {
                        Files.copy(path, target.toPath(), StandardCopyOption.REPLACE_EXISTING)
                    }
                }
            }
        }
    }

    void rewriteMetadata() {
        File output = outputDirectory.get().asFile
        try {
            ApkMetadata.write(ApkMetadata.read(inputDirectory.get().asFile, variantName.get()), output,
                'app-' + variantName.get() + '-protected.apk')
        } catch (Exception failure) {
            removeTree(output)
            throw failure
        }
    }

    void invalidateOutputs() {
        removeTree(outputDirectory.get().asFile)
        removeTree(reportsDirectory.get().asFile)
        reportsDirectory.get().asFile.mkdirs()
    }

    @TaskAction
    void protect() {
        File output = outputDirectory.get().asFile
        File reports = reportsDirectory.get().asFile
        // Invalidate the previous release before signing, metadata, or prerequisite checks.
        invalidateOutputs()
        File work = null
        Map<String, String> secrets = [:]
        try {
            secrets = signingSecrets()
            if (hasDynamicFeatures.get()) throw new GradleException('NMMP does not support dynamic feature modules; use a standalone application APK')
            if (timeoutSeconds.get() <= 0 || minimumMethods.get() <= 0) {
                throw new GradleException('nmmp.timeoutSeconds and nmmp.minimumMethods must be positive')
            }
            if (!(['armeabi-v7a', 'arm64-v8a', 'x86', 'x86_64'].containsAll(abis.get()))) {
                throw new GradleException('nmmp.abis must contain supported Android ABIs: armeabi-v7a, arm64-v8a, x86, x86_64')
            }
            Map metadata = ApkMetadata.read(inputDirectory.get().asFile, variantName.get())
            File input = new File(inputDirectory.get().asFile, metadata.elements[0].outputFile as String)
            temporaryDir.mkdirs()
            work = Files.createTempDirectory(temporaryDir.toPath(), 'private-').toFile()
            File runtime = new File(work, 'runtime')
            unpack(runtime)
            String python = ChildProcess.python(pythonExecutable.orNull, work)
            File result = new File(work, 'result')
            String java = new File(System.getProperty('java.home'), 'bin/' + (System.getProperty('os.name').startsWith('Windows') ? 'java.exe' : 'java')).absolutePath
            List<String> command = [python, new File(runtime, 'production_protect.py').absolutePath,
                '--input', input.absolutePath, '--output', result.absolutePath,
                '--tool', new File(runtime, 'vm-protect.jar').absolutePath,
                '--sdk', sdkDirectory.get().asFile.absolutePath,
                '--keystore', signingConfiguration.storeFile.absolutePath,
                '--alias', signingConfiguration.keyAlias.toString(),
                '--ks-pass-env', 'NMMP_STORE_PASSWORD', '--key-pass-env', 'NMMP_KEY_PASSWORD',
                '--java', java, '--min-methods', minimumMethods.get().toString(),
                '--timeout', timeoutSeconds.get().toString()]
            if (ndkDirectory.present) command.addAll(['--ndk', ndkDirectory.get().asFile.absolutePath])
            if (cmakeDirectory.present) command.addAll(['--cmake', cmakeDirectory.get().asFile.absolutePath])
            if (!abis.get().isEmpty()) {
                command.add('--abis')
                command.addAll(abis.get())
            }
            // The runner gives each external tool its own timeout. Bound the whole pipeline too.
            ChildProcess.run(command, secrets, new File(reports, 'runner.log'), Math.multiplyExact(timeoutSeconds.get(), 12))
            File checkedApk = new File(result, 'app.apk')
            File manifest = new File(result, 'release.json')
            if (!checkedApk.isFile() || !manifest.isFile()) throw new GradleException('NMMP runner did not publish a verified APK and release report')
            Map release = new JsonSlurper().parse(manifest, 'UTF-8') as Map
            if (release.schema_version != 1 || release.input_sha256 != digest(input) || release.output_sha256 != digest(checkedApk)) {
                throw new GradleException('NMMP verified release report does not match the input and protected APK')
            }
            copyReports(result, reports, secrets)
            output.mkdirs()
            String name = 'app-' + variantName.get() + '-protected.apk'
            Files.copy(checkedApk.toPath(), new File(output, name).toPath())
            ApkMetadata.write(metadata, output, name)
            transformationRequest?.submit(this, { artifact -> new File(output, name) })
            logger.lifecycle("NMMP protected APK: ${new File(output, name)}")
        } catch (Exception failure) {
            removeTree(output)
            // The immutable runner may emit diagnostics alongside its rejected result.
            if (work != null) {
                File diagnostics = new File(reports, 'diagnostics')
                work.listFiles()?.findAll { it.isFile() && it.name.contains('.failed-') }?.each { file ->
                    diagnostics.mkdirs()
                    String safe = ChildProcess.redact(file.getText('UTF-8'), secrets)
                    new File(diagnostics, file.name).setText(safe, 'UTF-8')
                }
            }
            String detail = ChildProcess.redact(failure.message ?: failure.class.simpleName, secrets)
            throw new GradleException("NMMP protection failed for ${variantName.get()}: ${detail}\nDiagnostics: ${reports}")
        } finally {
            if (work != null) removeTree(work)
        }
    }
}
