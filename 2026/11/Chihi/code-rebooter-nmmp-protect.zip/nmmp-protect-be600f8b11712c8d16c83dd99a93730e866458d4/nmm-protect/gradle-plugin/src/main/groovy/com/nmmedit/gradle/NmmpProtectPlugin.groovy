package com.nmmedit.gradle

import org.gradle.api.Plugin
import org.gradle.api.Project
import org.gradle.api.Action
import org.gradle.api.GradleException
import com.android.build.api.artifact.SingleArtifact
import com.android.build.api.variant.ApplicationAndroidComponentsExtension
import com.android.build.gradle.AppExtension

class NmmpProtectPlugin implements Plugin<Project> {
    void apply(Project project) {
        NmmpExtension extension = project.extensions.create('nmmp', NmmpExtension)
        project.pluginManager.withPlugin('com.android.application') {
            def components = project.extensions.getByType(ApplicationAndroidComponentsExtension)
            if (components.pluginVersion.major != 8) {
                throw new GradleException('NMMP supports Android Gradle Plugin 8; validated with AGP 8.13.2, Gradle 8.14.3 and JDK 17+')
            }
            AppExtension android = project.extensions.getByType(AppExtension)
            Map<String, Object> signing = [:]
            android.applicationVariants.all { legacy ->
                signing[legacy.name] = legacy.signingConfig
                project.tasks.withType(ProtectApkTask).configureEach { task ->
                    if (task.variantName.get() == legacy.name) task.signingConfiguration = legacy.signingConfig
                }
            }
            components.onVariants(components.selector().withBuildType('release'), { variant ->
                String capitalized = variant.name.substring(0, 1).toUpperCase(Locale.ROOT) + variant.name.substring(1)
                def protect = project.tasks.register('nmmpProtect' + capitalized, ProtectApkTask) { task ->
                    task.group = 'build'
                    task.description = "Protect and verify the ${variant.name} APK using the existing Android signing configuration"
                    task.variantName.set(variant.name)
                    task.signingConfiguration = signing[variant.name]
                    task.sdkDirectory.set(components.sdkComponents.sdkDirectory)
                    task.pythonExecutable.set(extension.pythonExecutable)
                    task.ndkDirectory.set(extension.ndkDirectory)
                    task.cmakeDirectory.set(extension.cmakeDirectory)
                    task.abis.set(extension.abis)
                    task.minimumMethods.set(extension.minimumMethods)
                    task.timeoutSeconds.set(extension.timeoutSeconds)
                    task.hasDynamicFeatures.set(!android.dynamicFeatures.isEmpty())
                    task.outputDirectory.set(project.layout.buildDirectory.dir("outputs/nmmp/${variant.name}/apk"))
                    task.reportsDirectory.set(project.layout.buildDirectory.dir("outputs/nmmp/${variant.name}/reports"))
                }
                def transformation = variant.artifacts.use(protect)
                    .wiredWithDirectories({ task -> task.inputDirectory }, { task -> task.outputDirectory })
                    .toTransformMany(SingleArtifact.APK.INSTANCE)
                protect.configure { task ->
                    task.transformationRequest = transformation
                    // AGP assigns a default output path while registering the transform.
                    task.outputDirectory.set(project.layout.buildDirectory.dir("outputs/nmmp/${variant.name}/apk"))
                    task.doFirst { task.invalidateOutputs() }
                    // AGP writes its metadata in doLast; then remove profiles tied to the old DEX.
                    task.doLast { task.rewriteMetadata() }
                }
                def rejectBundle = project.tasks.register('nmmpReject' + capitalized + 'Bundle', RejectBundleTask) { task ->
                    task.description = "Reject unsupported ${variant.name} Android App Bundle consumers"
                    task.assembleTaskName.set('assemble' + capitalized)
                }
                variant.artifacts.use(rejectBundle)
                    .wiredWithFiles({ task -> task.inputBundle }, { task -> task.outputBundle })
                    .toTransform(SingleArtifact.BUNDLE.INSTANCE)
                project.tasks.configureEach { task ->
                    if (task.name == 'assemble' + capitalized) task.dependsOn(protect)
                    if (task.name in ['bundle' + capitalized, 'sign' + capitalized + 'Bundle']) {
                        task.doFirst {
                            throw new GradleException(RejectBundleTask.unsupportedMessage('assemble' + capitalized))
                        }
                    }
                }
            } as Action)
        }
        project.afterEvaluate {
            if (!project.plugins.hasPlugin('com.android.application')) {
                throw new GradleException('Apply com.nmmedit.protect to an Android application module with com.android.application')
            }
        }
    }
}
