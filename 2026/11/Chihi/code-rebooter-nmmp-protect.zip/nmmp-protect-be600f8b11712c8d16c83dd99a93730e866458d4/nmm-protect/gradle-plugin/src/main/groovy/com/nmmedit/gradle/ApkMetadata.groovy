package com.nmmedit.gradle

import groovy.json.JsonOutput
import groovy.json.JsonSlurper
import org.gradle.api.GradleException

import java.nio.file.Files

/** Handles the standalone subset of AGP's version 3 APK metadata. */
final class ApkMetadata {
    static Map read(File directory, String variant) {
        File metadata = new File(directory, 'output-metadata.json')
        def value
        try {
            value = new JsonSlurper().parse(metadata, 'UTF-8')
        } catch (Exception ignored) {
            throw new GradleException("NMMP requires valid AGP output-metadata.json in ${directory}")
        }
        if (!(value instanceof Map) || value.version != 3 || value.artifactType?.type != 'APK' ||
            value.artifactType?.kind != 'Directory' || !(value.applicationId instanceof String) ||
            !value.applicationId || value.variantName != variant) {
            throw new GradleException("NMMP requires version 3 APK metadata for variant ${variant}")
        }
        if (!(value.elements instanceof List) || value.elements.size() != 1) {
            throw new GradleException('NMMP supports one standalone APK; split or multiple APK outputs are unsupported')
        }
        def element = value.elements[0]
        if (!(element instanceof Map) || !(element.type in ['SINGLE', 'UNIVERSAL']) ||
            element.filters != [] || !(element.versionCode instanceof Number)) {
            throw new GradleException('NMMP supports SINGLE or UNIVERSAL standalone APK metadata without split filters')
        }
        String name = element.outputFile
        if (!name || !name.endsWith('.apk') || name.contains('/') || name.contains('\\') ||
            name.contains(':') || name == '..' || new File(name).isAbsolute()) {
            throw new GradleException('NMMP APK metadata must reference a safe APK basename in its input directory')
        }
        File apk = new File(directory, name)
        if (!apk.isFile() || Files.isSymbolicLink(apk.toPath()) || apk.canonicalFile.parentFile != directory.canonicalFile) {
            throw new GradleException("NMMP input APK is missing or escapes the artifact directory: ${name}")
        }
        return value as Map
    }

    static void write(Map input, File directory, String name) {
        // Round-trip so the caller's AGP metadata is never mutated.
        Map result = new JsonSlurper().parseText(JsonOutput.toJson(input)) as Map
        result.remove('baselineProfiles')
        result.elements.each {
            it.remove('baselineProfiles')
            it.outputFile = name
        }
        directory.mkdirs()
        new File(directory, 'output-metadata.json').setText(JsonOutput.prettyPrint(JsonOutput.toJson(result)) + '\n', 'UTF-8')
    }
}
