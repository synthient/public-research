package com.nmmedit.gradle

import org.gradle.testkit.runner.GradleRunner
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder

import static org.junit.Assert.*

class BundleRejectionTest {
    @Rule public TemporaryFolder temporary = new TemporaryFolder()

    private File fixture() {
        File directory = temporary.newFolder('bundle')
        new File(directory, 'settings.gradle').text = "rootProject.name = 'bundle-contract'\n"
        new File(directory, 'local.properties').text = "sdk.dir=${System.getenv('ANDROID_HOME') ?: System.getProperty('user.home') + '/Library/Android/sdk'}\n"
        new File(directory, 'build.gradle').text = '''
plugins {
    id 'com.android.application'
    id 'com.nmmedit.protect'
}
repositories { google(); mavenCentral() }
android {
    namespace 'com.example.bundlecontract'
    compileSdk 36
    defaultConfig { minSdk 23; versionCode 1; versionName '1.0' }
}
androidComponents.onVariants(androidComponents.selector().withBuildType('release')) { variant ->
    def bundle = variant.artifacts.get(com.android.build.api.artifact.SingleArtifact.BUNDLE.INSTANCE)
    tasks.register('consumeReleaseBundle') {
        inputs.file(bundle)
        doLast { println 'NMMP_TEST_UNPROTECTED_BUNDLE=' + bundle.get().asFile }
    }
}
'''
        File manifest = new File(directory, 'src/main/AndroidManifest.xml')
        manifest.parentFile.mkdirs()
        manifest.text = '<manifest xmlns:android="http://schemas.android.com/apk/res/android"><application android:label="Bundle test" /></manifest>'
        directory
    }

    private GradleRunner runner(File directory, String... arguments) {
        GradleRunner.create().withProjectDir(directory).withPluginClasspath()
            .withArguments(arguments.toList() + ['--offline', '--stacktrace', '--console=plain',
                '--gradle-user-home', new File(System.getProperty('user.home'), '.gradle').absolutePath])
    }

    @Test void officialBundleConsumerCannotPublishAnUnprotectedRelease() {
        File directory = fixture()
        def result = runner(directory, 'consumeReleaseBundle').buildAndFail()
        assertTrue(result.output.contains('Android App Bundle (AAB) protection is unsupported'))
        assertFalse(result.output.contains('NMMP_TEST_UNPROTECTED_BUNDLE='))

        // The public artifact itself must be guarded even if the upstream signing task is excluded.
        def artifact = runner(directory, 'consumeReleaseBundle', '--exclude-task', 'signReleaseBundle').buildAndFail()
        assertTrue(artifact.output.contains(':nmmpRejectReleaseBundle FAILED'))
        assertTrue(artifact.output.contains('Android App Bundle (AAB) protection is unsupported'))
        assertFalse(artifact.output.contains('NMMP_TEST_UNPROTECTED_BUNDLE='))
    }

    @Test void directBundleSigningCannotBypassTheLifecycleGuard() {
        def result = runner(fixture(), 'signReleaseBundle').buildAndFail()
        assertTrue(result.output.contains('Android App Bundle (AAB) protection is unsupported'))
    }
}
