package com.nmmedit.gradle

import org.gradle.api.file.DirectoryProperty
import org.gradle.api.model.ObjectFactory
import org.gradle.api.provider.ListProperty
import org.gradle.api.provider.Property

import javax.inject.Inject

abstract class NmmpExtension {
    abstract Property<String> getPythonExecutable()
    abstract DirectoryProperty getNdkDirectory()
    abstract DirectoryProperty getCmakeDirectory()
    abstract ListProperty<String> getAbis()
    abstract Property<Integer> getMinimumMethods()
    abstract Property<Integer> getTimeoutSeconds()

    @Inject
    NmmpExtension(ObjectFactory objects) {
        // An omitted override lets the runner retain existing native ABIs, or use all four for Java-only APKs.
        abis.convention([])
        minimumMethods.convention(1)
        timeoutSeconds.convention(900)
    }
}
