package com.nmmedit.gradle

import org.gradle.api.DefaultTask
import org.gradle.api.GradleException
import org.gradle.api.file.RegularFileProperty
import org.gradle.api.provider.Property
import org.gradle.api.tasks.Input
import org.gradle.api.tasks.InputFiles
import org.gradle.api.tasks.OutputFile
import org.gradle.api.tasks.PathSensitive
import org.gradle.api.tasks.PathSensitivity
import org.gradle.api.tasks.TaskAction
import org.gradle.work.DisableCachingByDefault

import java.nio.file.Files

/** Rejects official BUNDLE consumers as well as the usual bundle lifecycle task. */
@DisableCachingByDefault(because = 'Unsupported release bundles must always fail')
abstract class RejectBundleTask extends DefaultTask {
    // InputFiles retains the producer dependency but also lets us reject when signing was excluded.
    @InputFiles @PathSensitive(PathSensitivity.NONE)
    abstract RegularFileProperty getInputBundle()
    @OutputFile abstract RegularFileProperty getOutputBundle()
    @Input abstract Property<String> getAssembleTaskName()

    RejectBundleTask() {
        outputs.upToDateWhen { false }
        outputs.doNotCacheIf('No unsupported release bundle may be restored from a cache') { true }
    }

    static String unsupportedMessage(String assembleTask) {
        'NMMP supports standalone release APKs only; Android App Bundle (AAB) protection is unsupported. Use ' + assembleTask
    }

    @TaskAction
    void reject() {
        Files.deleteIfExists(outputBundle.get().asFile.toPath())
        throw new GradleException(unsupportedMessage(assembleTaskName.get()))
    }
}
