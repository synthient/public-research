package com.nmmedit.apkprotect;

import com.android.zipflinger.*;
import java.io.File;
import java.io.IOException;
import java.util.zip.Deflater;
import java.util.regex.Pattern;

/** APK storage policy shared by new and pre-existing native libraries. */
public final class ApkPackaging {
    public static final int NATIVE_ALIGNMENT = 16 * 1024;
    private static final Pattern REPLACED = Pattern.compile(
            "classes[0-9]*\\.dex|META-INF/[^/]+\\.(?i:RSA|DSA|EC|SF|MF)|AndroidManifest\\.xml");
    private ApkPackaging() {}

    public static void copyResources(ZipMap input, ZipArchive output) throws IOException {
        ZipSource copy = new ZipSource(input);
        for (String name : input.getEntries().keySet()) {
            if (REPLACED.matcher(name).matches()) continue;
            boolean nativeLibrary = name.startsWith("lib/") && name.endsWith(".so");
            copy.select(name, name, nativeLibrary ? Deflater.NO_COMPRESSION : ZipSource.COMPRESSION_NO_CHANGE,
                    nativeLibrary ? NATIVE_ALIGNMENT : 4);
        }
        output.add(copy);
    }

    public static void addNativeLibrary(ZipArchive output, File library, String abi) throws IOException {
        Source source = Sources.from(library, "lib/" + abi + "/" + library.getName(), Deflater.NO_COMPRESSION);
        source.align(NATIVE_ALIGNMENT);
        output.add(source);
    }
}
