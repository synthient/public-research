package com.nmmedit.apkprotect.util;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.TemporaryFolder;
import java.io.*;
import java.nio.file.Files;
import java.util.zip.*;
import static org.junit.Assert.*;
public class ApkUtilsTest {
    @Rule public TemporaryFolder temporary = new TemporaryFolder();
    private File zip(String entry) throws Exception {
        File zip = temporary.newFile();
        try (ZipOutputStream out = new ZipOutputStream(new FileOutputStream(zip))) {
            out.putNextEntry(new ZipEntry(entry)); out.write(new byte[]{1,2,3}); out.closeEntry();
        }
        return zip;
    }
    @Test public void rejectsPathTraversal() throws Exception {
        File out = temporary.newFolder(); File zip = zip("../escape");
        assertThrows(IOException.class, () -> ApkUtils.extractFiles(zip, ".*", out));
        assertFalse(new File(out.getParent(), "escape").exists());
    }
    @Test public void rejectsSymlinkParent() throws Exception {
        File out = temporary.newFolder(); File outside = temporary.newFolder();
        Files.createSymbolicLink(out.toPath().resolve("linked"), outside.toPath());
        File zip = zip("linked/escape");
        assertThrows(IOException.class, () -> ApkUtils.extractFiles(zip, ".*", out));
        assertFalse(new File(outside, "escape").exists());
    }
    @Test public void extractsValidNestedEntry() throws Exception {
        File out = temporary.newFolder();
        assertEquals(1, ApkUtils.extractFiles(zip("nested/file"), ".*", out).size());
        assertArrayEquals(new byte[]{1,2,3}, Files.readAllBytes(new File(out,"nested/file").toPath()));
    }
    @Test public void directoryEntriesDoNotBecomeRegularFiles() throws Exception {
        File archive=temporary.newFile(), out=temporary.newFolder();
        try(ZipOutputStream zip=new ZipOutputStream(new FileOutputStream(archive))) {
            zip.putNextEntry(new ZipEntry("nested/")); zip.closeEntry();
            zip.putNextEntry(new ZipEntry("nested/file")); zip.write(1); zip.closeEntry();
        }
        assertEquals(1,ApkUtils.extractFiles(archive,".*",out).size());
        assertTrue(new File(out,"nested").isDirectory());
    }
}
