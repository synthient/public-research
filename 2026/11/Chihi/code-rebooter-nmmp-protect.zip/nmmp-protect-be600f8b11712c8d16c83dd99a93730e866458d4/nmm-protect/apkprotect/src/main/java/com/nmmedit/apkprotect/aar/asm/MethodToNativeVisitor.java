package com.nmmedit.apkprotect.aar.asm;

import org.objectweb.asm.ClassVisitor;
import org.objectweb.asm.MethodVisitor;
import org.objectweb.asm.Opcodes;
import org.objectweb.asm.Type;

import java.util.List;
import java.util.Map;

/**
 * 把需要转换的方法标识为native，去掉字节码部分
 */
public class MethodToNativeVisitor extends ClassVisitor {
    private final Map<AsmMethod, List<AsmMethod>> convertedMethods;
    private String className;
    private boolean isInterface;

    public MethodToNativeVisitor(int api,
                                 ClassVisitor classVisitor,
                                 Map<AsmMethod, List<AsmMethod>> convertedMethods) {
        super(api, classVisitor);
        this.convertedMethods = convertedMethods;
    }

    @Override
    public void visit(int version, int access, String name, String signature, String superName, String[] interfaces) {
        className = name;
        isInterface = (access & Opcodes.ACC_INTERFACE) != 0;
        super.visit(version, access, name, signature, superName, interfaces);
    }

    @Override
    public MethodVisitor visitMethod(int access, String name, String descriptor, String signature, String[] exceptions) {
        if (name.startsWith("<") || (access & (Opcodes.ACC_NATIVE | Opcodes.ACC_ABSTRACT)) != 0) {
            return super.visitMethod(access, name, descriptor, signature, exceptions);
        }
        final List<AsmMethod> myMethods = convertedMethods.get(new AsmMethod(access, name, descriptor));
        if (myMethods == null || myMethods.isEmpty()) {
            return super.visitMethod(access, name, descriptor, signature, exceptions);
        }
        if (isInterface) {
            throw new IllegalStateException("Cannot convert an interface method to native: "
                    + className + "." + name + descriptor);
        }
        if (myMethods.size() > 2) {
            throw new IllegalStateException("Unexpected converted method count for " + name + descriptor);
        }
        final AsmMethod target = myMethods.size() == 2 ? myMethods.get(1) : null;
        if (target != null) {
            if (!descriptor.equals(target.descriptor) || name.equals(target.name)
                    || (access & Opcodes.ACC_STATIC) != (target.access & Opcodes.ACC_STATIC)
                    || (target.access & Opcodes.ACC_PRIVATE) == 0) {
                throw new IllegalStateException("Invalid native wrapper target for " + name + descriptor);
            }
            MethodVisitor nativeMethod = super.visitMethod(target.access | Opcodes.ACC_NATIVE,
                    target.name, target.descriptor, null, null);
            if (nativeMethod != null) nativeMethod.visitEnd();
        }
        final MethodVisitor output = super.visitMethod(target == null ? access | Opcodes.ACC_NATIVE : access,
                name, descriptor, signature, exceptions);
        if (output == null) return null;
        // Forward declaration metadata, including method/parameter/type annotations, but discard
        // the old Code attribute and its frames, exception table, local variables and annotations.
        return new MethodVisitor(api, output) {
            @Override public void visitCode() { mv = null; }

            @Override public void visitEnd() {
                if (target != null) genCall(output, access, target);
                output.visitEnd();
            }
        };
    }

    private void genCall(MethodVisitor mv, int access, AsmMethod target) {
        boolean isStatic = (access & Opcodes.ACC_STATIC) != 0;
        mv.visitCode();
        int slot = 0;
        if (!isStatic) mv.visitVarInsn(Opcodes.ALOAD, slot++);
        for (Type argument : Type.getArgumentTypes(target.descriptor)) {
            mv.visitVarInsn(argument.getOpcode(Opcodes.ILOAD), slot);
            slot += argument.getSize();
        }
        mv.visitMethodInsn(isStatic ? Opcodes.INVOKESTATIC : Opcodes.INVOKESPECIAL,
                className, target.name, target.descriptor, false);
        Type returnType = Type.getReturnType(target.descriptor);
        mv.visitInsn(returnType.getOpcode(Opcodes.IRETURN));
        mv.visitMaxs(Math.max(slot, returnType.getSize()), slot);
    }
}
