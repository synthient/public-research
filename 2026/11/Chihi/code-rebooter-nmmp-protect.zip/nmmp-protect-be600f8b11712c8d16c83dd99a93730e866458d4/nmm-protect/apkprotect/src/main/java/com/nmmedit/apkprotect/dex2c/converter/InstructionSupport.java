package com.nmmedit.apkprotect.dex2c.converter;

import com.android.tools.smali.dexlib2.Opcode;
import com.android.tools.smali.dexlib2.iface.instruction.Instruction;
import com.android.tools.smali.dexlib2.iface.instruction.ReferenceInstruction;
import com.android.tools.smali.dexlib2.iface.reference.TypeReference;

/** Known interpreter gaps, shared by automatic selection and strict conversion. */
public final class InstructionSupport {
    private InstructionSupport() { }
    public static String unsupportedReason(Instruction instruction) {
        Opcode opcode = instruction.getOpcode();
        if (opcode.odexOnly()) return "Unsupported opcode " + opcode.name();
        switch (opcode) {
            case INVOKE_CUSTOM: case INVOKE_CUSTOM_RANGE:
            case INVOKE_POLYMORPHIC: case INVOKE_POLYMORPHIC_RANGE:
            case CONST_METHOD_HANDLE: case CONST_METHOD_TYPE:
                return "Unsupported opcode " + opcode.name();
            case FILLED_NEW_ARRAY: case FILLED_NEW_ARRAY_RANGE:
                String type = ((TypeReference) ((ReferenceInstruction) instruction).getReference()).getType();
                if (!type.startsWith("[L") && !type.startsWith("[[") && !type.equals("[I"))
                    return "Unsupported opcode " + opcode.name() + " for array type " + type;
                break;
            default: break;
        }
        return null;
    }
}
