package com.nmmedit.apkprotect.dex2c.converter;

import com.android.tools.smali.dexlib2.Opcode;
import com.android.tools.smali.dexlib2.Opcodes;
import com.android.tools.smali.dexlib2.MethodHandleType;
import com.android.tools.smali.dexlib2.dexbacked.DexBackedDexFile;
import com.android.tools.smali.dexlib2.immutable.*;
import com.android.tools.smali.dexlib2.immutable.instruction.*;
import com.android.tools.smali.dexlib2.immutable.reference.*;
import com.android.tools.smali.dexlib2.iface.reference.Reference;
import com.android.tools.smali.dexlib2.writer.io.MemoryDataStore;
import com.android.tools.smali.dexlib2.writer.pool.DexPool;
import org.junit.Test;
import java.util.Collections;
import java.util.Arrays;
import static org.junit.Assert.*;

public class UnsupportedOpcodeTest {
    private void rejects(Opcode opcode, Reference reference) throws Exception {
        ImmutableMethod method = new ImmutableMethod("Lsample/Core;", "modern", Collections.emptyList(),
                "V", 9, Collections.emptySet(), Collections.emptySet(),
                new ImmutableMethodImplementation(1, Arrays.asList(
                        new ImmutableInstruction21c(opcode, 0, reference),
                        new ImmutableInstruction10x(Opcode.RETURN_VOID)), Collections.emptyList(), Collections.emptyList()));
        ImmutableClassDef type = new ImmutableClassDef("Lsample/Core;", 1, "Ljava/lang/Object;",
                Collections.emptyList(), null, Collections.emptySet(), Collections.emptyList(), Collections.singletonList(method));
        MemoryDataStore store = new MemoryDataStore();
        DexPool.writeTo(store, new ImmutableDexFile(Opcodes.forApi(28), Collections.singletonList(type)));
        DexBackedDexFile dex = new DexBackedDexFile(Opcodes.forApi(28), store.getData());
        IllegalArgumentException error = assertThrows(IllegalArgumentException.class,
                () -> new References(dex, new ClassAnalyzer()));
        assertTrue(error.getMessage(), error.getMessage().contains(opcode.name()));
        assertTrue(error.getMessage(), error.getMessage().contains("Lsample/Core;->modern()V"));
    }

    @Test public void rejectsConstMethodTypeBeforeNativeGeneration() throws Exception {
        rejects(Opcode.CONST_METHOD_TYPE, new ImmutableMethodProtoReference(Collections.emptyList(), "V"));
    }

    @Test public void rejectsConstMethodHandleBeforeNativeGeneration() throws Exception {
        rejects(Opcode.CONST_METHOD_HANDLE, new ImmutableMethodHandleReference(MethodHandleType.INVOKE_STATIC,
                new ImmutableMethodReference("Lsample/Core;", "target", Collections.emptyList(), "V")));
    }
}
