package com.nmmedit.apkprotect.util;

import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TemporaryFolder;
import java.nio.file.Files;
import java.nio.file.Path;
import static org.junit.Assert.*;

public class FileUtilsTest {
    @Rule public TemporaryFolder temporary = new TemporaryFolder();

    @Test public void cleanupDeletesLinksWithoutFollowingTheirTargets() throws Exception {
        Path work = temporary.newFolder().toPath();
        Path outside = temporary.newFolder().toPath();
        Path valuable = Files.writeString(outside.resolve("keep"), "original");
        Files.createSymbolicLink(work.resolve("linked"), outside);
        FileUtils.deleteFile(work.toFile());
        assertFalse(Files.exists(work));
        assertEquals("original", Files.readString(valuable));
    }
}
