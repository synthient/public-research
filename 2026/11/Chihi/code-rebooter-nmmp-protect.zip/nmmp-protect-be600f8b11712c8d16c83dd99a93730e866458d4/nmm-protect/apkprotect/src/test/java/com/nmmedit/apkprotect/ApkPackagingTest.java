package com.nmmedit.apkprotect;
import com.android.zipflinger.*;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.TemporaryFolder;
import java.io.*;
import java.util.zip.*;
import static org.junit.Assert.*;
public class ApkPackagingTest {
    @Rule public TemporaryFolder temporary = new TemporaryFolder();
    @Test public void preservesResourcesAndAlignsExistingAndNewNativeLibraries() throws Exception {
        File input=temporary.newFile(), output=new File(temporary.getRoot(),"out.apk"), lib=temporary.newFile();
        try (ZipOutputStream zip=new ZipOutputStream(new FileOutputStream(input))) {
            for (String name:new String[]{"lib/arm64-v8a/libexisting.so","assets/business.json","META-INF/CERT.SF","classes.dex","AndroidManifest.xml"}) {
                zip.putNextEntry(new ZipEntry(name)); zip.write(new byte[]{1,2,3}); zip.closeEntry();
            }
        }
        try(FileOutputStream stream=new FileOutputStream(lib)){stream.write(new byte[]{4,5,6});}
        try(ZipArchive zip=new ZipArchive(output.toPath())) {
            ApkPackaging.copyResources(ZipMap.from(input.toPath()),zip);
            ApkPackaging.addNativeLibrary(zip,lib,"arm64-v8a");
        }
        try(ZipFile zip=new ZipFile(output)) {
            assertNotNull(zip.getEntry("assets/business.json"));
            assertNull(zip.getEntry("classes.dex")); assertNull(zip.getEntry("META-INF/CERT.SF"));
            for(String name:new String[]{"lib/arm64-v8a/libexisting.so","lib/arm64-v8a/"+lib.getName()})
                assertEquals(ZipEntry.STORED,zip.getEntry(name).getMethod());
        }
        try(RandomAccessFile file=new RandomAccessFile(output,"r")) {
            long offset=0; int libs=0;
            while(offset+30<file.length()) {
                file.seek(offset);
                if(Integer.reverseBytes(file.readInt())!=0x04034b50) break;
                file.seek(offset+18); long size=Integer.toUnsignedLong(Integer.reverseBytes(file.readInt()));
                file.seek(offset+26); int nameLen=Short.toUnsignedInt(Short.reverseBytes(file.readShort()));
                int extraLen=Short.toUnsignedInt(Short.reverseBytes(file.readShort()));
                byte[] name=new byte[nameLen]; file.readFully(name);
                long payload=offset+30+nameLen+extraLen;
                if(new String(name,java.nio.charset.StandardCharsets.UTF_8).startsWith("lib/")) {
                    assertEquals(0,payload%16384); libs++;
                }
                offset=payload+size;
            }
            assertEquals(2,libs);
        }
    }
}
