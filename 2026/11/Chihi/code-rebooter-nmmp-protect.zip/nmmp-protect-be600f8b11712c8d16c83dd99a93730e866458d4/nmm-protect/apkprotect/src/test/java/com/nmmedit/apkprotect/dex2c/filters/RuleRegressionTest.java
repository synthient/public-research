package com.nmmedit.apkprotect.dex2c.filters;
import org.junit.Test;
import java.io.*;
import java.util.*;
import static org.junit.Assert.*;
public class RuleRegressionTest {
    private SimpleRules rules(String text) throws Exception { SimpleRules rules=new SimpleRules(); rules.parse(new StringReader(text)); return rules; }
    @Test public void matchesLiteralNestedNames() throws Exception {
        SimpleRules rules=rules("class sample.Outer$Inner { verify$release; }");
        assertTrue(rules.matchClass("Lsample/Outer$Inner;","Ljava/lang/Object;",Collections.emptyList()));
        assertTrue(rules.matchMethod("verify$release")); assertFalse(rules.matchMethod("verify"));
    }
    @Test public void overlappingRulesUnionMethods() throws Exception {
        SimpleRules rules=rules("class sample.* { first; }\nclass sample.Core { second; }");
        assertTrue(rules.matchClass("Lsample/Core;",null,Collections.emptyList()));
        assertTrue(rules.matchMethod("first")); assertTrue(rules.matchMethod("second"));
        assertFalse(rules.matchClass("Lother/Core;",null,Collections.emptyList()));
        assertFalse(rules.matchMethod("first"));
    }
    @Test public void supportsCommentsAndWhitespace() throws Exception {
        SimpleRules rules=rules("# core\nclass sample.Core { // methods\n first; second;\n}\n");
        assertTrue(rules.matchClass("Lsample/Core;",null,Collections.emptyList()));
        assertTrue(rules.matchMethod("second"));
    }
    @Test public void rejectsTruncatedOrMalformedRules() {
        for(String text:Arrays.asList("class sample.Core { first;", "class sample.Core {}", "class sample.Core extends", "class sample.Core { first; } garbage"))
            assertThrows(text, IOException.class, () -> rules(text));
    }
    @Test public void dollarAndRegexCharactersAreLiteral() throws Exception {
        SimpleRules rules=rules("class sample.Core { a+b; }");
        assertTrue(rules.matchClass("Lsample/Core;",null,Collections.emptyList()));
        assertTrue(rules.matchMethod("a+b")); assertFalse(rules.matchMethod("aaab"));
    }
}
