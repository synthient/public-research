package com.nmmedit.apkprotect.aar.asm;

import org.junit.Test;
import org.objectweb.asm.*;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.*;

import static org.junit.Assert.*;

public class MethodToNativeVisitorTest {
    private static final String OWNER = "fixture/Converted";
    private static final String ARGS = "(ZBCSIJFDLjava/lang/String;[I)";
    private static final Class<?>[] PARAMS = {boolean.class, byte.class, char.class, short.class,
            int.class, long.class, float.class, double.class, String.class, int[].class};
    private static final int[] ARRAY = {17, 29};
    private static final Object[] VALUES = {true, (byte) 2, 'c', (short) 4, 5, 6000000000L,
            7.25f, 8.5d, "argument", ARRAY};

    @Retention(RetentionPolicy.RUNTIME)
    public @interface Marker { }

    @Test
    public void collisionWrappersForwardEveryArgumentAndReturnCategory() throws Exception {
        String[] returns = {"V", "Z", "B", "C", "S", "I", "J", "F", "D", "Ljava/lang/String;", "[I"};
        Object[] expected = {null, true, (byte) 7, (char) 7, (short) 7, 7, 19L, 2.5f, 3.75d, "result", ARRAY};
        for (boolean isStatic : new boolean[]{false, true}) {
            for (int i = 0; i < returns.length; i++) {
                int access = Opcodes.ACC_PUBLIC | Opcodes.ACC_FINAL | Opcodes.ACC_SYNCHRONIZED
                        | (isStatic ? Opcodes.ACC_STATIC : 0);
                String descriptor = ARGS + returns[i];
                AsmMethod original = new AsmMethod(access, "run", descriptor);
                AsmMethod target = new AsmMethod(Opcodes.ACC_PRIVATE | Opcodes.ACC_NATIVE
                        | (isStatic ? Opcodes.ACC_STATIC : 0), "run0", descriptor);
                byte[] converted = convert(fixture(access, "run", descriptor), original,
                        Arrays.asList(original, target));
                Class<?> actualClass = define(converted);
                Method wrapper = actualClass.getDeclaredMethod("run", PARAMS);
                assertEquals(access, wrapper.getModifiers());
                assertTrue(wrapper.isAnnotationPresent(Marker.class));
                assertEquals(Marker.class, wrapper.getParameterAnnotations()[0][0].annotationType());
                assertArrayEquals(new Class<?>[]{java.io.IOException.class}, wrapper.getExceptionTypes());
                Method nativeMethod = actualClass.getDeclaredMethod("run0", PARAMS);
                assertEquals(target.access, nativeMethod.getModifiers());
                assertEquals(0, nativeMethod.getAnnotations().length);

                // Replace only the native body with a Java probe, then let the JVM verify and execute
                // the unchanged wrapper. The probe checks every value, including wide local slots.
                Class<?> runnable = define(replaceNativeWithProbe(converted, returns[i]));
                Object receiver = isStatic ? null : runnable.getConstructor().newInstance();
                assertEquals(expected[i], runnable.getMethod("run", PARAMS).invoke(receiver, VALUES));
            }
        }
    }

    @Test
    public void directNativeConversionPreservesApiMetadata() throws Exception {
        AsmMethod original = new AsmMethod(Opcodes.ACC_PUBLIC, "run", ARGS + "Ljava/lang/String;");
        byte[] converted = convert(fixture(original.access, original.name, original.descriptor),
                original, Collections.singletonList(original));
        Method method = define(converted).getDeclaredMethod("run", PARAMS);
        assertTrue(Modifier.isNative(method.getModifiers()));
        assertTrue(method.isAnnotationPresent(Marker.class));
        assertEquals(Marker.class, method.getParameterAnnotations()[0][0].annotationType());
        assertArrayEquals(new Class<?>[]{java.io.IOException.class}, method.getExceptionTypes());
    }

    @Test
    public void constructorsAndExistingNativeMethodsRemainUnchanged() throws Exception {
        AsmMethod constructor = new AsmMethod(Opcodes.ACC_PUBLIC, "<init>", "()V");
        byte[] converted = convert(fixture(Opcodes.ACC_PUBLIC | Opcodes.ACC_NATIVE, "run", ARGS + "I"),
                constructor, Collections.singletonList(constructor));
        Class<?> clazz = define(converted);
        assertNotNull(clazz.getConstructor().newInstance());
        assertTrue(Modifier.isNative(clazz.getMethod("run", PARAMS).getModifiers()));
    }

    @Test
    public void rejectsSelectedStaticAndDefaultInterfaceMethods() {
        for (int access : new int[]{Opcodes.ACC_PUBLIC, Opcodes.ACC_PUBLIC | Opcodes.ACC_STATIC}) {
            ClassWriter writer = new ClassWriter(ClassWriter.COMPUTE_MAXS);
            writer.visit(Opcodes.V1_8, Opcodes.ACC_PUBLIC | Opcodes.ACC_INTERFACE | Opcodes.ACC_ABSTRACT,
                    "fixture/Interface", null, "java/lang/Object", null);
            MethodVisitor method = writer.visitMethod(access, "value", "()I", null, null);
            method.visitCode();
            method.visitInsn(Opcodes.ICONST_1);
            method.visitInsn(Opcodes.IRETURN);
            method.visitMaxs(0, 0);
            method.visitEnd();
            writer.visitEnd();
            AsmMethod selected = new AsmMethod(access, "value", "()I");
            IllegalStateException error = assertThrows(IllegalStateException.class,
                    () -> convert(writer.toByteArray(), selected, Collections.singletonList(selected)));
            assertTrue(error.getMessage().contains("interface"));
            assertTrue(error.getMessage().contains("fixture/Interface.value()I"));
        }
    }

    private static byte[] convert(byte[] input, AsmMethod original, List<AsmMethod> methods) {
        ClassWriter output = new ClassWriter(0);
        new ClassReader(input).accept(new MethodToNativeVisitor(Opcodes.ASM9, output,
                Collections.singletonMap(original, methods)), 0);
        return output.toByteArray();
    }

    private static byte[] fixture(int access, String name, String descriptor) {
        ClassWriter writer = new ClassWriter(ClassWriter.COMPUTE_MAXS);
        writer.visit(Opcodes.V1_8, Opcodes.ACC_PUBLIC, OWNER, null, "java/lang/Object", null);
        MethodVisitor constructor = writer.visitMethod(Opcodes.ACC_PUBLIC, "<init>", "()V", null, null);
        constructor.visitCode();
        constructor.visitVarInsn(Opcodes.ALOAD, 0);
        constructor.visitMethodInsn(Opcodes.INVOKESPECIAL, "java/lang/Object", "<init>", "()V", false);
        constructor.visitInsn(Opcodes.RETURN);
        constructor.visitMaxs(0, 0);
        constructor.visitEnd();
        MethodVisitor method = writer.visitMethod(access, name, descriptor, null,
                new String[]{"java/io/IOException"});
        method.visitAnnotation(Type.getDescriptor(Marker.class), true).visitEnd();
        method.visitParameterAnnotation(0, Type.getDescriptor(Marker.class), true).visitEnd();
        if ((access & Opcodes.ACC_NATIVE) == 0) {
            method.visitCode();
            method.visitInsn(Opcodes.ACONST_NULL);
            method.visitInsn(Opcodes.ATHROW);
            method.visitMaxs(0, 0);
        }
        method.visitEnd();
        writer.visitEnd();
        return writer.toByteArray();
    }

    private static Class<?> define(byte[] bytes) {
        return new ClassLoader(MethodToNativeVisitorTest.class.getClassLoader()) {
            Class<?> loadFixture() { return defineClass(null, bytes, 0, bytes.length); }
        }.loadFixture();
    }

    public static void verifyArguments(boolean z, byte b, char c, short s, int i, long j,
                                       float f, double d, String value, int[] array) {
        assertArrayEquals(VALUES, new Object[]{z, b, c, s, i, j, f, d, value, array});
    }

    public static int[] resultArray() { return ARRAY; }

    private static byte[] replaceNativeWithProbe(byte[] input, String returnType) {
        ClassWriter writer = new ClassWriter(ClassWriter.COMPUTE_MAXS);
        new ClassReader(input).accept(new ClassVisitor(Opcodes.ASM9, writer) {
            @Override
            public MethodVisitor visitMethod(int access, String name, String descriptor,
                                             String signature, String[] exceptions) {
                if (!name.equals("run0")) return super.visitMethod(access, name, descriptor, signature, exceptions);
                MethodVisitor method = super.visitMethod(access & ~Opcodes.ACC_NATIVE, name,
                        descriptor, signature, exceptions);
                int base = (access & Opcodes.ACC_STATIC) == 0 ? 1 : 0;
                method.visitCode();
                for (int slot = 0; slot < 5; slot++) method.visitVarInsn(Opcodes.ILOAD, base + slot);
                method.visitVarInsn(Opcodes.LLOAD, base + 5);
                method.visitVarInsn(Opcodes.FLOAD, base + 7);
                method.visitVarInsn(Opcodes.DLOAD, base + 8);
                method.visitVarInsn(Opcodes.ALOAD, base + 10);
                method.visitVarInsn(Opcodes.ALOAD, base + 11);
                method.visitMethodInsn(Opcodes.INVOKESTATIC, Type.getInternalName(MethodToNativeVisitorTest.class),
                        "verifyArguments", ARGS + "V", false);
                switch (returnType) {
                    case "V": break;
                    case "Z": method.visitInsn(Opcodes.ICONST_1); break;
                    case "J": method.visitLdcInsn(19L); break;
                    case "F": method.visitLdcInsn(2.5f); break;
                    case "D": method.visitLdcInsn(3.75d); break;
                    case "Ljava/lang/String;": method.visitLdcInsn("result"); break;
                    case "[I": method.visitMethodInsn(Opcodes.INVOKESTATIC,
                            Type.getInternalName(MethodToNativeVisitorTest.class), "resultArray", "()[I", false); break;
                    default: method.visitIntInsn(Opcodes.BIPUSH, 7);
                }
                method.visitInsn(Type.getType(returnType).getOpcode(Opcodes.IRETURN));
                method.visitMaxs(0, 0);
                method.visitEnd();
                return null;
            }
        }, 0);
        return writer.toByteArray();
    }
}
