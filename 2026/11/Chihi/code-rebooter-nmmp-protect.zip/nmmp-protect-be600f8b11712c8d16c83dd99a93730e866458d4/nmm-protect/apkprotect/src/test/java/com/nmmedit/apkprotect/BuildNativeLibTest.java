package com.nmmedit.apkprotect;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.TemporaryFolder;
import java.io.File;
import java.nio.file.Files;
import java.util.Locale;
import static org.junit.Assert.*;
public class BuildNativeLibTest {
    @Rule public TemporaryFolder temporary = new TemporaryFolder();
    @Test public void discoversInstalledHostStripTool() throws Exception {
        File ndk = temporary.newFolder();
        String os = System.getProperty("os.name").toLowerCase(Locale.ROOT);
        String host = os.contains("mac") ? "darwin-x86_64" : os.contains("windows") ? "windows-x86_64" : "linux-x86_64";
        File strip = new File(ndk, "toolchains/llvm/prebuilt/"+host+"/bin/llvm-strip"+(os.contains("windows")?".exe":""));
        Files.createDirectories(strip.toPath().getParent()); Files.createFile(strip.toPath());
        BuildNativeLib.CMakeOptions options = new BuildNativeLib.CMakeOptions("cmake", "sdk", ndk.getPath(), 21,
                temporary.getRoot().getPath(), BuildNativeLib.CMakeOptions.BuildType.RELEASE, "arm64-v8a");
        assertEquals(strip.getAbsolutePath(), options.getStripBinaryPath());
    }
}
