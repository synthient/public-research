package com.nmmedit.apkprotect.aar;

import com.android.tools.r8.*;
import com.android.tools.r8.origin.Origin;
import com.android.tools.smali.dexlib2.Opcode;
import com.android.tools.smali.dexlib2.immutable.*;
import com.android.tools.smali.dexlib2.immutable.instruction.*;
import com.android.tools.smali.dexlib2.immutable.reference.*;
import com.android.tools.smali.dexlib2.writer.io.FileDataStore;
import com.android.tools.smali.dexlib2.writer.pool.DexPool;
import com.google.common.collect.HashMultimap;
import com.nmmedit.apkprotect.dex2c.DexConfig;
import com.nmmedit.apkprotect.dex2c.converter.ClassAnalyzer;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TemporaryFolder;
import org.objectweb.asm.*;

import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

import static org.junit.Assert.*;

public class JniConsumerRulesTest {
    @Rule public final TemporaryFolder temporary = new TemporaryFolder();

    @Test
    public void preservesExistingConsumerRulesVerbatim() throws Exception {
        byte[] existing = "# 项目规则\r\n-keep class existing.Api { *; }".getBytes(StandardCharsets.UTF_8);
        byte[] combined = JniConsumerRules.append(existing, "-keep class generated.Api\n");
        assertArrayEquals(existing, Arrays.copyOf(combined, existing.length));
        assertTrue(new String(combined, StandardCharsets.UTF_8).endsWith("\n-keep class generated.Api\n"));
        assertArrayEquals("generated\n".getBytes(StandardCharsets.UTF_8),
                JniConsumerRules.append(new byte[0], "generated\n"));
    }

    @Test
    public void r8KeepsJniNamesIncludingExternalInheritedMembersAndRemovesUnrelatedCode() throws Exception {
        DexConfig config = config();
        String rules = JniConsumerRules.generate(config, new ClassAnalyzer());
        assertTrue(rules.contains("external.Argument[]"));
        assertTrue(rules.contains("external.Result"));
        assertFalse(rules.contains("-dontobfuscate"));
        Map<String, byte[]> output = new ConcurrentHashMap<>();
        R8Command.Builder builder = R8Command.builder()
                .setMode(CompilationMode.RELEASE)
                .addLibraryResourceProvider(JdkClassFileProvider.fromSystemJdk())
                .addProguardConfiguration(Arrays.asList(rules.split("\n")), Origin.unknown())
                .setProgramConsumer(new ClassFileConsumer() {
                    @Override public void accept(ByteDataView bytes, String descriptor, DiagnosticsHandler handler) {
                        output.put(descriptor, bytes.copyByteData());
                    }
                    @Override public void finished(DiagnosticsHandler handler) { }
                });
        for (byte[] fixture : program()) builder.addClassProgramData(fixture, Origin.unknown());
        R8.run(builder.build());
        assertTrue(output.containsKey("Lfixture/Protected;"));
        assertTrue(output.containsKey("Lcom/nmmedit/protect/NativeUtil;"));
        assertTrue(output.containsKey("Lexternal/Child;"));
        assertTrue(output.containsKey("Lexternal/Argument;"));
        assertTrue(output.containsKey("Lexternal/Result;"));
        assertFalse(output.containsKey("Lunrelated/Unused;"));
        ClassLoader loader = new ClassLoader(getClass().getClassLoader()) {
            @Override protected Class<?> findClass(String name) throws ClassNotFoundException {
                byte[] bytes = output.get("L" + name.replace('.', '/') + ";");
                if (bytes == null) throw new ClassNotFoundException(name);
                return defineClass(name, bytes, 0, bytes.length);
            }
        };
        Class<?> child = loader.loadClass("external.Child");
        assertNotNull(child.getConstructor().newInstance());
        assertEquals(int.class, child.getField("state").getType());
        assertEquals(long.class, child.getMethod("callback", long.class).getReturnType());
        assertNotNull(loader.loadClass("com.nmmedit.protect.NativeUtil").getMethod("classesInit0", int.class));
        Class<?> argumentArray = java.lang.reflect.Array.newInstance(loader.loadClass("external.Argument"), 0).getClass();
        assertNotNull(loader.loadClass("fixture.Protected").getDeclaredMethod("protect0", argumentArray));
    }

    private DexConfig config() throws Exception {
        DexConfig config = new DexConfig(temporary.newFolder(), "classes.dex");
        ImmutableMethod nativeMethod = new ImmutableMethod("Lfixture/Protected;", "protect0",
                Collections.singletonList(new ImmutableMethodParameter("[Lexternal/Argument;", null, null)),
                "Lexternal/Result;", Opcodes.ACC_PRIVATE | Opcodes.ACC_NATIVE, null, null, null);
        HashMultimap<String, List<? extends com.android.tools.smali.dexlib2.iface.Method>> shellMethods = HashMultimap.create();
        shellMethods.put(nativeMethod.getDefiningClass(), Collections.singletonList(nativeMethod));
        config.setShellMethods(shellMethods);
        ImmutableMethod implementation = new ImmutableMethod(nativeMethod.getDefiningClass(), nativeMethod.getName(),
                nativeMethod.getParameters(), nativeMethod.getReturnType(), Opcodes.ACC_PRIVATE, null, null,
                new ImmutableMethodImplementation(5, Arrays.asList(
                        new ImmutableInstruction21c(Opcode.NEW_INSTANCE, 0, new ImmutableTypeReference("Lexternal/Child;")),
                        new ImmutableInstruction35c(Opcode.INVOKE_DIRECT, 1, 0, 0, 0, 0, 0,
                                new ImmutableMethodReference("Lexternal/Child;", "<init>", Collections.emptyList(), "V")),
                        new ImmutableInstruction22c(Opcode.IGET, 1, 0,
                                new ImmutableFieldReference("Lexternal/Child;", "state", "I")),
                        new ImmutableInstruction35c(Opcode.INVOKE_VIRTUAL, 3, 0, 1, 2, 0, 0,
                                new ImmutableMethodReference("Lexternal/Child;", "callback", Collections.singletonList("J"), "J")),
                        new ImmutableInstruction35c(Opcode.INVOKE_VIRTUAL, 1, 0, 0, 0, 0, 0,
                                new ImmutableMethodReference("[I", "clone", Collections.emptyList(), "Ljava/lang/Object;")),
                        new ImmutableInstruction11x(Opcode.RETURN_OBJECT, 0)), null, null));
        DexPool pool = new DexPool(com.android.tools.smali.dexlib2.Opcodes.getDefault());
        pool.internClass(new ImmutableClassDef(nativeMethod.getDefiningClass(), Opcodes.ACC_PUBLIC,
                "Ljava/lang/Object;", null, null, null, Collections.emptyList(), Collections.singletonList(implementation)));
        FileDataStore store = new FileDataStore(config.getImplDexFile());
        try { pool.writeTo(store); } finally { store.close(); }
        return config;
    }

    private static List<byte[]> program() {
        List<byte[]> classes = new ArrayList<>();
        ClassWriter protectedClass = simpleClass("fixture/Protected", "java/lang/Object");
        protectedClass.visitMethod(Opcodes.ACC_PRIVATE | Opcodes.ACC_NATIVE, "protect0",
                "([Lexternal/Argument;)Lexternal/Result;", null, null).visitEnd();
        classes.add(finish(protectedClass));
        ClassWriter utility = simpleClass("com/nmmedit/protect/NativeUtil", "java/lang/Object");
        utility.visitMethod(Opcodes.ACC_PUBLIC | Opcodes.ACC_STATIC | Opcodes.ACC_NATIVE,
                "classesInit0", "(I)V", null, null).visitEnd();
        classes.add(finish(utility));
        ClassWriter parent = simpleClass("external/Parent", "java/lang/Object");
        parent.visitField(Opcodes.ACC_PUBLIC, "state", "I", null, null).visitEnd();
        MethodVisitor method = parent.visitMethod(Opcodes.ACC_PUBLIC, "callback", "(J)J", null, null);
        method.visitCode();
        method.visitVarInsn(Opcodes.LLOAD, 1);
        method.visitInsn(Opcodes.LRETURN);
        method.visitMaxs(0, 0);
        method.visitEnd();
        classes.add(finish(parent));
        classes.add(finish(simpleClass("external/Child", "external/Parent")));
        classes.add(finish(simpleClass("external/Argument", "java/lang/Object")));
        classes.add(finish(simpleClass("external/Result", "java/lang/Object")));
        classes.add(finish(simpleClass("unrelated/Unused", "java/lang/Object")));
        return classes;
    }

    private static ClassWriter simpleClass(String name, String parent) {
        ClassWriter writer = new ClassWriter(ClassWriter.COMPUTE_MAXS);
        writer.visit(Opcodes.V1_8, Opcodes.ACC_PUBLIC, name, null, parent, null);
        MethodVisitor constructor = writer.visitMethod(Opcodes.ACC_PUBLIC, "<init>", "()V", null, null);
        constructor.visitCode();
        constructor.visitVarInsn(Opcodes.ALOAD, 0);
        constructor.visitMethodInsn(Opcodes.INVOKESPECIAL, parent, "<init>", "()V", false);
        constructor.visitInsn(Opcodes.RETURN);
        constructor.visitMaxs(0, 0);
        constructor.visitEnd();
        return writer;
    }

    private static byte[] finish(ClassWriter writer) { writer.visitEnd(); return writer.toByteArray(); }
}
