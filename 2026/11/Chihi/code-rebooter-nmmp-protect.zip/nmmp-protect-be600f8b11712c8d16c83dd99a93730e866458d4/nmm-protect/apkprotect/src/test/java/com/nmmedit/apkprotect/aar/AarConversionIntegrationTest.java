package com.nmmedit.apkprotect.aar;

import com.android.tools.smali.dexlib2.Opcode;
import com.android.tools.smali.dexlib2.dexbacked.DexBackedDexFile;
import com.android.tools.smali.dexlib2.iface.Method;
import com.android.tools.smali.dexlib2.immutable.*;
import com.android.tools.smali.dexlib2.immutable.instruction.*;
import com.android.tools.smali.dexlib2.writer.io.FileDataStore;
import com.android.tools.smali.dexlib2.writer.pool.DexPool;
import com.nmmedit.apkprotect.dex2c.Dex2c;
import com.nmmedit.apkprotect.dex2c.DexConfig;
import com.nmmedit.apkprotect.dex2c.converter.*;
import com.nmmedit.apkprotect.dex2c.converter.instructionrewriter.RandomInstructionRewriter;
import com.nmmedit.apkprotect.dex2c.filters.BasicKeepConfig;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TemporaryFolder;
import org.objectweb.asm.*;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.*;

import static org.junit.Assert.*;

public class AarConversionIntegrationTest {
    @Rule public final TemporaryFolder temporary = new TemporaryFolder();

    @Test
    public void collisionRegistrationTableMatchesNativeMethodInOutputClass() throws Exception {
        File input = temporary.newFile("classes.dex");
        DexPool pool = new DexPool(com.android.tools.smali.dexlib2.Opcodes.getDefault());
        pool.internClass(dexClass("Lfixture/Parent;", "Ljava/lang/Object;",
                Collections.singletonList(dexMethod("Lfixture/Parent;", "run", Opcodes.ACC_PRIVATE))));
        pool.internClass(dexClass("Lfixture/Child;", "Lfixture/Parent;", Arrays.asList(
                dexMethod("Lfixture/Child;", "run", Opcodes.ACC_PUBLIC),
                dexMethod("Lfixture/Child;", "run0", Opcodes.ACC_PRIVATE))));
        FileDataStore store = new FileDataStore(input);
        try { pool.writeTo(store); } finally { store.close(); }
        ClassAnalyzer analyzer = new ClassAnalyzer();
        analyzer.setMinSdk(21);
        analyzer.loadDexFile(input);
        DexConfig config = Dex2c.handleModuleDex(input, new BasicKeepConfig() {
            @Override public boolean acceptMethod(Method method) {
                return method.getDefiningClass().equals("Lfixture/Child;") && method.getName().equals("run");
            }
        }, analyzer, new RandomInstructionRewriter(), temporary.newFolder());
        List<? extends Method> shell = config.getShellMethods().get("Lfixture/Child;").iterator().next();
        assertEquals(2, shell.size());
        assertEquals("run1", shell.get(1).getName());

        ClassWriter original = new ClassWriter(ClassWriter.COMPUTE_MAXS);
        original.visit(Opcodes.V1_8, Opcodes.ACC_PUBLIC, "fixture/Child", null, "fixture/Parent", null);
        for (String name : Arrays.asList("run", "run0")) {
            MethodVisitor method = original.visitMethod(name.equals("run") ? Opcodes.ACC_PUBLIC : Opcodes.ACC_PRIVATE,
                    name, "()I", null, null);
            method.visitCode();
            method.visitInsn(Opcodes.ICONST_1);
            method.visitInsn(Opcodes.IRETURN);
            method.visitMaxs(0, 0);
            method.visitEnd();
        }
        original.visitEnd();
        java.lang.reflect.Method modify = AarProtect.class.getDeclaredMethod("modifyClass", InputStream.class,
                Set.class, String.class, String.class, int.class);
        modify.setAccessible(true);
        byte[] output = (byte[]) modify.invoke(null, new ByteArrayInputStream(original.toByteArray()),
                config.getShellMethods().get("Lfixture/Child;"), config.getRegisterNativesClassName(),
                config.getRegisterNativesMethodName(), config.getOffsetFromClassName("fixture/Child"));
        Map<String, Integer> outputMethods = new HashMap<>();
        new ClassReader(output).accept(new ClassVisitor(Opcodes.ASM9) {
            @Override public MethodVisitor visitMethod(int access, String name, String descriptor,
                                                       String signature, String[] exceptions) {
                outputMethods.put(name + descriptor, access);
                return null;
            }
        }, 0);
        assertEquals(Integer.valueOf(Opcodes.ACC_PRIVATE | Opcodes.ACC_NATIVE), outputMethods.get("run1()I"));
        assertEquals(Integer.valueOf(Opcodes.ACC_PUBLIC), outputMethods.get("run()I"));
        assertEquals(Integer.valueOf(Opcodes.ACC_PRIVATE), outputMethods.get("run0()I"));
        References references;
        try (InputStream dex = new BufferedInputStream(new FileInputStream(config.getImplDexFile()))) {
            references = new ResolverCodeGenerator(DexBackedDexFile.fromInputStream(null, dex), analyzer).getReferences();
        }
        String registration = "{" + references.getStringItemIndex("run1") + ", "
                + references.getStringItemIndex("()I") + ", (void *) "
                + MyMethodUtil.getJniFunctionName("fixture/Child", "run1", Collections.emptyList(), "I") + "}";
        assertTrue(new String(Files.readAllBytes(config.getNativeFunctionsFile().toPath()), StandardCharsets.UTF_8)
                .contains(registration));
    }

    private static ImmutableClassDef dexClass(String name, String parent, List<ImmutableMethod> methods) {
        return new ImmutableClassDef(name, Opcodes.ACC_PUBLIC, parent, null, null, null,
                Collections.emptyList(), methods);
    }

    private static ImmutableMethod dexMethod(String owner, String name, int access) {
        return new ImmutableMethod(owner, name, Collections.emptyList(), "I", access, null, null,
                new ImmutableMethodImplementation(2, Arrays.asList(
                        new ImmutableInstruction11n(Opcode.CONST_4, 0, 1),
                        new ImmutableInstruction11x(Opcode.RETURN, 0)), null, null));
    }
}
