package com.nmmedit.apkprotect.aar.asm;

import org.junit.Test;
import org.objectweb.asm.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.junit.Assert.assertEquals;

public class InjectStaticBlockVisitorTest {
    private static final List<Integer> registrations = new ArrayList<>();

    public static void register(int index) { registrations.add(index); }

    @Test
    public void generatedInitializerVerifiesAndExecutesRegistrationOnce() throws Exception {
        verifyRegistration(false);
    }

    @Test
    public void existingInitializerWithEmptyStackVerifiesAndExecutesRegistrationOnce() throws Exception {
        verifyRegistration(true);
    }

    private static void verifyRegistration(boolean existingInitializer) throws Exception {
        for (int writerFlags : new int[]{0, ClassWriter.COMPUTE_MAXS}) {
            for (int index : new int[]{-1, 0, 128, 40000}) {
                registrations.clear();
                ClassWriter output = new ClassWriter(writerFlags);
                new ClassReader(fixture(existingInitializer)).accept(new InjectStaticBlockVisitor(Opcodes.ASM9,
                        output, Type.getInternalName(InjectStaticBlockVisitorTest.class), "register", index), 0);
                byte[] bytes = output.toByteArray();
                Class<?> transformed = new ClassLoader(InjectStaticBlockVisitorTest.class.getClassLoader()) {
                    Class<?> loadFixture() { return defineClass(null, bytes, 0, bytes.length); }
                }.loadFixture();
                assertEquals(7, transformed.getMethod("value").invoke(null));
                assertEquals(7, transformed.getMethod("value").invoke(null));
                assertEquals(Arrays.asList(index), registrations);
            }
        }
    }

    private static byte[] fixture(boolean existingInitializer) {
        ClassWriter writer = new ClassWriter(0);
        writer.visit(Opcodes.V1_8, Opcodes.ACC_PUBLIC, "fixture/Initialized", null, "java/lang/Object", null);
        if (existingInitializer) {
            MethodVisitor initializer = writer.visitMethod(Opcodes.ACC_STATIC, "<clinit>", "()V", null, null);
            initializer.visitCode();
            initializer.visitInsn(Opcodes.RETURN);
            initializer.visitMaxs(0, 0);
            initializer.visitEnd();
        }
        MethodVisitor value = writer.visitMethod(Opcodes.ACC_PUBLIC | Opcodes.ACC_STATIC, "value", "()I", null, null);
        value.visitCode();
        value.visitIntInsn(Opcodes.BIPUSH, 7);
        value.visitInsn(Opcodes.IRETURN);
        value.visitMaxs(1, 0);
        value.visitEnd();
        writer.visitEnd();
        return writer.toByteArray();
    }
}
