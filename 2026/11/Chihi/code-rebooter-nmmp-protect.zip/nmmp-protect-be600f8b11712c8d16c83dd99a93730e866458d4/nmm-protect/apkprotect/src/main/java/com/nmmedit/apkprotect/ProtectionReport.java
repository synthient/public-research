package com.nmmedit.apkprotect;

import com.android.tools.smali.dexlib2.iface.Method;
import com.google.gson.GsonBuilder;
import com.nmmedit.apkprotect.dex2c.*;
import com.nmmedit.apkprotect.dex2c.converter.MyMethodUtil;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.security.*;
import java.util.*;

/** External audit record; never embedded in the distributed APK. */
public final class ProtectionReport {
    private final List<String> methods;
    private final int classes;
    private ProtectionReport(List<String> methods, int classes) { this.methods=methods; this.classes=classes; }

    public static ProtectionReport create(GlobalDexConfig global) throws IOException {
        List<String> methods=new ArrayList<>(); Set<String> classes=new HashSet<>();
        for (DexConfig dex : global.getConfigs()) {
            for (String method : dex.getConvertedMethods()) {
                methods.add(method);
                classes.add(method.substring(0,method.indexOf("->")));
            }
        }
        if (methods.isEmpty()) throw new IOException("No methods converted. Check rules and the mapping from this exact input build.");
        Collections.sort(methods);
        return new ProtectionReport(methods,classes.size());
    }

    public int convertedMethodCount() { return methods.size(); }

    public void write(File input, File destination) throws IOException {
        Map<String,Object> report=new LinkedHashMap<>();
        report.put("schema_version",1);
        report.put("input_sha256",sha256(input));
        report.put("converted_class_count",classes);
        report.put("converted_method_count",methods.size());
        report.put("converted_methods",methods);
        Files.write(destination.toPath(),new GsonBuilder().setPrettyPrinting().disableHtmlEscaping().create()
                .toJson(report).getBytes(StandardCharsets.UTF_8));
    }

    static String sha256(File file) throws IOException {
        try {
            MessageDigest digest=MessageDigest.getInstance("SHA-256");
            try(InputStream input=new FileInputStream(file)) {
                byte[] buffer=new byte[8192]; int size;
                while((size=input.read(buffer))!=-1) digest.update(buffer,0,size);
            }
            StringBuilder result=new StringBuilder();
            for(byte value:digest.digest()) result.append(String.format("%02x",value&255));
            return result.toString();
        } catch(NoSuchAlgorithmException exception) { throw new AssertionError(exception); }
    }
}
