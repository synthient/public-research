package com.nmmedit.apkprotect.aar;

import com.android.tools.smali.dexlib2.dexbacked.DexBackedDexFile;
import com.android.tools.smali.dexlib2.iface.ClassDef;
import com.android.zipflinger.ZipMap;
import com.android.zipflinger.ZipRepo;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashSet;
import java.util.Set;
import java.util.TreeSet;

/** Rejects D8-generated classes that the original class-file based AAR cannot supply to JNI. */
final class AarPreflight {
    private AarPreflight() { }

    static void validate(File classJar, File dexJar) throws IOException {
        Set<String> originalTypes = new HashSet<>();
        for (String name : ZipMap.from(classJar.toPath()).getEntries().keySet()) {
            if (name.endsWith(".class")) {
                originalTypes.add("L" + name.substring(0, name.length() - ".class".length()) + ";");
            }
        }
        Set<String> missingClasses = new TreeSet<>();
        try (ZipRepo archive = new ZipRepo(ZipMap.from(dexJar.toPath()))) {
            for (String name : archive.getEntries().keySet()) {
                if (!name.endsWith(".dex")) continue;
                if (!name.equals("classes.dex")) {
                    throw new IOException("Multidex AAR conversion is unsupported; protect the final APK instead");
                }
                try (InputStream input = new BufferedInputStream(archive.getInputStream(name))) {
                    for (ClassDef type : DexBackedDexFile.fromInputStream(null, input).getClasses()) {
                        if (!originalTypes.contains(type.getType())) {
                            String descriptor = type.getType();
                            missingClasses.add(descriptor.substring(1, descriptor.length() - 1));
                        }
                    }
                }
            }
        }
        if (!missingClasses.isEmpty()) {
            throw new IOException("AAR protection cannot preserve D8-generated classes absent from classes.jar: "
                    + String.join(", ", missingClasses) + ". Protect the final APK instead.");
        }
    }
}
