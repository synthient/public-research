package com.nmmedit.apkprotect.util;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.concurrent.TimeUnit;

/** Runs build tools without pipe deadlocks or silently swallowed failures. */
public final class CommandRunner {
    private CommandRunner() {}

    public static void run(List<String> command, long timeoutSeconds, File output) throws IOException {
        if (timeoutSeconds <= 0) throw new IllegalArgumentException("Process timeout must be positive");
        if (Thread.currentThread().isInterrupted()) throw new IOException("Build interrupted");
        ProcessBuilder builder = new ProcessBuilder(command).redirectErrorStream(true);
        builder.redirectOutput(output == null ? ProcessBuilder.Redirect.INHERIT : ProcessBuilder.Redirect.to(output));
        Process process = builder.start();
        try {
            if (!process.waitFor(timeoutSeconds, TimeUnit.SECONDS)) {
                terminate(process);
                throw new IOException("Build command timed out after " + timeoutSeconds + "s: " + command.get(0));
            }
            if (process.exitValue() != 0) {
                throw new IOException("Build command exited with " + process.exitValue() + ": " + command.get(0));
            }
        } catch (InterruptedException exception) {
            terminate(process);
            Thread.currentThread().interrupt();
            throw new IOException("Build interrupted: " + command.get(0), exception);
        } finally {
            if (process.isAlive()) terminate(process);
        }
    }

    private static void terminate(Process process) {
        process.descendants().forEach(child -> child.destroyForcibly());
        process.destroyForcibly();
    }
}
