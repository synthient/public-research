package com.nmmedit.apkprotect.aar;

import com.android.tools.smali.dexlib2.dexbacked.DexBackedDexFile;
import com.android.tools.smali.dexlib2.iface.Method;
import com.android.tools.smali.dexlib2.iface.reference.FieldReference;
import com.android.tools.smali.dexlib2.iface.reference.MethodReference;
import com.nmmedit.apkprotect.dex2c.DexConfig;
import com.nmmedit.apkprotect.dex2c.converter.ClassAnalyzer;
import com.nmmedit.apkprotect.dex2c.converter.References;
import com.nmmedit.apkprotect.dex2c.converter.ResolverCodeGenerator;
import org.objectweb.asm.Type;

import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.*;

/** Keeps the exact classes and members resolved by the generated JNI tables. */
final class JniConsumerRules {
    static String generate(DexConfig config, ClassAnalyzer analyzer) throws IOException {
        final References references;
        try (InputStream input = new BufferedInputStream(new FileInputStream(config.getImplDexFile()))) {
            references = new ResolverCodeGenerator(DexBackedDexFile.fromInputStream(null, input), analyzer)
                    .getReferences();
        }
        SortedMap<String, SortedSet<String>> classes = new TreeMap<>();
        for (String descriptor : references.getTypePool()) keepType(classes, descriptor);
        for (FieldReference field : references.getFieldPool()) {
            keepType(classes, field.getDefiningClass()).add(Type.getType(field.getType()).getClassName()
                    + " " + field.getName() + ";");
            keepType(classes, field.getType());
        }
        for (MethodReference method : references.getMethodPool()) keepMethod(classes, method);
        // Include the public wrapper as well as the private native registered under its new name.
        for (List<? extends Method> methods : config.getShellMethods().values()) {
            for (Method method : methods) keepMethod(classes, method);
        }
        keepType(classes, "L" + config.getRegisterNativesClassName() + ";")
                .add("void " + config.getRegisterNativesMethodName() + "(int);");

        StringBuilder rules = new StringBuilder("# nmmp: names resolved by generated JNI code\n");
        for (Map.Entry<String, SortedSet<String>> entry : classes.entrySet()) {
            rules.append("-keep,includedescriptorclasses class ").append(entry.getKey()).append(" {\n");
            for (String member : entry.getValue()) rules.append("    ").append(member).append('\n');
            rules.append("}\n");
        }
        return rules.toString();
    }

    static byte[] append(byte[] existing, String generated) {
        byte[] extra = ((existing.length == 0 ? "" : "\n") + generated).getBytes(StandardCharsets.UTF_8);
        byte[] combined = Arrays.copyOf(existing, existing.length + extra.length);
        System.arraycopy(extra, 0, combined, existing.length, extra.length);
        return combined;
    }

    private static SortedSet<String> keepType(Map<String, SortedSet<String>> classes, String descriptor) {
        Type type = Type.getType(descriptor);
        if (type.getSort() == Type.ARRAY) type = type.getElementType();
        if (type.getSort() != Type.OBJECT) return null;
        return classes.computeIfAbsent(type.getClassName(), ignored -> new TreeSet<>());
    }

    private static void keepMethod(Map<String, SortedSet<String>> classes, MethodReference method) {
        SortedSet<String> members = keepType(classes, method.getDefiningClass());
        // Array methods (for example int[].clone()) are supplied by the runtime. Keep reference
        // element types, but do not treat these methods as members of the element's class.
        if (Type.getType(method.getDefiningClass()).getSort() == Type.ARRAY) members = null;
        StringBuilder member = new StringBuilder();
        if (!method.getName().equals("<init>")) {
            member.append(Type.getType(method.getReturnType()).getClassName()).append(' ');
        }
        member.append(method.getName()).append('(');
        String separator = "";
        for (CharSequence parameter : method.getParameterTypes()) {
            member.append(separator).append(Type.getType(parameter.toString()).getClassName());
            separator = ",";
            keepType(classes, parameter.toString());
        }
        member.append(");");
        if (members != null) members.add(member.toString());
        keepType(classes, method.getReturnType());
    }
}
