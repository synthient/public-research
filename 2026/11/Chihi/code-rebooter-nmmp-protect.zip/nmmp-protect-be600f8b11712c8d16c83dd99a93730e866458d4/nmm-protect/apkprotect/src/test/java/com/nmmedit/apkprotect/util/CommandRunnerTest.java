package com.nmmedit.apkprotect.util;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.TemporaryFolder;
import java.io.*;
import java.nio.file.Files;
import java.util.*;
import static org.junit.Assert.*;
public class CommandRunnerTest {
    @Rule public TemporaryFolder temporary = new TemporaryFolder();
    private List<String> command(String mode) {
        return Arrays.asList(new File(System.getProperty("java.home"), "bin/java").getPath(),
            "-cp", System.getProperty("java.class.path"), Child.class.getName(), mode);
    }
    @Test(timeout=10000) public void drainsBothOutputStreams() throws Exception {
        File log = temporary.newFile();
        CommandRunner.run(command("flood"), 5, log);
        assertTrue(Files.size(log.toPath()) >= 400000);
    }
    @Test public void nonzeroExitFails() throws Exception {
        IOException error = assertThrows(IOException.class,
            () -> CommandRunner.run(command("fail"), 5, temporary.newFile()));
        assertTrue(error.getMessage().contains("17"));
    }
    @Test(timeout=7000) public void timeoutFails() throws Exception {
        IOException error = assertThrows(IOException.class,
            () -> CommandRunner.run(command("wait"), 1, temporary.newFile()));
        assertTrue(error.getMessage().contains("timed out"));
    }
    @Test public void preservesInterruptFlag() throws Exception {
        Thread.currentThread().interrupt();
        try {
            assertThrows(IOException.class,
                () -> CommandRunner.run(command("wait"), 5, temporary.newFile()));
            assertTrue(Thread.currentThread().isInterrupted());
        } finally { Thread.interrupted(); }
    }
    public static class Child {
        public static void main(String[] args) throws Exception {
            if (args[0].equals("fail")) System.exit(17);
            if (args[0].equals("wait")) Thread.sleep(60000);
            for (int i=0;i<20000;i++) { System.out.println("stdout line"); System.err.println("stderr line"); }
        }
    }
}
