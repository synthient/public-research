package com.nmmedit.apkprotect.aar;

import com.nmmedit.apkprotect.dex2c.converter.ClassAnalyzer;
import com.nmmedit.apkprotect.dex2c.converter.instructionrewriter.RandomInstructionRewriter;
import com.nmmedit.apkprotect.dex2c.filters.BasicKeepConfig;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TemporaryFolder;
import org.objectweb.asm.*;

import java.io.*;
import java.lang.reflect.InvocationTargetException;
import java.util.jar.JarEntry;
import java.util.jar.JarOutputStream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;
import java.util.zip.ZipFile;

import static org.junit.Assert.*;

public class AarDesugaringTest {
    @Rule public final TemporaryFolder temporary = new TemporaryFolder();

    @Test
    public void rejectsD8CompanionClassesAbsentFromOriginalJar() throws Exception {
        AarFolders folders = fixture(true);
        AarProtect protect = protector(folders);
        IOException error = assertThrows(IOException.class, protect::run);
        assertTrue(error.getMessage().contains("D8"));
        assertTrue(error.getMessage().contains("classes.jar"));
        assertTrue(error.getMessage().contains("fixture/I$-CC"));
        assertFalse(folders.apkFolders.getDex2cSrcDir().exists());
        assertFalse(folders.getOutputAar().exists());
    }

    @Test
    public void acceptsClassFilesThatNeedNoAdditionalD8Classes() throws Exception {
        AarFolders folders = fixture(false);
        assertTrue(convertToDex(protector(folders)).isFile());
    }

    @Test public void rejectsMultidexRatherThanSilentlyDroppingSecondaryDex() throws Exception {
        AarFolders folders = fixture(false);
        File dexJar = convertToDex(protector(folders));
        File multiple = temporary.newFile("multidex.zip");
        try (ZipFile source = new ZipFile(dexJar);
             ZipOutputStream output = new ZipOutputStream(new FileOutputStream(multiple));
             InputStream input = source.getInputStream(source.getEntry("classes.dex"))) {
            byte[] dex = input.readAllBytes();
            for (String name : new String[]{"classes.dex", "classes2.dex"}) {
                output.putNextEntry(new ZipEntry(name)); output.write(dex); output.closeEntry();
            }
        }
        IOException error = assertThrows(IOException.class, () -> AarPreflight.validate(
                new File(folders.getTempDir(), "classes.jar"), multiple));
        assertTrue(error.getMessage(), error.getMessage().contains("Multidex"));
    }

    private static AarProtect protector(AarFolders folders) {
        return new AarProtect.Builder(folders).setClassAnalyzer(new ClassAnalyzer())
                .setInstructionRewriter(new RandomInstructionRewriter()).setFilter(new BasicKeepConfig()).build();
    }

    private static File convertToDex(AarProtect protect) throws Exception {
        java.lang.reflect.Method method = AarProtect.class.getDeclaredMethod("classesJarToDexJar");
        method.setAccessible(true);
        try {
            return (File) method.invoke(protect);
        } catch (InvocationTargetException error) {
            if (error.getCause() instanceof Exception) throw (Exception) error.getCause();
            throw error;
        }
    }

    private AarFolders fixture(boolean interfaceCall) throws IOException {
        ByteArrayOutputStream classes = new ByteArrayOutputStream();
        try (JarOutputStream jar = new JarOutputStream(classes)) {
            if (interfaceCall) {
                jar.putNextEntry(new JarEntry("fixture/I.class"));
                jar.write(classBytes("fixture/I", true, false));
                jar.closeEntry();
            }
            jar.putNextEntry(new JarEntry("fixture/Core.class"));
            jar.write(classBytes("fixture/Core", false, interfaceCall));
            jar.closeEntry();
        }
        File aar = temporary.newFile("input.aar");
        try (ZipOutputStream zip = new ZipOutputStream(new FileOutputStream(aar))) {
            zip.putNextEntry(new ZipEntry("classes.jar"));
            zip.write(classes.toByteArray());
            zip.closeEntry();
        }
        return new AarFolders(aar, temporary.newFolder("output"));
    }

    private static byte[] classBytes(String name, boolean isInterface, boolean interfaceCall) {
        ClassWriter writer = new ClassWriter(ClassWriter.COMPUTE_MAXS);
        writer.visit(Opcodes.V1_8, Opcodes.ACC_PUBLIC
                        | (isInterface ? Opcodes.ACC_INTERFACE | Opcodes.ACC_ABSTRACT : 0),
                name, null, "java/lang/Object", null);
        MethodVisitor method = writer.visitMethod(Opcodes.ACC_PUBLIC | Opcodes.ACC_STATIC, "value", "()I", null, null);
        method.visitCode();
        if (interfaceCall) method.visitMethodInsn(Opcodes.INVOKESTATIC, "fixture/I", "value", "()I", true);
        else method.visitInsn(Opcodes.ICONST_1);
        method.visitInsn(Opcodes.IRETURN);
        method.visitMaxs(0, 0);
        method.visitEnd();
        writer.visitEnd();
        return writer.toByteArray();
    }
}
