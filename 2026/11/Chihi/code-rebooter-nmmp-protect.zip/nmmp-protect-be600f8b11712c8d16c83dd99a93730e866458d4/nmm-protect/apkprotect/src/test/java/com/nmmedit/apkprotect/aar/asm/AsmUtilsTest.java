package com.nmmedit.apkprotect.aar.asm;

import org.junit.Test;
import org.objectweb.asm.*;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import static org.junit.Assert.*;

public class AsmUtilsTest {
    public static class InitTarget {
        static int value;
        public static void initialize(int index) { value = index; }
    }

    @Test public void addedStaticInitializerVerifiesAndExecutes() throws Exception {
        ClassWriter original = new ClassWriter(0);
        original.visit(Opcodes.V1_8, Opcodes.ACC_PUBLIC, "fixture/AddedInitializer", null, "java/lang/Object", null);
        original.visitEnd();
        ClassWriter output = new ClassWriter(ClassWriter.COMPUTE_MAXS);
        new ClassReader(original.toByteArray()).accept(new InjectStaticBlockVisitor(Opcodes.ASM9,
                output, Type.getInternalName(InitTarget.class), "initialize", 37), 0);
        byte[] bytes = output.toByteArray();
        ClassLoader loader = new ClassLoader(getClass().getClassLoader()) {
            @Override protected Class<?> findClass(String name) throws ClassNotFoundException {
                if (name.equals("fixture.AddedInitializer")) return defineClass(name, bytes, 0, bytes.length);
                return super.findClass(name);
            }
        };
        InitTarget.value = 0;
        Class.forName("fixture.AddedInitializer", true, loader);
        assertEquals(37, InitTarget.value);
    }

    @Test
    public void testInjectStaticBlock() throws Exception {
        final ClassWriter output = new ClassWriter(ClassWriter.COMPUTE_MAXS);
        try (InputStream input = getClass().getResourceAsStream("/test2_class")) {
            assertNotNull("Bundled class fixture", input);
            new ClassReader(input).accept(new InjectStaticBlockVisitor(Opcodes.ASM9,
                    output, "com/nmmp/NativeUtils", "classInit0", 5), 0);
        }
        final List<String> calls = new ArrayList<>();
        new ClassReader(output.toByteArray()).accept(new ClassVisitor(Opcodes.ASM9) {
            @Override public MethodVisitor visitMethod(int access, String name, String descriptor,
                                                       String signature, String[] exceptions) {
                if (!name.equals("<clinit>")) return null;
                return new MethodVisitor(Opcodes.ASM9) {
                    @Override public void visitMethodInsn(int opcode, String owner, String name,
                                                          String descriptor, boolean isInterface) {
                        calls.add(owner + "." + name + descriptor);
                    }
                };
            }
        }, 0);
        assertEquals("com/nmmp/NativeUtils.classInit0(I)V", calls.get(0));
    }
}
