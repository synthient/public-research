package com.nmmedit.apkprotect;

import com.android.tools.smali.dexlib2.*;
import com.android.tools.smali.dexlib2.dexbacked.DexBackedDexFile;
import com.android.tools.smali.dexlib2.iface.*;
import com.android.tools.smali.dexlib2.immutable.*;
import com.android.tools.smali.dexlib2.immutable.instruction.*;
import com.android.tools.smali.dexlib2.immutable.reference.*;
import com.android.tools.smali.dexlib2.writer.pool.DexPool;
import com.android.tools.smali.dexlib2.writer.io.FileDataStore;
import com.google.gson.*;
import com.nmmedit.apkprotect.dex2c.*;
import com.nmmedit.apkprotect.dex2c.converter.ClassAnalyzer;
import com.nmmedit.apkprotect.dex2c.converter.instructionrewriter.RandomInstructionRewriter;
import org.junit.*;
import org.junit.rules.TemporaryFolder;
import java.io.*;
import java.nio.file.Files;
import java.util.*;
import static org.junit.Assert.*;

public class AutomaticSelectionTest {
    @Rule public TemporaryFolder temporary = new TemporaryFolder();

    private ImmutableMethod method(String owner, String name, String returnType, int flags,
                                   com.android.tools.smali.dexlib2.iface.instruction.Instruction... instructions) {
        return new ImmutableMethod(owner, name, Collections.emptyList(), returnType, flags,
                Collections.emptySet(), Collections.emptySet(), instructions.length == 0 ? null :
                new ImmutableMethodImplementation(2, Arrays.asList(instructions), Collections.emptyList(), Collections.emptyList()));
    }
    private ImmutableClassDef type(String name, int flags, ImmutableMethod... methods) {
        return new ImmutableClassDef(name, flags, "Ljava/lang/Object;", Collections.emptyList(), null,
                Collections.emptySet(), Collections.emptyList(), Arrays.asList(methods));
    }
    private File dex(String name, ImmutableClassDef... classes) throws Exception {
        return dex(name, 28, classes);
    }
    private File dex(String name, int api, ImmutableClassDef... classes) throws Exception {
        File file = temporary.newFile(name);
        FileDataStore store = new FileDataStore(file);
        try {
            DexPool.writeTo(store, new ImmutableDexFile(Opcodes.forApi(api), Arrays.asList(classes)));
        } finally { store.close(); }
        return file;
    }
    private AutomaticSelection analyze(ClassAnalyzer analyzer, File... files) throws Exception {
        for (File file : files) analyzer.loadDexFile(file);
        AutomaticSelection selection = new AutomaticSelection(analyzer);
        for (File file : files) try (InputStream in = new BufferedInputStream(new FileInputStream(file))) {
            selection.analyze(DexBackedDexFile.fromInputStream(null, in).getClasses());
        }
        return selection;
    }

    @Test public void automaticallyConvertsOnlySupportedOverloadAndPreservesOtherCodeAcrossDex() throws Exception {
        ImmutableMethod good = method("La/a;", "a", "I", 9,
                new ImmutableInstruction11n(Opcode.CONST_4, 0, 3), new ImmutableInstruction11x(Opcode.RETURN, 0));
        ImmutableMethod modern = method("La/a;", "a", "Ljava/lang/invoke/MethodType;", 9,
                new ImmutableInstruction21c(Opcode.CONST_METHOD_TYPE, 0, new ImmutableMethodProtoReference(Collections.emptyList(), "V")),
                new ImmutableInstruction11x(Opcode.RETURN_OBJECT, 0));
        ImmutableMethod other = method("Lx/z;", "b", "V", 9, new ImmutableInstruction10x(Opcode.RETURN_VOID));
        File first = dex("classes.dex", type("La/a;", 1, good, modern));
        File second = dex("classes2.dex", type("Lx/z;", 1, other));
        ClassAnalyzer analyzer = new ClassAnalyzer();
        AutomaticSelection selection = analyze(analyzer, first, second);
        assertTrue(selection.acceptMethod(good));
        assertFalse(selection.acceptMethod(modern));
        assertTrue(selection.acceptMethod(other));
        GlobalDexConfig result = Dex2c.handleAllDex(Arrays.asList(first, second), selection,
                new RandomInstructionRewriter(), analyzer, temporary.newFolder());
        selection.verifyConversion(result);
        try (InputStream in = new BufferedInputStream(new FileInputStream(result.getConfigs().get(0).getShellDexFile()))) {
            for (ClassDef owner : DexBackedDexFile.fromInputStream(null, in).getClasses()) for (Method m : owner.getMethods()) {
                if (m.getReturnType().equals("I")) assertTrue(AccessFlags.NATIVE.isSet(m.getAccessFlags()));
                else assertEquals(Opcode.CONST_METHOD_TYPE, m.getImplementation().getInstructions().iterator().next().getOpcode());
            }
        }
        File report = temporary.newFile(); selection.write(first, report);
        JsonObject json = JsonParser.parseString(Files.readString(report.toPath())).getAsJsonObject();
        assertEquals(3, json.get("scanned_method_count").getAsInt());
        assertEquals(2, json.get("selected_method_count").getAsInt());
        assertEquals(1, json.get("skipped_method_count").getAsInt());
        assertEquals("unsupported_opcode", json.getAsJsonArray("skipped_methods").get(0).getAsJsonObject().get("reason").getAsString());
        assertTrue(json.getAsJsonArray("selected_methods").toString().contains("La/a;->a()I"));
    }

    @Test public void retainsConstructorsNativeSyntheticSynchronizedAndInterfacesWithReasons() throws Exception {
        ImmutableInstruction10x ret = new ImmutableInstruction10x(Opcode.RETURN_VOID);
        File file = dex("shapes.dex", type("Lshapes/Core;", 1,
                method("Lshapes/Core;", "<init>", "V", 0x10001, ret),
                method("Lshapes/Core;", "<clinit>", "V", 0x10008, ret),
                method("Lshapes/Core;", "nativeCall", "V", 0x109),
                method("Lshapes/Core;", "generated", "V", 0x1009, ret),
                method("Lshapes/Core;", "locked", "V", 0x20009, ret)),
                type("Lshapes/I;", 0x601, method("Lshapes/I;", "defaultCall", "V", 1, ret)));
        AutomaticSelection selection = analyze(new ClassAnalyzer(), file);
        File report = temporary.newFile(); selection.write(file, report);
        String json = Files.readString(report.toPath());
        for (String reason : Arrays.asList("constructor", "native", "synthetic", "synchronized", "interface_method"))
            assertTrue(reason, json.contains(reason));
        assertThrows(IOException.class, () -> selection.requireSelection());
    }

    @Test public void mismatchedConversionCannotClaimSelectedMethodsAreProtected() throws Exception {
        File file = dex("match.dex", type("Lsample/A;", 1,
                method("Lsample/A;", "ok", "V", 9, new ImmutableInstruction10x(Opcode.RETURN_VOID))));
        AutomaticSelection selection = analyze(new ClassAnalyzer(), file);
        assertThrows(IOException.class, () -> selection.verifyConversion(new GlobalDexConfig(temporary.newFolder())));
    }

    @Test public void keepsParameterMetadataAndUnsupportedPrimitiveFilledArrays() throws Exception {
        ImmutableMethod annotated = new ImmutableMethod("Lsample/Core;", "annotated",
                Collections.singletonList(new ImmutableMethodParameter("I", Collections.singleton(
                        new ImmutableAnnotation(AnnotationVisibility.RUNTIME, "Lsample/Marker;", Collections.emptySet())), null)),
                "V", 9, Collections.emptySet(), Collections.emptySet(), new ImmutableMethodImplementation(1,
                Collections.singletonList(new ImmutableInstruction10x(Opcode.RETURN_VOID)), Collections.emptyList(), Collections.emptyList()));
        ImmutableMethod array = method("Lsample/Core;", "booleans", "V", 9,
                new ImmutableInstruction35c(Opcode.FILLED_NEW_ARRAY, 0, 0, 0, 0, 0, 0, new ImmutableTypeReference("[Z")),
                new ImmutableInstruction10x(Opcode.RETURN_VOID));
        File file = dex("metadata.dex", type("Lsample/Core;", 1, annotated, array));
        AutomaticSelection selection = analyze(new ClassAnalyzer(), file);
        assertFalse(selection.acceptMethod(annotated)); assertFalse(selection.acceptMethod(array));
        File report = temporary.newFile(); selection.write(file, report);
        String json = Files.readString(report.toPath());
        assertTrue(json.contains("parameter_annotations")); assertTrue(json.contains("FILLED_NEW_ARRAY"));
        assertTrue(json.contains("[Z"));
    }

    @Test public void detectsJnaThroughSecondInterfaceInAnotherDexWithoutPackageAssumptions() throws Exception {
        ImmutableClassDef jna = new ImmutableClassDef("La/Api;", 0x601, "Ljava/lang/Object;",
                Arrays.asList("Ljava/io/Serializable;", "Lcom/sun/jna/Library;"), null,
                Collections.emptySet(), Collections.emptyList(), Collections.singletonList(
                        method("La/Api;", "invoke", "V", 0x401)));
        ImmutableMethod caller = method("Lb/Caller;", "call", "V", 9,
                new ImmutableInstruction35c(Opcode.INVOKE_INTERFACE, 1, 0, 0, 0, 0, 0,
                        new ImmutableMethodReference("La/Api;", "invoke", Collections.emptyList(), "V")),
                new ImmutableInstruction10x(Opcode.RETURN_VOID));
        File first = dex("jni1.dex", type("Lb/Caller;", 1, caller));
        File second = dex("jni2.dex", jna);
        AutomaticSelection selection = analyze(new ClassAnalyzer(), first, second);
        assertFalse(selection.acceptMethod(caller));
        File report = temporary.newFile(); selection.write(first, report);
        assertTrue(Files.readString(report.toPath()).contains("\"reason\": \"jna\""));
    }

    @Test public void reportIsDeterministicAndBoundToExactInput() throws Exception {
        File file = dex("stable.dex", type("Lu/x;", 1,
                method("Lu/x;", "z", "V", 9, new ImmutableInstruction10x(Opcode.RETURN_VOID)),
                method("Lu/x;", "a", "V", 9, new ImmutableInstruction10x(Opcode.RETURN_VOID))));
        File first = temporary.newFile(), second = temporary.newFile();
        analyze(new ClassAnalyzer(), file).write(file, first);
        analyze(new ClassAnalyzer(), file).write(file, second);
        assertArrayEquals(Files.readAllBytes(first.toPath()), Files.readAllBytes(second.toPath()));
        JsonObject report = JsonParser.parseString(Files.readString(first.toPath())).getAsJsonObject();
        byte[] expected = java.security.MessageDigest.getInstance("SHA-256").digest(Files.readAllBytes(file.toPath()));
        StringBuilder hex = new StringBuilder(); for (byte value : expected) hex.append(String.format("%02x", value & 255));
        assertEquals(hex.toString(), report.get("input_sha256").getAsString());
        assertEquals("Lu/x;->a()V", report.getAsJsonArray("selected_methods").get(0).getAsString());
    }

    @Test public void detectsJnaInFieldValueAndInvokedMethodSignatures() throws Exception {
        String owner = "Lplain/Core;", pointer = "Lcom/sun/jna/Pointer;";
        ImmutableMethod field = method(owner, "field", "V", 9,
                new ImmutableInstruction21c(Opcode.SGET_OBJECT, 0, new ImmutableFieldReference("Lplain/Holder;", "value", "[" + pointer)),
                new ImmutableInstruction10x(Opcode.RETURN_VOID));
        ImmutableMethod returns = method(owner, "returns", "V", 9,
                new ImmutableInstruction35c(Opcode.INVOKE_STATIC, 0, 0, 0, 0, 0, 0,
                        new ImmutableMethodReference("Lplain/Holder;", "get", Collections.emptyList(), pointer)),
                new ImmutableInstruction10x(Opcode.RETURN_VOID));
        ImmutableMethod parameter = method(owner, "parameter", "V", 9,
                new ImmutableInstruction35c(Opcode.INVOKE_STATIC, 1, 0, 0, 0, 0, 0,
                        new ImmutableMethodReference("Lplain/Holder;", "set", Collections.singletonList(pointer), "V")),
                new ImmutableInstruction10x(Opcode.RETURN_VOID));
        File file = dex("member-types.dex", type(owner, 1, field, returns, parameter));
        AutomaticSelection selection = analyze(new ClassAnalyzer(), file);
        assertFalse(selection.acceptMethod(field));
        assertFalse(selection.acceptMethod(returns));
        assertFalse(selection.acceptMethod(parameter));
    }

    @Test public void retainedNewInstructionsKeepTheirDexVersionWhenAnotherDexIsOlder() throws Exception {
        File first = dex("old.dex", 23, type("Lold/Core;", 1,
                method("Lold/Core;", "ok", "V", 9, new ImmutableInstruction10x(Opcode.RETURN_VOID))));
        File second = dex("new.dex", 28, type("Lmodern/Core;", 1,
                method("Lmodern/Core;", "modern", "V", 9,
                        new ImmutableInstruction21c(Opcode.CONST_METHOD_TYPE, 0,
                                new ImmutableMethodProtoReference(Collections.emptyList(), "V")),
                        new ImmutableInstruction10x(Opcode.RETURN_VOID))));
        ClassAnalyzer analyzer = new ClassAnalyzer();
        AutomaticSelection selection = analyze(analyzer, first, second);
        GlobalDexConfig converted = Dex2c.handleAllDex(Arrays.asList(first, second), selection,
                new RandomInstructionRewriter(), analyzer, temporary.newFolder());
        List<File> output = ApkProtect.injectInstructionAndWriteToFile(converted, Collections.emptySet(), 60000, temporary.newFolder());
        assertEquals(2, output.size());
        for (int index = 0; index < 2; index++) {
            byte[] original = Files.readAllBytes((index == 0 ? first : second).toPath());
            byte[] rewritten = Files.readAllBytes(output.get(index).toPath());
            assertArrayEquals(Arrays.copyOf(original, 8), Arrays.copyOf(rewritten, 8));
        }
        try (InputStream in = new BufferedInputStream(new FileInputStream(output.get(1)))) {
            Method method = DexBackedDexFile.fromInputStream(null, in).getClasses().iterator().next().getMethods().iterator().next();
            assertEquals(Opcode.CONST_METHOD_TYPE, method.getImplementation().getInstructions().iterator().next().getOpcode());
        }
    }
}
