package com.nmmedit.apkprotect;
import com.nmmedit.apkprotect.dex2c.*;
import com.android.tools.smali.dexlib2.immutable.ImmutableMethod;
import com.google.common.collect.HashMultimap;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.TemporaryFolder;
import java.io.*;
import java.nio.file.Files;
import java.util.*;
import static org.junit.Assert.*;
public class ProtectionReportTest {
    @Rule public TemporaryFolder temporary = new TemporaryFolder();
    @Test public void refusesNoConvertedMethods() {
        assertThrows(IOException.class, () -> ProtectionReport.create(new GlobalDexConfig(temporary.getRoot())));
    }
    @Test public void countsOriginalMethodsEvenWhenCollisionAddsNativeTarget() throws Exception {
        GlobalDexConfig global = new GlobalDexConfig(temporary.getRoot());
        DexConfig dex = new DexConfig(temporary.getRoot(),"classes.dex");
        HashMultimap methods = HashMultimap.create();
        ImmutableMethod method = new ImmutableMethod("Lsample/Core;","verify",Collections.emptyList(),"Z",1,Collections.emptySet(),Collections.emptySet(),null);
        methods.put("Lsample/Core;",Arrays.asList(method,method)); dex.setShellMethods(methods); global.addDexConfig(dex);
        dex.setShellMethods(null); // APK mode releases its heavyweight method metadata.
        ProtectionReport report = ProtectionReport.create(global);
        assertEquals(1, report.convertedMethodCount());
        File input=temporary.newFile(),output=temporary.newFile();
        report.write(input,output);
        String text=Files.readString(output.toPath());
        assertTrue(text.contains("verify()Z")); assertTrue(text.contains("input_sha256"));
    }
}
