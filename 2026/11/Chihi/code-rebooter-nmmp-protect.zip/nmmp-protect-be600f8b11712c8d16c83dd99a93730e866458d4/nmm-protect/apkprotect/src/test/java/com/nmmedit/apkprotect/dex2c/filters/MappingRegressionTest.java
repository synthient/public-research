package com.nmmedit.apkprotect.dex2c.filters;
import com.nmmedit.apkprotect.deobfus.MappingReader;
import com.android.tools.smali.dexlib2.immutable.*;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.TemporaryFolder;
import java.io.*;
import java.nio.file.Files;
import java.util.*;
import static org.junit.Assert.*;
public class MappingRegressionTest {
    @Rule public TemporaryFolder temporary=new TemporaryFolder();
    @Test public void mapsObjectReturnAndArrayArguments() throws Exception {
        File mapping=temporary.newFile();
        Files.writeString(mapping.toPath(), "sample.Core -> a:\n    sample.Result verify(sample.Result[][]) -> b\nsample.Result -> c:\n");
        SimpleRules rules=new SimpleRules(); rules.parse(new StringReader("class sample.Core { verify; }"));
        ProguardMappingConfig filter=new ProguardMappingConfig(new BasicKeepConfig(),new MappingReader(mapping),rules);
        ImmutableClassDef cls=new ImmutableClassDef("La;",1,"Ljava/lang/Object;",Collections.emptyList(),null,Collections.emptySet(),Collections.emptyList(),Collections.emptyList());
        ImmutableMethod method=new ImmutableMethod("La;","b",Collections.singletonList(new ImmutableMethodParameter("[[Lc;",Collections.emptySet(),null)),"Lc;",1,Collections.emptySet(),Collections.emptySet(),null);
        assertTrue(filter.acceptClass(cls)); assertTrue(filter.acceptMethod(method));
    }
}
