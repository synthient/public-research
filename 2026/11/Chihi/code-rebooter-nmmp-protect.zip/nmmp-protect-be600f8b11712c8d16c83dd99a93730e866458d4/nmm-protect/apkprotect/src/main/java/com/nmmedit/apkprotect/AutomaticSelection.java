package com.nmmedit.apkprotect;
import com.android.tools.smali.dexlib2.AccessFlags;
import com.android.tools.smali.dexlib2.iface.*;
import com.android.tools.smali.dexlib2.iface.instruction.*;
import com.android.tools.smali.dexlib2.iface.reference.*;
import com.google.gson.GsonBuilder;
import com.nmmedit.apkprotect.dex2c.*;
import com.nmmedit.apkprotect.dex2c.converter.ClassAnalyzer;
import com.nmmedit.apkprotect.dex2c.converter.MyMethodUtil;
import com.nmmedit.apkprotect.dex2c.converter.InstructionSupport;
import com.nmmedit.apkprotect.dex2c.filters.BasicKeepConfig;
import com.nmmedit.apkprotect.dex2c.filters.ClassAndMethodFilter;
import java.io.*;
import java.nio.file.Files;
import java.util.*;

/** Exact-signature selection from the input DEX. Never guesses application ownership from names. */
public final class AutomaticSelection implements ClassAndMethodFilter {
    private final ClassAnalyzer analyzer;
    private final BasicKeepConfig baseline = new BasicKeepConfig();
    private final SortedSet<String> selected = new TreeSet<>();
    private final Set<String> selectedClasses = new HashSet<>();
    private final SortedMap<String, Map<String, String>> skipped = new TreeMap<>();
    private final Set<String> inspected = new HashSet<>();
    private final Map<String, Boolean> jnaTypes = new HashMap<>();

    public AutomaticSelection(ClassAnalyzer analyzer) { this.analyzer = Objects.requireNonNull(analyzer); }

    public void analyze(Iterable<? extends ClassDef> classes) {
        for (ClassDef owner : classes) for (Method method : owner.getMethods()) {
            String name = descriptor(method);
            if (!inspected.add(name)) throw new IllegalArgumentException("Duplicate method in input DEX: " + name);
            String[] exclusion = exclusion(owner, method);
            if (exclusion == null) {
                selected.add(name);
                selectedClasses.add(owner.getType());
            } else {
                Map<String, String> entry = new LinkedHashMap<>();
                entry.put("method", name); entry.put("reason", exclusion[0]); entry.put("detail", exclusion[1]);
                skipped.put(name, entry);
            }
        }
    }

    private String[] exclusion(ClassDef owner, Method method) {
        int flags = method.getAccessFlags();
        if (method.getName().startsWith("<")) return skip("constructor", "Initialization must stay in DEX");
        if (AccessFlags.NATIVE.isSet(flags)) return skip("native", "Already native; no DEX implementation");
        if (AccessFlags.ABSTRACT.isSet(flags)) return skip("abstract", "No executable implementation");
        if (AccessFlags.BRIDGE.isSet(flags) || AccessFlags.SYNTHETIC.isSet(flags))
            return skip("synthetic", "Compiler-generated bridge or synthetic method");
        if (!baseline.acceptClass(owner)) return skip("bootstrap", "Platform bootstrap exclusion");
        if (AccessFlags.INTERFACE.isSet(owner.getAccessFlags()))
            return skip("interface_method", "Converter cannot declare native interface methods");
        if (AccessFlags.SYNCHRONIZED.isSet(flags) || AccessFlags.DECLARED_SYNCHRONIZED.isSet(flags))
            return skip("synchronized", "Retain original synchronization semantics");
        for (MethodParameter parameter : method.getParameters()) if (!parameter.getAnnotations().isEmpty())
            return skip("parameter_annotations", "Converter removes parameter annotations");
        MethodImplementation implementation = method.getImplementation();
        if (implementation == null) return skip("no_implementation", "No DEX implementation");
        if (isJnaType(owner.getType())) return skip("jna", "JNA class or interface hierarchy");
        for (String type : referencedTypes(method)) if (isJnaType(type))
            return skip("jna", "JNA type in method signature " + type);
        for (Instruction instruction : implementation.getInstructions()) {
            String unsupported = InstructionSupport.unsupportedReason(instruction);
            if (unsupported != null) return skip("unsupported_opcode", unsupported);
            if (instruction instanceof ReferenceInstruction) {
                Reference reference = ((ReferenceInstruction) instruction).getReference();
                for (String type : referencedTypes(reference)) if (isJnaType(type))
                    return skip("jna", "Reference to JNA type " + type);
            }
        }
        return null;
    }

    private static List<String> referencedTypes(Reference reference) {
        List<String> types = new ArrayList<>();
        if (reference instanceof MethodReference) {
            MethodReference method = (MethodReference) reference;
            types.add(method.getDefiningClass()); types.add(method.getReturnType());
            for (CharSequence parameter : method.getParameterTypes()) types.add(parameter.toString());
        } else if (reference instanceof FieldReference) {
            FieldReference field = (FieldReference) reference;
            types.add(field.getDefiningClass()); types.add(field.getType());
        } else if (reference instanceof TypeReference) types.add(((TypeReference) reference).getType());
        return types;
    }

    private boolean isJnaType(String type) {
        return jnaTypes.computeIfAbsent(type, value -> inheritsJna(value, new HashSet<>()));
    }
    private boolean inheritsJna(String type, Set<String> seen) {
        if (type == null || !seen.add(type)) return false;
        while (type.startsWith("[")) type = type.substring(1);
        if (type.startsWith("Lcom/sun/jna/")) return true;
        ClassDef definition = analyzer.getClassDef(type);
        if (definition == null) return false;
        if (inheritsJna(definition.getSuperclass(), seen)) return true;
        for (String iface : definition.getInterfaces()) if (inheritsJna(iface, seen)) return true;
        return false;
    }
    private static String[] skip(String reason, String detail) { return new String[]{reason, detail}; }
    private static String descriptor(MethodReference method) {
        return method.getDefiningClass() + "->" + method.getName()
                + MyMethodUtil.getMethodSignature(method.getParameterTypes(), method.getReturnType());
    }
    @Override public boolean acceptClass(ClassDef type) { return selectedClasses.contains(type.getType()); }
    @Override public boolean acceptMethod(Method method) { return selected.contains(descriptor(method)); }

    public void requireSelection() throws IOException {
        if (selected.isEmpty()) throw new IOException("Automatic analysis found no compatible methods. See selection-report.json for exclusions.");
    }
    public void verifyConversion(GlobalDexConfig result) throws IOException {
        List<String> converted = new ArrayList<>();
        for (DexConfig dex : result.getConfigs()) converted.addAll(dex.getConvertedMethods());
        if (converted.size() != selected.size() || !new TreeSet<>(converted).equals(selected))
            throw new IOException("Automatic selection and actual converted methods disagree; refusing incomplete protection");
    }
    public void write(File input, File output) throws IOException {
        Map<String, Object> report = new LinkedHashMap<>();
        report.put("schema_version", 1); report.put("selection_mode", "auto"); report.put("policy_version", 1);
        report.put("input_sha256", ProtectionReport.sha256(input));
        report.put("scanned_method_count", inspected.size()); report.put("selected_method_count", selected.size());
        report.put("skipped_method_count", skipped.size()); report.put("selected_methods", selected);
        report.put("skipped_methods", skipped.values());
        Files.createDirectories(output.toPath().toAbsolutePath().getParent());
        Files.writeString(output.toPath(), new GsonBuilder().setPrettyPrinting().disableHtmlEscaping().create().toJson(report));
        System.out.println("Automatic selection: " + selected.size() + " methods selected, " + skipped.size()
                + " retained unchanged; reasons: " + output.getName());
    }
}
