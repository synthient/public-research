package com.nmmedit.apkprotect.dex2c.filters;

import java.io.*;
import java.util.*;
import java.util.regex.*;

/** Simple positive selection rules. Only '*' is a wildcard; inheritance is direct. */
public class SimpleRules {
    private static final Pattern HEADER = Pattern.compile(
            "class\\s+([^\\s{};]+)(?:\\s+(extends|implements)\\s+([^\\s{};]+))?\\s*(?:\\{(.*))?");
    private final List<Rule> rules = new ArrayList<>();
    private List<Pattern> activeMethods = Collections.emptyList();

    public void parse(Reader source) throws IOException {
        List<Rule> parsed = new ArrayList<>();
        Rule pending = null;
        int number = 0;
        try (BufferedReader reader = new BufferedReader(source)) {
            String line;
            while ((line = reader.readLine()) != null) {
                number++;
                int comment = line.indexOf("//");
                if (comment >= 0) line = line.substring(0, comment);
                comment = line.indexOf('#');
                if (comment >= 0) line = line.substring(0, comment);
                line = line.trim();
                if (line.isEmpty()) continue;
                if (pending == null) {
                    Matcher header = HEADER.matcher(line);
                    if (!header.matches()) throw invalid(number, "expected class selection");
                    pending = new Rule(header.group(1), header.group(2), header.group(3));
                    if (header.group(4) == null) {
                        pending.methods.add(wildcard("*"));
                        parsed.add(pending);
                        pending = null;
                        continue;
                    }
                    line = header.group(4).trim();
                }
                int closing = line.indexOf('}');
                String body = closing < 0 ? line : line.substring(0, closing);
                if (closing >= 0 && !line.substring(closing + 1).trim().isEmpty())
                    throw invalid(number, "unexpected text after closing brace");
                if (body.indexOf('{') >= 0) throw invalid(number, "nested class block");
                for (String item : body.split(";")) {
                    String method = item.trim();
                    if (method.isEmpty()) continue;
                    if (method.matches(".*\\s.*") || method.contains("(") || method.contains(")"))
                        throw invalid(number, "expected method name, not a method signature");
                    pending.methods.add(wildcard(method));
                }
                if (closing >= 0) {
                    if (pending.methods.isEmpty()) throw invalid(number, "empty method selection");
                    parsed.add(pending);
                    pending = null;
                }
            }
        }
        if (pending != null) throw invalid(number, "unclosed class block");
        if (parsed.isEmpty()) throw invalid(number, "empty conversion rules");
        rules.addAll(parsed);
        activeMethods = Collections.emptyList();
    }

    public boolean matchClass(String type, String supertype, List<String> interfaces) {
        List<Pattern> selected = new ArrayList<>();
        for (Rule rule : rules) {
            if (!rule.type.matcher(type).matches()) continue;
            if ("extends".equals(rule.relationship) && !rule.parent.equals(supertype)) continue;
            if ("implements".equals(rule.relationship) && !interfaces.contains(rule.parent)) continue;
            selected.addAll(rule.methods);
        }
        activeMethods = selected;
        return !selected.isEmpty();
    }

    public boolean matchMethod(String name) {
        if (name == null) return false;
        for (Pattern pattern : activeMethods) if (pattern.matcher(name).matches()) return true;
        return false;
    }

    private static IOException invalid(int line, String message) {
        return new IOException("Invalid conversion rule at line " + line + ": " + message);
    }

    private static Pattern wildcard(String value) {
        String[] parts = value.split("\\*", -1);
        StringJoiner result = new StringJoiner(".*");
        for (String part : parts) result.add(Pattern.quote(part));
        return Pattern.compile(result.toString());
    }

    private static String descriptor(String name) { return "L" + name.replace('.', '/') + ";"; }

    private static final class Rule {
        final Pattern type;
        final String relationship;
        final String parent;
        final List<Pattern> methods = new ArrayList<>();
        Rule(String type, String relationship, String parent) {
            this.type = wildcard(descriptor(type));
            this.relationship = relationship;
            this.parent = parent == null ? null : descriptor(parent);
        }
    }
}
