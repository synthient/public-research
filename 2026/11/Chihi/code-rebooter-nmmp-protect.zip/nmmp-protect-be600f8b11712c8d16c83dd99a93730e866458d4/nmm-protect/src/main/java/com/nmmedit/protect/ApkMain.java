package com.nmmedit.protect;

import com.nmmedit.apkprotect.ApkFolders;
import com.nmmedit.apkprotect.ApkProtect;
import com.nmmedit.apkprotect.AutomaticSelection;
import com.nmmedit.apkprotect.deobfus.MappingReader;
import com.nmmedit.apkprotect.dex2c.converter.ClassAnalyzer;
import com.nmmedit.apkprotect.dex2c.converter.instructionrewriter.RandomInstructionRewriter;
import com.nmmedit.apkprotect.dex2c.filters.*;

import java.io.*;
import java.nio.charset.StandardCharsets;

public class ApkMain {
    public static void main(String[] args) throws IOException {
        if (args.length < 1) {
            System.err.println("No Input apk.");
            System.err.println("<inApk> [--auto | <convertRuleFile> [mapping.txt]] (default: automatic selection)");
            return;
        }
        final File apk = new File(args[0]);
        final File outDir = new File(apk.getParentFile(), "build");

        final ClassAnalyzer classAnalyzer = new ClassAnalyzer();
        final ClassAndMethodFilter filterConfig;
        if (args.length == 1 || args[1].equals("--auto")) {
            if (args.length > 2) throw new IllegalArgumentException("Automatic mode reads DEX names directly and does not require a mapping");
            filterConfig = new AutomaticSelection(classAnalyzer);
        } else {
            final SimpleRules simpleRules = new SimpleRules();
            simpleRules.parse(new InputStreamReader(new FileInputStream(args[1]), StandardCharsets.UTF_8));
            if (args.length > 2) {
                filterConfig = new ProguardMappingConfig(new BasicKeepConfig(), new MappingReader(new File(args[2])), simpleRules);
            } else {
                filterConfig = new SimpleConvertConfig(new BasicKeepConfig(), simpleRules);
            }
        }
        //todo 可能需要加载某些厂商私有的sdk


        final ApkFolders apkFolders = new ApkFolders(apk, outDir);


        final ApkProtect apkProtect = new ApkProtect.Builder(apkFolders)
                .setInstructionRewriter(new RandomInstructionRewriter())
                .setFilter(filterConfig)
                .setClassAnalyzer(classAnalyzer)
                .build();
        apkProtect.run();
    }
}
