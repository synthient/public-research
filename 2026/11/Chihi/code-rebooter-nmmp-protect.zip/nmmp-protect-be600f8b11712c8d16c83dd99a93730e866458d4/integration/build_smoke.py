#!/usr/bin/env python3
"""Build a signed, self-contained regression APK using only installed SDK tools."""
import argparse
import os
from pathlib import Path
import subprocess
import zipfile


def run(command, **kwargs):
    subprocess.run([str(value) for value in command], check=True, **kwargs)


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sdk",type=Path,required=True)
    parser.add_argument("--output",type=Path,required=True)
    args=parser.parse_args()
    source=Path(__file__).resolve().parent/"smoke"
    output=args.output.resolve(); output.mkdir(parents=True,exist_ok=True)
    build_tools=max((args.sdk/"build-tools").iterdir(),key=lambda p:tuple(int(v) for v in p.name.split(".")))
    android=args.sdk/"platforms/android-36/android.jar"
    classes=output/"classes"; classes.mkdir(exist_ok=True)
    run(["javac","--release","8","-classpath",android,"-d",classes,
         source/"Smoke.java",source/"SmokeInstrumentation.java"])
    with zipfile.ZipFile(output/"classes.jar","w") as jar:
        for file in sorted(classes.rglob("*.class")):jar.write(file,file.relative_to(classes).as_posix())
    dex=output/"dex"; dex.mkdir(exist_ok=True)
    run([build_tools/"d8","--release","--min-api","23","--lib",android,"--output",dex,output/"classes.jar"])
    run([build_tools/"aapt2","link","--manifest",source/"AndroidManifest.xml","-I",android,"-o",output/"unsigned.apk"])
    with zipfile.ZipFile(output/"unsigned.apk","a") as apk:
        for file in dex.glob("*.dex"):apk.write(file,file.name)
    key=output/"smoke.jks"
    env=dict(os.environ,NMMP_SMOKE_PASSWORD="android")
    if not key.exists():
        run(["keytool","-genkeypair","-keystore",key,"-storepass:env","NMMP_SMOKE_PASSWORD","-keypass:env","NMMP_SMOKE_PASSWORD",
             "-alias","smoke","-keyalg","RSA","-keysize","2048","-validity","365","-dname","CN=nmmp regression fixture"],env=env)
    run([build_tools/"zipalign","-P","16","-f","4",output/"unsigned.apk",output/"aligned.apk"])
    run([build_tools/"apksigner","sign","--ks",key,"--ks-key-alias","smoke","--ks-pass","env:NMMP_SMOKE_PASSWORD",
         "--out",output/"input.apk",output/"aligned.apk"],env=env)
    run([build_tools/"apksigner","verify","--verbose",output/"input.apk"])
    print(output/"input.apk")

if __name__=="__main__":main()
