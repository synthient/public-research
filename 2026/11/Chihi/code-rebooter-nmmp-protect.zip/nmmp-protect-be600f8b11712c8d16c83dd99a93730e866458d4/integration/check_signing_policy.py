#!/usr/bin/env python3
"""Exercise SDK signing and rotation policy with disposable keys and an existing fixture APK."""
import argparse
import os
from pathlib import Path
import subprocess
import tempfile


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sdk", required=True, type=Path)
    parser.add_argument("--build-tools", default="36.0.0")
    parser.add_argument("--input", required=True, type=Path)
    parser.add_argument("--report", required=True, type=Path)
    args = parser.parse_args()
    build_tools = args.sdk / "build-tools" / args.build_tools
    signer = build_tools / "apksigner"
    helper = Path(__file__).resolve().parents[1] / "tools/VerifySigningPolicy.java"
    env = dict(os.environ, NMMP_ROTATION_FIXTURE_PASSWORD="disposable-test-key")
    def run(command, check=True):
        return subprocess.run([str(value) for value in command], env=env, check=check,
                              stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, timeout=60)
    with tempfile.TemporaryDirectory(prefix="nmmp-signing-test-") as directory:
        work = Path(directory)
        passwords = ["--ks-pass", "env:NMMP_ROTATION_FIXTURE_PASSWORD"]
        for name in ("old", "new"):
            run(["keytool", "-genkeypair", "-keystore", work / (name + ".jks"),
                 "-storepass:env", "NMMP_ROTATION_FIXTURE_PASSWORD", "-alias", "fixture",
                 "-keyalg", "RSA", "-validity", "30", "-dname", "CN=nmmp fixture " + name])
        run([signer, "rotate", "--out", work / "lineage", "--old-signer", "--ks", work / "old.jks",
             *passwords, "--new-signer", "--ks", work / "new.jks", *passwords])
        original, rotated = work / "original.apk", work / "rotated.apk"
        run([signer, "sign", "--ks", work / "old.jks", *passwords,
             "--out", original, args.input.resolve()])
        run([signer, "sign", "--ks", work / "old.jks", *passwords,
             "--next-signer", "--ks", work / "new.jks", *passwords,
             "--lineage", work / "lineage", "--rotation-min-sdk-version", "28",
             "--out", rotated, args.input.resolve()])
        for apk in (original, rotated):
            run([signer, "verify", "--verbose", apk])
        command = ["java", "-cp", build_tools / "lib/apksigner.jar", helper]
        accepted = run([*command, original])
        rejected = run([*command, rotated], check=False)
        if accepted.stdout.strip() != "NMMP_SIGNING_POLICY_OK":
            raise SystemExit("Unrotated fixture unexpectedly rejected")
        if rejected.returncode == 0 or "rotation lineage" not in rejected.stdout:
            raise SystemExit("Rotated fixture was not rejected: " + rejected.stdout)
        report = "Unrotated APK: SDK signature valid; policy accepted\nRotated A-to-B APK: SDK signature valid; policy rejected\n"
        args.report.parent.mkdir(parents=True, exist_ok=True)
        args.report.write_text(report, encoding="utf-8")
        print(report, end="")


if __name__ == "__main__":
    main()
