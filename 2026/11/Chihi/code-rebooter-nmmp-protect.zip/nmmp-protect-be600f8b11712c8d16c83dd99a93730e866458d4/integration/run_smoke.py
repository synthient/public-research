#!/usr/bin/env python3
"""Install original, test, upgrade to protected, and test on an explicit emulator."""
import argparse
import subprocess
from pathlib import Path


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--serial", required=True)
    parser.add_argument("--original", required=True, type=Path)
    parser.add_argument("--protected", required=True, type=Path)
    parser.add_argument("--report", required=True, type=Path)
    args = parser.parse_args()
    if not args.serial.startswith("emulator-"):
        parser.error("This fixture runner only targets an explicitly selected disposable emulator")
    lines = []
    def run(command):
        result = subprocess.run(["adb", "-s", args.serial] + [str(value) for value in command],
                                check=True, text=True, stdout=subprocess.PIPE,
                                stderr=subprocess.STDOUT, timeout=120)
        print(result.stdout, flush=True)
        lines.append(result.stdout)
        return result.stdout
    run(["shell", "getprop", "ro.build.version.sdk"])
    run(["shell", "getconf", "PAGE_SIZE"])
    for label, apk in [("original", args.original), ("protected upgrade", args.protected)]:
        print(label, flush=True)
        lines.append(label)
        run(["install", "-r", apk])
        output = run(["shell", "am", "instrument", "-w", "-r", "com.nmmp.smoke/.SmokeInstrumentation"])
        if "NMMP_INSTRUMENTATION_PASS" not in output or "INSTRUMENTATION_CODE: -1" not in output:
            raise SystemExit("Instrumentation failed; see output")
    args.report.parent.mkdir(parents=True, exist_ok=True)
    args.report.write_text("\n".join(lines), encoding="utf-8")


if __name__ == "__main__":
    main()
