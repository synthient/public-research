package com.nmmp.smoke;

import android.app.Instrumentation;
import android.os.Bundle;

/** Exercises the application class loader and native libraries inside an installed APK. */
public class SmokeInstrumentation extends Instrumentation {
    @Override public void onCreate(Bundle arguments) {
        super.onCreate(arguments);
        start();
    }

    @Override public void onStart() {
        Bundle result = new Bundle();
        try {
            Smoke.main(new String[0]);
            result.putString("stream", "NMMP_INSTRUMENTATION_PASS");
            finish(-1, result);
        } catch (Throwable error) {
            result.putString("stream", android.util.Log.getStackTraceString(error));
            finish(0, result);
        }
    }
}
