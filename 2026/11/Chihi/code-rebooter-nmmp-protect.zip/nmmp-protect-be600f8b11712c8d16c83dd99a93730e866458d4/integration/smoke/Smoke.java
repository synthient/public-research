package com.nmmp.smoke;

public class Smoke {
    public static void main(String[] args) throws Exception {
        long start = System.nanoTime();
        for(int i=0;i<100;i++) verify();
        Thread[] workers = new Thread[4];
        final Throwable[] failure = new Throwable[1];
        for(int i=0;i<workers.length;i++) workers[i]=new Thread(() -> {
            try { for(int n=0;n<500;n++) verify(); }
            catch(Throwable error) { synchronized(failure) { failure[0]=error; } }
        });
        for(Thread worker:workers) worker.start();
        for(Thread worker:workers) worker.join();
        if(failure[0]!=null) throw new AssertionError("worker",failure[0]);
        System.out.println("NMMP_SMOKE_PASS " + (System.nanoTime()-start));
    }
    private static void verify() {
        check(Core.mix(6,123456789012L,1.5f,2.25)==123456789021L);
        check(Core.truth(true,false));
        check(Core.array(new int[]{1,2,3,4})==10);
        check(Core.text("hello").equals("HELLO!"));
        check(Core.caught(0)==-7 && Core.caught(2)==5);
        check(new Child().value()==12);
        check(Core.switchValue(9)==81 && Core.switchValue(2)==4);
        check(Core.floating(2.5,4.0)==10.0);
        check(Core.byteValue()==-12 && Core.charValue()=='界' && Core.shortValue()==-300);
    }
    private static void check(boolean condition) { if(!condition)throw new AssertionError("behavior mismatch"); }
}
class Core {
    static long mix(int a,long b,float c,double d) { return a+b+(long)c+(long)d; }
    static boolean truth(boolean a,boolean b) { return a&&!b; }
    static int array(int[] values) { int n=0; for(int v:values)n+=v; return n; }
    static String text(String s) { return s.toUpperCase(java.util.Locale.ROOT)+"!"; }
    static int caught(int n) { try{return 10/n;}catch(ArithmeticException error){return -7;} }
    static int switchValue(int n) { switch(n){case 2:return 4;case 9:return 81;default:return -1;} }
    static double floating(double a,double b){return a*b;}
    static byte byteValue(){return -12;}
    static char charValue(){return '界';}
    static short shortValue(){return -300;}
}
class Parent { int value(){return 5;} }
class Child extends Parent { @Override int value(){return super.value()+7;} }
