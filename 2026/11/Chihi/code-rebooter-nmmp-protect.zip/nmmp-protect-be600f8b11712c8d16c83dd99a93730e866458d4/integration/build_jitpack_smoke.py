#!/usr/bin/env python3
"""Publish JitPack-shaped Maven artifacts and consume them without an included build."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import xml.etree.ElementTree as ET
import zipfile

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'tools'))
from apk_validation import certificate_digests, sha256, validate_apk
from production_protect import converted_methods, validate_selection


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--sdk', type=Path)
    parser.add_argument('--publish-only', action='store_true')
    parser.add_argument('--group', default='com.github.nmmp-fixture')
    parser.add_argument('--repository', default='nmmp-protect')
    parser.add_argument('--version', default='jitpack-smoke')
    args = parser.parse_args()
    for value in (args.group, args.repository, args.version):
        if not re.fullmatch(r'[A-Za-z0-9_.-]+', value):
            parser.error('Fixture coordinate components must use letters, numbers, dots, underscores or hyphens')
    if not args.publish_only and not args.sdk:
        parser.error('--sdk is required for the real Android consumer build')
    work = ROOT / '.validation/jitpack-smoke'
    repository = work / 'maven'
    work.mkdir(parents=True, exist_ok=True)
    environment = dict(os.environ, GROUP=args.group, ARTIFACT=args.repository, VERSION=args.version)

    def run(command, log):
        with log.open('w') as stream:
            result = subprocess.run([str(v) for v in command], cwd=ROOT, env=environment,
                                    stdout=stream, stderr=subprocess.STDOUT, timeout=1800)
        if result.returncode:
            with log.open('rb') as stream:
                stream.seek(max(0, log.stat().st_size - 8000))
                tail = stream.read().decode(errors='replace')
            raise RuntimeError(f'Command failed; see {log}\n{tail}')
        print('Passed: ' + str(log), flush=True)

    run(['bash', 'tools/jitpack_publish.sh', '-Dmaven.repo.local=' + str(repository)],
        work / 'publication.log')
    module_group = args.group + '.' + args.repository
    coordinate = module_group + ':gradle-plugin:' + args.version
    artifact_dir = repository / module_group.replace('.', '/') / 'gradle-plugin' / args.version
    stem = 'gradle-plugin-' + args.version
    jar = artifact_dir / (stem + '.jar')
    assert jar.is_file(), 'The requested JitPack artifact is missing: ' + coordinate
    assert (artifact_dir / (stem + '-sources.jar')).is_file()
    pom = ET.parse(artifact_dir / (stem + '.pom')).getroot()
    ns = {'m': 'http://maven.apache.org/POM/4.0.0'}
    for name, value in [('groupId', module_group), ('artifactId', 'gradle-plugin'), ('version', args.version)]:
        assert pom.findtext('m:' + name, namespaces=ns) == value
    assert not pom.findall('m:dependencies/m:dependency', ns), 'The plugin must not depend on unpublished core modules'
    module = json.loads((artifact_dir / (stem + '.module')).read_text())
    assert module['component']['group'] == module_group
    assert module['component']['version'] == args.version
    bundled = {}
    with zipfile.ZipFile(jar) as archive:
        assert 'implementation-class=com.nmmedit.gradle.NmmpProtectPlugin' in archive.read(
            'META-INF/gradle-plugins/com.nmmedit.protect.properties').decode()
        for name in ('vm-protect.jar', 'production_protect.py', 'apk_validation.py', 'VerifySigningPolicy.java'):
            bundled[name] = hashlib.sha256(archive.read('nmmp-runtime/' + name)).hexdigest()
        for name in ('nmmp', 'nmmvm'):
            assert archive.read('META-INF/licenses/' + name + '/LICENSE')
        bytecode = archive.read('com/nmmedit/gradle/NmmpProtectPlugin.class')
        assert int.from_bytes(bytecode[6:8], 'big') == 61, 'Plugin bytecode must target Java 17'
    result = {'coordinate': coordinate, 'plugin_sha256': sha256(jar), 'bundled_sha256': bundled,
              'publication_verified': True, 'hosted_jitpack_verified': False}
    if args.publish_only:
        (work / 'summary.json').write_text(json.dumps(result, indent=2) + '\n')
        print('Verified Maven publication: ' + coordinate)
        return

    sdk = args.sdk.resolve()
    environment.update(ANDROID_HOME=str(sdk), ANDROID_SDK_ROOT=str(sdk), NMMP_JITPACK_FIXTURE_PASSWORD='android')
    consumer = work / 'consumer'
    source = consumer / 'app/src/main'
    source.mkdir(parents=True, exist_ok=True)
    java = source / 'java/com/nmmp/smoke'
    java.mkdir(parents=True, exist_ok=True)
    for name in ('Smoke.java', 'SmokeInstrumentation.java'):
        shutil.copyfile(ROOT / 'integration/smoke' / name, java / name)
    shutil.copyfile(ROOT / 'integration/gradle-smoke/app/src/main/AndroidManifest.xml', source / 'AndroidManifest.xml')
    (consumer / 'settings.gradle').write_text(f'''pluginManagement {{
    repositories {{
        maven {{ url = uri('{repository.as_uri()}'); content {{ includeGroup('{module_group}') }} }}
        google(); mavenCentral(); gradlePluginPortal()
    }}
    resolutionStrategy.eachPlugin {{
        if (requested.id.id == 'com.nmmedit.protect') {{
            useModule('{module_group}:gradle-plugin:' + requested.version)
        }}
    }}
}}
dependencyResolutionManagement {{ repositories {{ google(); mavenCentral() }} }}
rootProject.name = 'nmmp-published-consumer'
include ':app'
''')
    (consumer / 'build.gradle').write_text("plugins { id 'com.android.application' version '8.13.2' apply false }\n")
    (consumer / 'gradle.properties').write_text('org.gradle.jvmargs=-Xmx2048m\norg.gradle.workers.max=2\n')
    (consumer / 'app/build.gradle').write_text('''import com.android.build.api.artifact.SingleArtifact
plugins {
    id 'com.android.application'
    id 'com.nmmedit.protect' version 'VERSION_PLACEHOLDER'
}
android {
    namespace 'com.nmmp.smoke'
    compileSdk 36
    defaultConfig { applicationId 'com.nmmp.smoke'; minSdk 23; targetSdk 36; versionCode 1; versionName '1.0' }
    signingConfigs {
        fixture {
            storeFile rootProject.file('fixture.jks')
            storePassword System.getenv('NMMP_JITPACK_FIXTURE_PASSWORD')
            keyAlias 'smoke'
            keyPassword System.getenv('NMMP_JITPACK_FIXTURE_PASSWORD')
        }
    }
    buildTypes.release { signingConfig signingConfigs.fixture; minifyEnabled false }
    compileOptions { sourceCompatibility JavaVersion.VERSION_1_8; targetCompatibility JavaVersion.VERSION_1_8 }
}
nmmp { abis = ['x86_64'] }
androidComponents.onVariants(androidComponents.selector().withBuildType('release')) { variant ->
    def apk = variant.artifacts.get(SingleArtifact.APK.INSTANCE)
    tasks.register('verifyPublishedPlugin') {
        inputs.dir(apk)
        doLast {
            println 'NMMP_PUBLISHED_APK_DIR=' + apk.get().asFile.absolutePath
            println 'NMMP_PUBLISHED_PLUGIN_CLASS=' + plugins.getPlugin('com.nmmedit.protect').class.name
        }
    }
}
'''.replace('VERSION_PLACEHOLDER', args.version))
    key = consumer / 'fixture.jks'
    if not key.exists():
        run(['keytool', '-genkeypair', '-keystore', key, '-storepass:env', 'NMMP_JITPACK_FIXTURE_PASSWORD',
             '-keypass:env', 'NMMP_JITPACK_FIXTURE_PASSWORD', '-alias', 'smoke', '-keyalg', 'RSA',
             '-keysize', '2048', '-validity', '365', '-dname', 'CN=nmmp JitPack publication fixture'], work / 'key-generation.log')
    run([ROOT / 'nmm-protect/gradlew', '-p', consumer, ':app:assembleRelease', ':app:verifyPublishedPlugin',
         '--console=plain', '--stacktrace', '--no-configuration-cache'], work / 'consumer-build.log')
    base = consumer / 'app/build/outputs/nmmp/release'
    metadata = json.loads((base / 'apk/output-metadata.json').read_text())
    apk = base / 'apk' / metadata['elements'][0]['outputFile']
    release = json.loads((base / 'reports/release.json').read_text())
    assert release['output_sha256'] == sha256(apk)
    assert release['selection_mode'] == 'auto' and release['rules_sha256'] is None
    coverage = json.loads((base / 'reports/protection-report.json').read_text())
    selection = json.loads((base / 'reports/selection-report.json').read_text())
    methods = converted_methods(coverage, release['input_sha256'], 1)
    validate_selection(selection, release['input_sha256'], methods)
    validate_apk(apk, {'x86_64'})
    for name, field in [('vm-protect.jar', 'tool_sha256'), ('production_protect.py', 'runner_sha256'),
                        ('apk_validation.py', 'validator_sha256'), ('VerifySigningPolicy.java', 'signing_policy_sha256')]:
        assert bundled[name] == release[field], 'Consumer must run the engine and helpers inside the published plugin'
    signer = sdk / 'build-tools/36.0.0/apksigner'
    signed = subprocess.run([str(signer), 'verify', '--verbose', '--print-certs', str(apk)],
                            check=True, text=True, stdout=subprocess.PIPE).stdout
    certificate = subprocess.run(['keytool', '-exportcert', '-keystore', str(key),
                                  '-storepass:env', 'NMMP_JITPACK_FIXTURE_PASSWORD', '-alias', 'smoke'],
                                 env=environment, check=True, stdout=subprocess.PIPE).stdout
    assert certificate_digests(signed) == release['signer_sha256'] == [hashlib.sha256(certificate).hexdigest()]
    log = (work / 'consumer-build.log').read_text()
    assert 'NMMP_PUBLISHED_APK_DIR=' + str(base / 'apk') in log
    assert 'NMMP_PUBLISHED_PLUGIN_CLASS=com.nmmedit.gradle.NmmpProtectPlugin' in log
    assert ':nmm-protect:' not in log, 'Consumer must not use an included nmmp build'
    result.update(consumer_verified=True, converted_method_count=len(methods), apk_sha256=sha256(apk))
    (work / 'summary.json').write_text(json.dumps(result, indent=2) + '\n')
    print('Verified standalone Maven consumer: ' + coordinate)


if __name__ == '__main__':
    main()
