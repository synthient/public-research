#!/usr/bin/env python3
"""Exercise automatic release protection with real AGP and disposable fixture keys."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import zipfile

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'tools'))
from apk_validation import certificate_digests, sha256, validate_apk
from production_protect import validate_selection


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--sdk', type=Path, required=True)
    args = parser.parse_args()
    sdk = args.sdk.resolve()
    fixture = ROOT / 'integration/gradle-smoke'
    output = ROOT / '.validation/gradle-smoke'
    logs = output / 'acceptance'
    logs.mkdir(parents=True, exist_ok=True)
    environment = dict(os.environ, ANDROID_HOME=str(sdk), ANDROID_SDK_ROOT=str(sdk),
                       NMMP_FIXTURE_PASSWORD='android')
    wrapper = ROOT / ('nmm-protect/gradlew.bat' if os.name == 'nt' else 'nmm-protect/gradlew')
    command = [str(wrapper), '-p', str(fixture), '--console=plain', '--stacktrace',
               '--no-configuration-cache']
    certificates = {}
    for name in ('first', 'second'):
        key = output / (name + '.jks')
        if not key.exists():
            subprocess.run(['keytool', '-genkeypair', '-keystore', str(key),
                            '-storepass:env', 'NMMP_FIXTURE_PASSWORD',
                            '-keypass:env', 'NMMP_FIXTURE_PASSWORD', '-alias', 'smoke',
                            '-keyalg', 'RSA', '-keysize', '2048', '-validity', '365',
                            '-dname', 'CN=nmmp Gradle fixture ' + name],
                           check=True, env=environment, stdout=subprocess.DEVNULL)
        certificate = subprocess.run(['keytool', '-exportcert', '-keystore', str(key),
                                      '-storepass:env', 'NMMP_FIXTURE_PASSWORD',
                                      '-alias', 'smoke'], env=environment,
                                     check=True, stdout=subprocess.PIPE).stdout
        certificates[name] = hashlib.sha256(certificate).hexdigest()

    native = output / 'native/x86_64/libfixture.so'
    native.parent.mkdir(parents=True, exist_ok=True)
    suffix = '.exe' if os.name == 'nt' else ''
    clang = next((sdk / 'ndk/28.2.13676358/toolchains/llvm/prebuilt').glob('*/bin/clang' + suffix))
    subprocess.run([str(clang), '--target=x86_64-linux-android23', '-shared', '-fPIC',
                    '-Wl,-z,max-page-size=16384', '-Wl,-z,common-page-size=16384',
                    '-x', 'c', '-', '-o', str(native)],
                   input=b'int nmmp_fixture_value(void) { return 42; }\n', check=True)

    def gradle(label, *tasks, expect_success=True):
        log = logs / (label + '.log')
        print(label + ': ' + ' '.join(tasks), flush=True)
        with log.open('w') as stream:
            result = subprocess.run(command + list(tasks), env=environment,
                                    stdout=stream, stderr=subprocess.STDOUT, timeout=1800)
        text = log.read_text(errors='replace')
        if (result.returncode == 0) != expect_success:
            raise RuntimeError(f'Unexpected Gradle result; see {log}\n{text[-8000:]}')
        return text

    def verify_release(variant, signing_key, log):
        base = output / 'app-build/outputs/nmmp' / variant
        apk_dir = base / 'apk'
        metadata = json.loads((apk_dir / 'output-metadata.json').read_text())
        assert len(metadata['elements']) == 1
        apk = apk_dir / metadata['elements'][0]['outputFile']
        assert apk.resolve().parent == apk_dir.resolve()
        assert metadata['applicationId'] == 'com.nmmp.smoke'
        assert metadata['variantName'] == variant
        assert not metadata.get('baselineProfiles')
        assert 'NMMP_FIXTURE_FINAL_APK_DIR=' + str(apk_dir) in log
        reports = base / 'reports'
        release = json.loads((reports / 'release.json').read_text())
        coverage = json.loads((reports / 'protection-report.json').read_text())
        selection = json.loads((reports / 'selection-report.json').read_text())
        assert release['output_sha256'] == sha256(apk)
        assert release['selection_report_sha256'] == sha256(reports / 'selection-report.json')
        assert release['signer_sha256'] == [certificates[signing_key]]
        assert release['selection_mode'] == 'auto' and release['rules_sha256'] is None
        assert release['converted_method_count'] > 0
        validate_selection(selection, release['input_sha256'], coverage['converted_methods'])
        validate_apk(apk, {'x86_64'})
        signer = sdk / 'build-tools/36.0.0' / ('apksigner.bat' if os.name == 'nt' else 'apksigner')
        actual = subprocess.run([str(signer), 'verify', '--verbose', '--print-certs', str(apk)],
                                check=True, text=True, stdout=subprocess.PIPE).stdout
        assert certificate_digests(actual) == [certificates[signing_key]]
        original = next((p for p in (output / 'app-build').rglob('*.apk')
                         if p != apk and sha256(p) == release['input_sha256']), None)
        assert original is not None, 'Original signed artifact must remain available for upgrade comparison'
        shutil.copyfile(original, output / ('original-' + variant + '.apk'))
        return {'variant': variant, 'apk': str(apk), 'original': str(original),
                'signer': certificates[signing_key], 'output_sha256': sha256(apk),
                'converted_methods': release['converted_method_count']}

    debug = gradle('01-debug', ':app:assembleDemoDebug', ':app:locateDemoDebugApk')
    assert ':app:nmmpProtectDemoDebug' not in debug
    debug_dir = Path(next(line.split('=', 1)[1] for line in debug.splitlines()
                         if line.startswith('NMMP_FIXTURE_FINAL_APK_DIR=')))
    debug_meta = json.loads((debug_dir / 'output-metadata.json').read_text())
    with zipfile.ZipFile(debug_dir / debug_meta['elements'][0]['outputFile']) as apk:
        assert not any(name.endswith('/libnmmp.so') for name in apk.namelist())

    first = gradle('02-release', ':app:assembleDemoRelease', ':app:locateDemoReleaseApk')
    checks = [verify_release('demoRelease', 'first', first)]
    repeat = gradle('03-repeat', ':app:assembleDemoRelease', ':app:locateDemoReleaseApk')
    checks.append(verify_release('demoRelease', 'first', repeat))
    other = gradle('04-other-flavor', ':app:assembleOtherRelease', ':app:locateOtherReleaseApk')
    checks.append(verify_release('otherRelease', 'second', other))
    native_default = gradle('04b-native-default-abi', ':app:assembleOtherRelease',
                            ':app:locateOtherReleaseApk', '-PfixtureNativeDefault=true')
    checks.append(verify_release('otherRelease', 'second', native_default))

    unsigned = gradle('05-unsigned', ':app:assembleUnsignedRelease', expect_success=False)
    assert 'sign' in unsigned.lower(), 'Unsigned release must fail with an actionable signing diagnostic'
    assert not list((output / 'app-build/outputs/nmmp/unsignedRelease').rglob('*.apk'))
    bundle = gradle('06-bundle', ':app:bundleDemoRelease', expect_success=False)
    assert 'nmmp' in bundle.lower() and ('aab' in bundle.lower() or 'bundle' in bundle.lower())
    bundle_consumer = gradle('06b-bundle-consumer', ':app:locateDemoReleaseBundle', expect_success=False)
    assert 'nmmp' in bundle_consumer.lower() and 'NMMP_FIXTURE_FINAL_BUNDLE=' not in bundle_consumer
    direct_bundle = gradle('06c-direct-bundle-signing', ':app:signDemoReleaseBundle', expect_success=False)
    assert 'nmmp' in direct_bundle.lower() and ('aab' in direct_bundle.lower() or 'bundle' in direct_bundle.lower())
    broken = gradle('07-broken-runner', ':app:assembleDemoRelease',
                    '-PfixtureBrokenPython=true', expect_success=False)
    assert 'python' in broken.lower()
    assert not list((output / 'app-build/outputs/nmmp/demoRelease/apk').glob('*.apk'))

    restored = gradle('08-signing-override-and-recovery', ':app:assembleDemoRelease',
                      ':app:locateDemoReleaseApk', '-PfixtureBuildTypeSigning=true')
    checks.append(verify_release('demoRelease', 'second', restored))
    cache_run = gradle('09-configuration-cache', ':app:assembleDemoRelease',
                       ':app:locateDemoReleaseApk', '-PfixtureBuildTypeSigning=true',
                       '--configuration-cache')
    checks.append(verify_release('demoRelease', 'second', cache_run))
    assert 'configuration cache entry discarded' in cache_run.lower(), \
        'Protection builds must discard configuration cache containing signing configuration'
    summary = {'checks': checks, 'debug_unprotected': True, 'unsigned_rejected': True,
               'bundle_rejected': True, 'failed_build_removed_stale_apk': True,
               'direct_bundle_artifact_consumer_rejected': True,
               'direct_bundle_signing_rejected': True,
               'native_abi_detected_without_explicit_override': True,
               'configuration_cache_discarded': True,
               'flavor_and_build_type_signing_verified': True}
    (logs / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
    print('Gradle integration passed; reports: ' + str(logs), flush=True)


if __name__ == '__main__':
    main()
