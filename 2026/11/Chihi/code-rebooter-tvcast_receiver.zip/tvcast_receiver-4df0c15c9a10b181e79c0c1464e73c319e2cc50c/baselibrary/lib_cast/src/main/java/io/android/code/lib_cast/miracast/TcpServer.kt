package io.android.code.lib_cast.miracast

import io.android.code.lib_cast.config.CastConfig
import kotlinx.coroutines.*
import java.io.InputStream
import java.net.ServerSocket
import java.net.Socket
import java.net.SocketException

class TcpServer(
    private val videoPort: Int = CastConfig.MIRA_TCP_PORT
) {
    private var scope: CoroutineScope? = null
    private var serverJob: Job? = null
    private var serverSocket: ServerSocket? = null
    private val clientSockets = mutableSetOf<Socket>()

    var onFrame: (suspend (Frame) -> Unit)? = null
    var onConnect: ((Socket) -> Unit)? = null
    var onDisconnect: ((Exception?) -> Unit)? = null

    /** 启动 TCP 服务 */
    fun start() {
        if (serverJob?.isActive == true) {
            //println("TcpServer 已在运行，跳过重复启动")
            return
        }

        //println("=== TcpServer 启动 === 端口: $videoPort")

        // 每次启动都创建全新的作用域
        scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
        serverJob = scope!!.launch {
            try {
                serverSocket = ServerSocket(videoPort).apply { reuseAddress = true }
                while (isActive) {
                    val socket = try {
                        serverSocket?.accept() ?: break
                    } catch (e: SocketException) {
                        //println("ServerSocket 已关闭: $e")
                        break
                    } catch (e: Exception) {
                       // println("Accept 异常: $e")
                        break
                    }

                    if (!isActive) {
                        socket.close()
                        break
                    }

                   // println("客户端连接: ${socket.inetAddress.hostAddress}:${socket.port}")
                    clientSockets.add(socket)
                    onConnect?.invoke(socket)

                    launch { handleClient(socket) }
                }
            } finally {
                //println("TCP 服务退出监听循环")
                releaseAll()
            }
        }
    }

    /** 停止 TCP 服务并彻底销毁所有资源 */
    fun stop() {
        //println("=== TcpServer 停止 ===")

        // 停止主任务
        serverJob?.cancel()
        serverJob = null

        // 关闭 ServerSocket
        try {
            serverSocket?.close()
        } catch (_: Exception) {
        } finally {
            serverSocket = null
        }

        // 关闭所有客户端连接
        clientSockets.forEach {
            try {
                it.close()
            } catch (_: Exception) {
            }
        }
        clientSockets.clear()

        // 取消并销毁作用域
        scope?.cancel()
        scope = null

        //println("TcpServer 资源已全部释放")
    }

    /** 真正的资源释放函数（内部使用） */
    private fun releaseAll() {
        try {
            serverSocket?.close()
        } catch (_: Exception) {
        }
        serverSocket = null

        clientSockets.forEach {
            try {
                it.close()
            } catch (_: Exception) {
            }
        }
        clientSockets.clear()

        scope?.cancel()
        scope = null
    }

    /** 单个客户端处理逻辑 */
    private suspend fun handleClient(socket: Socket) = withContext(Dispatchers.IO) {
        socket.use { sock ->
            try {
                sock.getOutputStream().write("OK".toByteArray())

                val input = sock.getInputStream()
                while (isActive) {
                    val len = readByte(input, 4)
                    if (len.isEmpty()) break
                    val length = bytesToInt(len)

                    val data = readByte(input, length)
                    if (data.isEmpty()) break

                    onFrame?.invoke(Frame.Video(0, 0, data, false))
                }
            } catch (e: Exception) {
                //println("客户端异常: $e")
                onDisconnect?.invoke(e)
            } finally {
                //println("客户端断开: ${sock.inetAddress.hostAddress}")
                clientSockets.remove(sock)
                try {
                    sock.close()
                } catch (_: Exception) {
                }
            }
        }
    }

    /** 安全读取固定长度数据 */
    private fun readByte(input: InputStream, size: Int): ByteArray {
        val buffer = ByteArray(size)
        var read = 0
        while (read < size) {
            val n = input.read(buffer, read, size - read)
            if (n == -1) return byteArrayOf()
            read += n
        }
        return buffer
    }

    private fun bytesToInt(src: ByteArray): Int =
        (src[0].toInt() and 0xFF) or
                ((src[1].toInt() and 0xFF) shl 8) or
                ((src[2].toInt() and 0xFF) shl 16) or
                ((src[3].toInt() and 0xFF) shl 24)
}
