package io.android.code.lib_cast.airplay.lib.rtsp;

public interface MediaStreamInfo {

    StreamType getStreamType();

    enum StreamType {
        AUDIO,
        VIDEO
    }
}
