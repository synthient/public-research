package io.android.code.lib_cast.airplay.netty.internal;

import io.android.code.lib_cast.airplay.netty.internal.handler.audio.AudioHandler;
import io.netty.bootstrap.Bootstrap;
import io.netty.channel.ChannelFuture;
import io.netty.channel.ChannelInitializer;
import io.netty.channel.EventLoopGroup;
import io.netty.channel.epoll.Epoll;
import io.netty.channel.epoll.EpollDatagramChannel;
import io.netty.channel.epoll.EpollEventLoopGroup;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.DatagramChannel;
import io.netty.channel.socket.nio.NioDatagramChannel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.net.InetSocketAddress;

public class AudioReceiver implements Runnable {

    private static final Logger log = LoggerFactory.getLogger(AudioReceiver.class);

    private final AudioHandler audioHandler;
    private final Object monitor;

    private int port;
    private EventLoopGroup workerGroup; // 新增
    private ChannelFuture channelFuture; // 新增


    public AudioReceiver(AudioHandler audioHandler, Object monitor) {
        this.audioHandler = audioHandler;
        this.monitor = monitor;
    }

    @Override
    public void run() {
        var bootstrap = new Bootstrap();
        workerGroup = eventLoopGroup(); // 修改

        try {
            bootstrap
                    .group(workerGroup)
                    .channel(datagramChannelClass())
                    .localAddress(new InetSocketAddress(0)) // bind random port
                    .handler(new ChannelInitializer<DatagramChannel>() {
                        @Override
                        public void initChannel(final DatagramChannel ch) {
                            ch.pipeline().addLast(audioHandler);
                        }
                    });
            channelFuture = bootstrap.bind().sync(); // 修改

            log.info("Audio receiver listening on port: {}",
                    port = ((InetSocketAddress) channelFuture.channel().localAddress()).getPort());

            synchronized (monitor) {
                monitor.notify();
            }

            channelFuture.channel().closeFuture().sync();
        } catch (InterruptedException e) {
            log.info("Audio receiver interrupted");
        } finally {
            log.info("Audio receiver stopped");
            workerGroup.shutdownGracefully();
        }
    }

    public void stop() { // 新增
        if (channelFuture != null && channelFuture.channel().isOpen()) { // 新增
            channelFuture.channel().close().syncUninterruptibly(); // 新增
        } // 新增
        if (workerGroup != null) { // 新增
            workerGroup.shutdownGracefully(); // 新增
        } // 新增
        log.info("Audio receiver stopped explicitly"); // 新增
    } // 新增

    public int getPort() {
        return port;
    }

    private EventLoopGroup eventLoopGroup() {
        return Epoll.isAvailable() ? new EpollEventLoopGroup() : new NioEventLoopGroup();
    }

    private Class<? extends DatagramChannel> datagramChannelClass() {
        return Epoll.isAvailable() ? EpollDatagramChannel.class : NioDatagramChannel.class;
    }
}
