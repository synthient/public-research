package io.android.code.lib_cast.manager

import io.android.code.lib_cast.airplay.lib.rtsp.AudioStreamInfo
import io.android.code.lib_cast.airplay.lib.rtsp.VideoStreamInfo
import io.android.code.lib_cast.airplay.netty.AirPlayServer
import io.android.code.lib_cast.airplay.netty.AirplayDataConsumer
import io.android.code.lib_cast.config.CastConfig
import java.io.IOException

object AirPlayManager {

    private var airPlayServer: AirPlayServer? = null

    /**
     * 启动 AirPlay 服务
     * @param serverName 服务名称
     * @param airPlayPort 视频端口
     * @param airTunesPort 音频端口
     * @param onVideo 视频数据回调
     * @param onAudio 音频数据回调
     * @param onVideoFormat 视频格式回调
     * @param onAudioFormat 音频格式回调
     */
    fun start(
        serverName: String = CastConfig.getAirPlayServerName(),
        airPlayPort: Int = CastConfig.AIRPLAY_PORT,
        airTunesPort: Int = CastConfig.AIRTUNES_PORT,
        onVideo: ((ByteArray) -> Unit)? = null,
        onAudio: ((ByteArray) -> Unit)? = null,
        onDataDisconnect: (() -> Unit)? = null,
        onVideoFormat: ((VideoStreamInfo?) -> Unit)? = null,
        onAudioFormat: ((AudioStreamInfo?) -> Unit)? = null
    ) {
        if (airPlayServer != null) {
            //println("⚠️ AirPlay 服务已在运行中")
            return
        }

        try {
            val consumer = object : AirplayDataConsumer {
                override fun onVideo(video: ByteArray) {
                    try {
                        onVideo?.invoke(video)
                    } catch (e: IOException) {
                        e.printStackTrace()
                    }
                }

                override fun onAudio(audio: ByteArray) {
                    try {
                        onAudio?.invoke(audio)
                    } catch (e: IOException) {
                        e.printStackTrace()
                    }
                }

                override fun onVideoFormat(videoStreamInfo: VideoStreamInfo?) {
                    onVideoFormat?.invoke(videoStreamInfo)
                }

                override fun onAudioFormat(audioStreamInfo: AudioStreamInfo?) {
                    onAudioFormat?.invoke(audioStreamInfo)
                }

                override fun onDataDisconnect() {
                    onDataDisconnect?.invoke()
                }
            }

            airPlayServer = AirPlayServer(serverName, airPlayPort, airTunesPort, consumer).apply { start() }

           // println("✅ AirPlay 服务启动成功：$serverName ($airPlayPort / $airTunesPort)")
        } catch (e: IOException) {
            e.printStackTrace()
           // println("❌ AirPlay 服务启动失败: ${e.message}")
        }
    }

    /**
     * 停止 AirPlay 服务
     */
    fun stop() {
        airPlayServer?.stop()
        airPlayServer = null
       // println("🛑 AirPlay 服务已停止")
    }

}