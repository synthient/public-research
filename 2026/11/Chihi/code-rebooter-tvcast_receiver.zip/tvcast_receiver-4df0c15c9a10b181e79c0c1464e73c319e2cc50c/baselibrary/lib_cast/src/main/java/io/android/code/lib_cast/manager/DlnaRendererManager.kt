package io.android.code.lib_cast.manager

import android.content.Context
import io.android.code.lib_cast.config.CastConfig
import io.android.code.lib_cast.dlna.CustomAVTransportService
import org.fourthline.cling.android.AndroidUpnpService
import org.fourthline.cling.binding.annotations.AnnotationLocalServiceBinder
import org.fourthline.cling.model.DefaultServiceManager
import org.fourthline.cling.model.meta.DeviceDetails
import org.fourthline.cling.model.meta.DeviceIdentity
import org.fourthline.cling.model.meta.LocalDevice
import org.fourthline.cling.model.meta.LocalService
import org.fourthline.cling.model.meta.ManufacturerDetails
import org.fourthline.cling.model.meta.ModelDetails
import org.fourthline.cling.model.types.UDADeviceType
import org.fourthline.cling.model.types.UDN
import java.util.UUID
import kotlin.jvm.java

object DlnaRendererManager {

    private var upnpService: AndroidUpnpService? = null
    private var localDevice: LocalDevice? = null
    private var avService: LocalService<CustomAVTransportService>? = null
    private var listener: Listener? = null

    fun setListener(l: Listener) {
        listener = l
    }

    fun init(service: AndroidUpnpService, context: Context) {
        this.upnpService = service
        registerDevice()
    }

    private fun registerDevice() {
        if (localDevice != null) return

        try {
            val binder = AnnotationLocalServiceBinder()
            @Suppress("UNCHECKED_CAST")
            val localService = binder.read(CustomAVTransportService::class.java) as LocalService<CustomAVTransportService>

            localService.manager = DefaultServiceManager(localService, CustomAVTransportService::class.java)
            val impl = localService.manager.implementation

            impl.callback = object : CustomAVTransportService.Callback {
                override fun onSetAVTransportURI(uri: String) {
                   // println("[DLNA] URI -> $uri")
                    listener?.onSetAVTransportURI(uri)
                }

                override fun onPlay() {
                   // println("[DLNA] Play")
                    listener?.onPlay()
                }

                override fun onPause() {
                    //println("[DLNA] Pause")
                    listener?.onPause()
                }

                override fun onStop() {
                    //println("[DLNA] Stop")
                    listener?.onStop()
                }
            }

            val dlnaServerName = CastConfig.getDlnaServerName()
            val deviceType = UDADeviceType("MediaRenderer", 1)
            val udn = UDN(UUID.randomUUID())
            val details = DeviceDetails(
                dlnaServerName,
                ManufacturerDetails("YourCompany"),
                ModelDetails("A-Player-Model", "Kotlin DLNA Renderer", "1")
            )

            val device = LocalDevice(
                DeviceIdentity(udn),
                deviceType,
                details,
                arrayOf(localService as LocalService<Any>)
            )

            upnpService?.registry?.addDevice(device)
            localDevice = device
            avService = localService

            //println("[DLNA] Device registered: $dlnaServerName")
        } catch (e: Exception) {
            //println("[DLNA] Register failed: ${e.message}")
            e.printStackTrace()
        }
    }

    fun release() {
        try {
            localDevice?.let {
                upnpService?.registry?.removeDevice(it)
                //println("[DLNA] Device unregistered")
            }
        } catch (e: Exception) {
            e.printStackTrace()
        } finally {
            localDevice = null
            upnpService = null
        }
    }

    interface Listener {
        fun onSetAVTransportURI(uri: String)
        fun onPlay()
        fun onPause()
        fun onStop()
    }
}
