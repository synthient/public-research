package io.android.code.lib_cast.config

import android.annotation.SuppressLint
import android.content.Context
import android.provider.Settings
import io.android.code.lib_cast.appContext
import java.util.*

object CastConfig {

    private var shortId: String? = null

    /** 生成简短的设备唯一后缀（例如 "3F9A"） */
    @SuppressLint("HardwareIds")
    private fun getShortId(): String {
        if (shortId != null) return shortId!!

        val androidId = try {
            Settings.Secure.getString(appContext.contentResolver, Settings.Secure.ANDROID_ID)
        } catch (e: Exception) {
            null
        }

        // 取ANDROID_ID或随机UUID，并截取4位简短标识
        val source = if (!androidId.isNullOrBlank()) androidId else UUID.randomUUID().toString()
        shortId = source.hashCode().toUInt().toString(16).uppercase().takeLast(4)
        return shortId!!
    }

    /** 获取唯一的 AirPlay 服务名 */
    fun getAirPlayServerName(): String {
        return "AIR(Cast-${getShortId()})"
    }

    /** 获取唯一的 DLNA 服务名 */
    fun getDlnaServerName(): String {
        return "DMR(Cast-${getShortId()})"
    }

    // 其他配置不变
    const val AIRPLAY_PORT = 15615
    const val AIRTUNES_PORT = 5002
    const val MIRA_TCP_PORT = 8888
}
