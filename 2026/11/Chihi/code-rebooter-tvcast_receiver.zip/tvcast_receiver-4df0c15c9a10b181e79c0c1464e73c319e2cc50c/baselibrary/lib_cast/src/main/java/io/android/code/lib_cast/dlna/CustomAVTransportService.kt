package io.android.code.lib_cast.dlna

import org.fourthline.cling.binding.annotations.*

import org.fourthline.cling.model.types.UnsignedIntegerFourBytes

@UpnpService(
    serviceId = UpnpServiceId("AVTransport"),
    serviceType = UpnpServiceType(value = "AVTransport", version = 1)
)
class CustomAVTransportService {

    // Cling 需要无参构造函数
    constructor()

    /** --- State Variables --- **/
    @UpnpStateVariable(sendEvents = true)
    var InstanceID: UnsignedIntegerFourBytes = UnsignedIntegerFourBytes(0)

    @UpnpStateVariable(sendEvents = true, defaultValue = "")
    var CurrentURI: String = ""

    @UpnpStateVariable(sendEvents = true, defaultValue = "")
    var CurrentURIMetaData: String = ""

    @UpnpStateVariable(sendEvents = true, defaultValue = "1")
    var TransportPlaySpeed: String = "1"

    /** --- Actions --- **/
    @UpnpAction
    fun SetAVTransportURI(
        @UpnpInputArgument(name = "InstanceID", stateVariable = "InstanceID") instanceId: UnsignedIntegerFourBytes?,
        @UpnpInputArgument(name = "CurrentURI", stateVariable = "CurrentURI") currentURI: String?,
        @UpnpInputArgument(name = "CurrentURIMetaData", stateVariable = "CurrentURIMetaData") currentURIMetaData: String?
    ) {
        if (!currentURI.isNullOrEmpty()) {
            CurrentURI = currentURI
            CurrentURIMetaData = currentURIMetaData ?: ""
           // println("[CustomAVTransport] SetAVTransportURI -> $currentURI")
            callback?.onSetAVTransportURI(currentURI)
        }
    }

    @UpnpAction
    fun Play(
        @UpnpInputArgument(name = "InstanceID", stateVariable = "InstanceID") instanceId: UnsignedIntegerFourBytes?,
        @UpnpInputArgument(name = "Speed", stateVariable = "TransportPlaySpeed") speed: String?
    ) {
        TransportPlaySpeed = speed ?: "1"
        //println("[CustomAVTransport] Play called (Speed=$speed)")
        callback?.onPlay()
    }

    @UpnpAction
    fun Pause(@UpnpInputArgument(name = "InstanceID", stateVariable = "InstanceID") instanceId: UnsignedIntegerFourBytes?) {
        //println("[CustomAVTransport] Pause called")
        callback?.onPause()
    }

    @UpnpAction
    fun Stop(@UpnpInputArgument(name = "InstanceID", stateVariable = "InstanceID") instanceId: UnsignedIntegerFourBytes?) {
        //println("[CustomAVTransport] Stop called")
        callback?.onStop()
    }

    /** --- Callback Interface --- **/
    interface Callback {
        fun onSetAVTransportURI(uri: String)
        fun onPlay()
        fun onPause()
        fun onStop()
    }

    @Transient
    var callback: Callback? = null
}
