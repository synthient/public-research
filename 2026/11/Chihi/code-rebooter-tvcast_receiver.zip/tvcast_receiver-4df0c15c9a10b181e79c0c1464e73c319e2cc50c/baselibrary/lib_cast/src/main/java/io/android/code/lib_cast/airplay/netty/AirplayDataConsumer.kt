package io.android.code.lib_cast.airplay.netty

import io.android.code.lib_cast.airplay.lib.rtsp.AudioStreamInfo
import io.android.code.lib_cast.airplay.lib.rtsp.VideoStreamInfo


interface AirplayDataConsumer {
    fun onVideo(video: ByteArray)

    fun onVideoFormat(videoStreamInfo: VideoStreamInfo?) {}

    fun onAudio(audio: ByteArray)

    fun onAudioFormat(audioInfo: AudioStreamInfo?) {}

    fun onDataDisconnect()
}

