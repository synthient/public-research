package io.android.code.lib_cast.dlna

import org.fourthline.cling.android.AndroidUpnpServiceConfiguration
import org.fourthline.cling.android.AndroidUpnpServiceImpl

class UpnpAndroidService : AndroidUpnpServiceImpl() {
    override fun createConfiguration(): AndroidUpnpServiceConfiguration {
        return AndroidUpnpServiceConfiguration()
    }
}
