package io.android.code.lib_cast.manager

import io.android.code.lib_cast.miracast.Frame
import io.android.code.lib_cast.miracast.TcpServer
import kotlinx.coroutines.*
import java.io.IOException

/**
 * Android 镜像接收管理器（无状态纯回调版本）
 */
object MirrorManager {

    private var tcpServer: TcpServer? = null
    private var scope :CoroutineScope ? = null

    /**
     * 启动镜像服务
     */
    fun start(
        onVideo: (ByteArray) -> Unit,
        onAudio: (ByteArray) -> Unit,
        onConnect: () -> Unit = {},
        onDisconnect: (Throwable?) -> Unit = {}
    ) {
        if (tcpServer != null) {
            //println("MirrorManager 已经启动")
            return
        }

        scope?.cancel()
        scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
        scope?.launch {
            try {
                //println("开始创建TCP")
                val server = TcpServer()

                server.onFrame = { frame ->
                    when (frame) {
                        is Frame.Video -> {
                            if (frame.data.size > 4) {
                                val h264 = frame.data.copyOfRange(4, frame.data.size)
                                onVideo(h264)
                            }
                        }
                        is Frame.Audio -> onAudio(frame.data)
                        is Frame.Heartbeat -> {
                            //println("收到心跳")
                        }
                        else -> Unit
                    }
                }

                server.onConnect = {
                    //println("客户端已连接")
                    onConnect()
                }

                server.onDisconnect = { e ->
                   // println("客户端断开: $e")
                    onDisconnect(e)
                }

                server.start()
                tcpServer = server
                //println("MirrorManager 已启动 TCP 服务")
            } catch (e: IOException) {
                //println("启动镜像服务失败: ${e.message}")
                onDisconnect(e)
            }
        }
    }

    /**
     * 停止镜像服务
     */
    fun stop() {
        tcpServer?.stop()
        tcpServer = null
        scope?.cancel()
        //println("MirrorManager 已停止")
    }
}
