package io.android.code.lib_cast.airplay.netty.internal.handler.session;

import java.util.HashMap;
import java.util.Map;

public class SessionManager {

    private final Map<String, Session> sessions = new HashMap<>();

    public Session getSession(String activeRemote) {
        synchronized (sessions) {
            Session session;
            if ((session = sessions.get(activeRemote)) == null) {
                session = new Session();
                sessions.put(activeRemote, session);
            }
            return session;
        }
    }

    // 新增方法以停止所有会话
    public void stopAllSessions() { // 新增
        synchronized (sessions) { // 新增
            for (Session session : sessions.values()) { // 新增
                session.stop(); // 新增
            } // 新增
            sessions.clear(); // 新增
        } // 新增
    } // 新增

}
