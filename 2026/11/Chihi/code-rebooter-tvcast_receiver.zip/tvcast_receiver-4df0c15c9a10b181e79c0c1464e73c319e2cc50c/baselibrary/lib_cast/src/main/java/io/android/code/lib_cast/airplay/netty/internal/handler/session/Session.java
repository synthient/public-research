package io.android.code.lib_cast.airplay.netty.internal.handler.session;


import io.android.code.lib_cast.airplay.lib.AirPlay;
import io.android.code.lib_cast.airplay.netty.internal.AudioControlServer;
import io.android.code.lib_cast.airplay.netty.internal.AudioReceiver;
import io.android.code.lib_cast.airplay.netty.internal.MirroringReceiver;

public class Session {

    private final AirPlay airPlay;

    private MirroringReceiver mirroringReceiver; // 新增
    private AudioReceiver audioReceiver; // 新增
    private AudioControlServer audioControlServer; // 新增

    private Thread airPlayReceiverThread;
    private Thread audioReceiverThread;
    private Thread audioControlServerThread;

    Session() {
        airPlay = new AirPlay();
    }

    public AirPlay getAirPlay() {
        return airPlay;
    }

    public void setAirPlayReceiverThread(Thread airPlayReceiverThread) {
        this.airPlayReceiverThread = airPlayReceiverThread;
    }

    public void setAudioReceiverThread(Thread audioReceiverThread) {
        this.audioReceiverThread = audioReceiverThread;
    }

    public void setAudioControlServerThread(Thread audioControlServerThread) {
        this.audioControlServerThread = audioControlServerThread;
    }

    public void setMirroringReceiver(MirroringReceiver mirroringReceiver) { // 新增
        this.mirroringReceiver = mirroringReceiver; // 新增
    } // 新增

    public void setAudioReceiver(AudioReceiver audioReceiver) { // 新增
        this.audioReceiver = audioReceiver; // 新增
    } // 新增

    public void setAudioControlServer(AudioControlServer audioControlServer) { // 新增
        this.audioControlServer = audioControlServer; // 新增
    } // 新增
    public boolean isMirroringActive() {
        return airPlayReceiverThread != null;
    }

    public boolean isAudioActive() {
        return audioReceiverThread != null && audioControlServerThread != null;
    }

    public void stopMirroring() {
        if (airPlayReceiverThread != null) {
            airPlayReceiverThread.interrupt();
            airPlayReceiverThread = null;
        }
        if (mirroringReceiver != null) { // 新增
            mirroringReceiver.stop(); // 新增
            mirroringReceiver = null; // 新增
        } // 新增
        // TODO destroy fair play video decryptor
    }

    public void stopAudio() {
        if (audioReceiverThread != null) {
            audioReceiverThread.interrupt();
            audioReceiverThread = null;
        }
        if (audioControlServerThread != null) {
            audioControlServerThread.interrupt();
            audioControlServerThread = null;
        }

        if (audioReceiver != null) { // 新增
            audioReceiver.stop(); // 新增
            audioReceiver = null; // 新增
        } // 新增
        if (audioControlServer != null) { // 新增
            audioControlServer.stop(); // 新增
            audioControlServer = null; // 新增
        } // 新增
    }

    public void stop() { // 新增
        stopMirroring(); // 新增
        stopAudio(); // 新增
    } // 新增

}
