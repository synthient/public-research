package io.android.code.lib_cast.miracast


sealed class Frame {
    abstract val width: Short
    abstract val height: Short

    data class SpsPps(
        override val width: Short,
        override val height: Short,
        val sps: ByteArray,
        val pps: ByteArray
    ) : Frame()

    data class Video(
        override val width: Short,
        override val height: Short,
        val data: ByteArray,
        val isKeyFrame: Boolean
    ) : Frame()

    data class Audio(
        val data: ByteArray
    ) : Frame() {
        override val width: Short = 0
        override val height: Short = 0
    }

    data class RawAudio(
        val data: ByteArray
    ) : Frame() {
        override val width: Short = 0
        override val height: Short = 0
    }

    data object Heartbeat : Frame() {
        override val width: Short = 0
        override val height: Short = 0
    }
}