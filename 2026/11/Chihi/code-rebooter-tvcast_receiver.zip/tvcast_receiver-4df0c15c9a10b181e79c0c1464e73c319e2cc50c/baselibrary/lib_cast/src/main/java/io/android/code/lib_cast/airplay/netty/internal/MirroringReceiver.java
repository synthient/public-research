package io.android.code.lib_cast.airplay.netty.internal;

import io.android.code.lib_cast.airplay.netty.internal.handler.mirroring.MirroringHandler;
import io.netty.bootstrap.ServerBootstrap;
import io.netty.channel.ChannelFuture;
import io.netty.channel.ChannelInitializer;
import io.netty.channel.ChannelOption;
import io.netty.channel.EventLoopGroup;
import io.netty.channel.epoll.Epoll;
import io.netty.channel.epoll.EpollEventLoopGroup;
import io.netty.channel.epoll.EpollServerSocketChannel;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.ServerSocketChannel;
import io.netty.channel.socket.SocketChannel;
import io.netty.channel.socket.nio.NioServerSocketChannel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.net.InetSocketAddress;

public class MirroringReceiver implements Runnable {

    private static final Logger log = LoggerFactory.getLogger(MirroringHandler.class);

    private final int port;
    private final MirroringHandler mirroringHandler;

    private EventLoopGroup bossGroup; // 新增
    private EventLoopGroup workerGroup; // 新增
    private ChannelFuture channelFuture; // 新增

    public MirroringReceiver(int port, MirroringHandler mirroringHandler) {
        this.port = port;
        this.mirroringHandler = mirroringHandler;
    }

    @Override
    public void run() {
        var serverBootstrap = new ServerBootstrap();
        bossGroup = eventLoopGroup(); // 修改
        workerGroup = eventLoopGroup(); // 修改
        try {
            serverBootstrap
                    .group(bossGroup, workerGroup)
                    .channel(serverSocketChannelClass())
                    .localAddress(new InetSocketAddress(port))
                    .childHandler(new ChannelInitializer<SocketChannel>() {
                        @Override
                        public void initChannel(final SocketChannel ch) {
                            ch.pipeline().addLast(mirroringHandler);
                        }
                    })
                    .childOption(ChannelOption.TCP_NODELAY, true)
                    .childOption(ChannelOption.SO_REUSEADDR, true)
                    .childOption(ChannelOption.SO_KEEPALIVE, true);
            channelFuture = serverBootstrap.bind().sync(); // 修改
            //System.out.println("Mirroring receiver listening on port: 监听到端口："+port);
            //log.info("Mirroring receiver listening on port: {}", port);
            channelFuture.channel().closeFuture().sync();
        } catch (InterruptedException e) {
           // System.out.println("Mirroring receiver interrupted中断");
           // log.info("Mirroring receiver interrupted");
        } finally {
            //System.out.println("Mirroring receiver stopped镜像流已经停止");
            mirroringHandler.onVideoDisconnect();
            bossGroup.shutdownGracefully();
            workerGroup.shutdownGracefully();

        }
    }

    public void stop() { // 新增
        if (channelFuture != null && channelFuture.channel().isOpen()) { // 新增
            channelFuture.channel().close().syncUninterruptibly(); // 新增
        } // 新增
        if (bossGroup != null) { // 新增
            bossGroup.shutdownGracefully(); // 新增
        } // 新增
        if (workerGroup != null) { // 新增
            workerGroup.shutdownGracefully(); // 新增
        } // 新增
        mirroringHandler.onVideoDisconnect(); // 新增
        log.info("Mirroring receiver stopped explicitly"); // 新增
    } // 新增

    private EventLoopGroup eventLoopGroup() {
        return Epoll.isAvailable() ? new EpollEventLoopGroup() : new NioEventLoopGroup();
    }

    private Class<? extends ServerSocketChannel> serverSocketChannelClass() {
        return Epoll.isAvailable() ? EpollServerSocketChannel.class : NioServerSocketChannel.class;
    }
}
