package io.android.code.lib_cast.airplay.netty.internal;


import io.android.code.lib_cast.airplay.netty.AirplayDataConsumer;
import io.android.code.lib_cast.airplay.netty.internal.handler.control.FairPlayHandler;
import io.android.code.lib_cast.airplay.netty.internal.handler.control.HeartBeatHandler;
import io.android.code.lib_cast.airplay.netty.internal.handler.control.PairingHandler;
import io.android.code.lib_cast.airplay.netty.internal.handler.control.RTSPHandler;
import io.android.code.lib_cast.airplay.netty.internal.handler.mirroring.MirroringHandler;
import io.android.code.lib_cast.airplay.netty.internal.handler.session.Session;
import io.android.code.lib_cast.airplay.netty.internal.handler.session.SessionManager;
import io.netty.bootstrap.ServerBootstrap;
import io.netty.channel.ChannelFuture;
import io.netty.channel.ChannelInitializer;
import io.netty.channel.ChannelOption;
import io.netty.channel.EventLoopGroup;
import io.netty.channel.epoll.Epoll;
import io.netty.channel.epoll.EpollEventLoopGroup;
import io.netty.channel.epoll.EpollServerSocketChannel;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.ServerSocketChannel;
import io.netty.channel.socket.SocketChannel;
import io.netty.channel.socket.nio.NioServerSocketChannel;
import io.netty.handler.codec.http.HttpObjectAggregator;
import io.netty.handler.codec.rtsp.RtspDecoder;
import io.netty.handler.codec.rtsp.RtspEncoder;
import io.netty.handler.logging.LogLevel;
import io.netty.handler.logging.LoggingHandler;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.net.InetSocketAddress;

public class ControlServer implements Runnable {

    private static final Logger log = LoggerFactory.getLogger(MirroringHandler.class);

    private final PairingHandler pairingHandler;
    private final FairPlayHandler fairPlayHandler;
    private final RTSPHandler rtspHandler;
    private final HeartBeatHandler heartBeatHandler;

    private final int airTunesPort;

    private final SessionManager sessionManager; // 新增

    private EventLoopGroup bossGroup; // 新增
    private EventLoopGroup workerGroup; // 新增
    private ChannelFuture channelFuture; // 新增

    public ControlServer(int airPlayPort, int airTunesPort, AirplayDataConsumer airplayDataConsumer) {
        this.airTunesPort = airTunesPort;
        this.sessionManager = new SessionManager(); // 新增
        SessionManager sessionManager = new SessionManager();
        pairingHandler = new PairingHandler(sessionManager);
        fairPlayHandler = new FairPlayHandler(sessionManager);
        rtspHandler = new RTSPHandler(airPlayPort, airTunesPort, sessionManager, airplayDataConsumer);
        heartBeatHandler = new HeartBeatHandler(sessionManager);
    }

    @Override
    public void run() {
        var serverBootstrap = new ServerBootstrap();
        bossGroup = eventLoopGroup(); // 修改
        workerGroup = eventLoopGroup(); // 修改
        try {
            serverBootstrap
                    .group(bossGroup, workerGroup)
                    .channel(serverSocketChannelClass())
                    .localAddress(new InetSocketAddress(airTunesPort))
                    .childHandler(new ChannelInitializer<SocketChannel>() {
                        @Override
                        public void initChannel(final SocketChannel ch) throws Exception {
                            ch.pipeline().addLast(
                                    new RtspDecoder(),
                                    new RtspEncoder(),
                                    new HttpObjectAggregator(64 * 1024),
                                    new LoggingHandler(LogLevel.DEBUG),
                                    pairingHandler,
                                    fairPlayHandler,
                                    rtspHandler,
                                    heartBeatHandler);
                        }
                    })
                    .childOption(ChannelOption.TCP_NODELAY, true)
                    .childOption(ChannelOption.SO_REUSEADDR, true)
                    .childOption(ChannelOption.SO_KEEPALIVE, true);
            channelFuture = serverBootstrap.bind().sync(); // 修改
            log.info("Control server listening on port: {}", airTunesPort);
            channelFuture.channel().closeFuture().sync();
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        } finally {
            log.info("Control server stopped");
            bossGroup.shutdownGracefully();
            workerGroup.shutdownGracefully();
        }
    }

    public void stop() { // 新增
        if (channelFuture != null && channelFuture.channel().isOpen()) { // 新增
            channelFuture.channel().close().syncUninterruptibly(); // 新增
        } // 新增
        if (bossGroup != null) { // 新增
            bossGroup.shutdownGracefully(); // 新增
        } // 新增
        if (workerGroup != null) { // 新增
            workerGroup.shutdownGracefully(); // 新增
        } // 新增
        sessionManager.stopAllSessions(); // 修改：替换 synchronized (sessionManager.sessions) {...}
        log.info("Control server stopped explicitly"); // 新增
    } // 新增

    private EventLoopGroup eventLoopGroup() {
        return Epoll.isAvailable() ? new EpollEventLoopGroup() : new NioEventLoopGroup();
    }

    private Class<? extends ServerSocketChannel> serverSocketChannelClass() {
        return Epoll.isAvailable() ? EpollServerSocketChannel.class : NioServerSocketChannel.class;
    }
}
