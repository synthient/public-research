package io.android.code.lib_base.ext.cache

import android.content.Context
import androidx.core.content.edit
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import kotlin.properties.ReadOnlyProperty
import kotlin.reflect.KProperty

class DynamicPreference<T>(
    private val context: Context,
    private val defaultValue: T,
    private val serializer: (T) -> String = { Gson().toJson(it) },
    private val deserializer: (String) -> T
) : ReadOnlyProperty<Any?, DynamicPreference<T>> {

    private val sharedPreferences by lazy {
        context.getSharedPreferences("AppPreferences", Context.MODE_PRIVATE)
    }

    override fun getValue(thisRef: Any?, property: KProperty<*>): DynamicPreference<T> = this

    // 动态键名读取
    fun get(key: String): T {
        val value = sharedPreferences.getString(key, null)
        return value?.let { deserializer(it) } ?: defaultValue
    }

    // 动态键名存储
    fun set(key: String, value: T) {
        sharedPreferences.edit {
            putString(key, serializer(value))
        }
    }
}


inline fun <reified T> dynamicPreference(
    context: Context,
    defaultValue: T
): DynamicPreference<T> {
    val type = object : TypeToken<T>() {}.type
    return DynamicPreference(
        context = context,
        defaultValue = defaultValue,
        deserializer = { Gson().fromJson(it, type) }
    )
}