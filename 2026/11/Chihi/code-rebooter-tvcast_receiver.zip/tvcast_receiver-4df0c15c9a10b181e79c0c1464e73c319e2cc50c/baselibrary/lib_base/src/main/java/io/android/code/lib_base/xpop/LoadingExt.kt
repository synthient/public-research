package io.android.code.lib_base.xpop

import android.annotation.SuppressLint
import com.lxj.xpopup.impl.LoadingPopupView


@SuppressLint("StaticFieldLeak")
var loadingPopup: LoadingPopupView? = null
fun showLoadingView(title: String = "", hasShadow: Boolean = false) {
    if (loadingPopup == null) {

        showLoadingViewDismiss()
        loadingPopup = getPopWithLoading(isLoading = true) {
            hasShadowBg(hasShadow)
            dismissOnTouchOutside(false)
            dismissOnBackPressed(false)
        }
    }
    loadingPopup?.setTitle(title)


}


fun showLoadingViewDismiss() {
    loadingPopup?.dismiss()
    loadingPopup = null


}