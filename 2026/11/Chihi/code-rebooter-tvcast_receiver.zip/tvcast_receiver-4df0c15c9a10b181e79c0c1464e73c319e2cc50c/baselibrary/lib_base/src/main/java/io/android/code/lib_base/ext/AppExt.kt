package io.android.code.lib_base.ext

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.util.Log
import io.android.code.lib_base.appContext
import io.android.code.lib_base.currentActivity

fun String.openApp(pkName:String = appContext.packageName) {
    val packageManager = appContext.packageManager
    val parts = this.split("/")

    if (parts.size == 2) {
        val packageName = parts[0]
        val activityClassName = if (parts[1].startsWith(".")) {
            // 如果 activityName 以 "." 开头，自动补全完整路径
            packageName + parts[1]
        } else {
            parts[1]
        }
        val intent = Intent().setClassName(packageName, activityClassName).apply {
            data = Uri.fromParts("package", pkName, null)
        }
        currentActivity?.startActivity(intent)
    } else {
        val packageName = this
        var intent = packageManager.getLaunchIntentForPackage(packageName)
        if(intent==null)intent = packageManager.getLeanbackLaunchIntentForPackage(packageName)
        if (intent != null) {
            currentActivity?.startActivity(intent)
        } else {
            // 如果找不到启动 Intent，尝试打开应用商店页面
            try {
                currentActivity?.startActivity(
                    Intent(
                        Intent.ACTION_VIEW,
                        Uri.parse("market://details?id=$packageName")
                    ).apply {
                        setPackage("com.android.vending") // 强制指定 Google Play
                    }
                )
            } catch (e: ActivityNotFoundException) {
                // 如果没有应用商店应用，打开网页版
                currentActivity?.startActivity(
                    Intent(
                        Intent.ACTION_VIEW,
                        Uri.parse("https://play.google.com/store/apps/details?id=$packageName")
                    )
                )
            }
        }
    }
}

fun Context.isAppUninstallable(packageName: String): Boolean {
    return try {
        val packageManager = packageManager
        val applicationInfo = packageManager.getApplicationInfo(packageName, 0)

        // 检查应用是否是系统应用或被标记为不可卸载
        val isSystemApp = applicationInfo.flags and ApplicationInfo.FLAG_SYSTEM != 0
        val isUpdatedSystemApp =
            applicationInfo.flags and ApplicationInfo.FLAG_UPDATED_SYSTEM_APP != 0

        // 如果应用不是系统应用并且不是更新的系统应用，则可以卸载
        !isSystemApp && !isUpdatedSystemApp
    } catch (e: PackageManager.NameNotFoundException) {
        // 如果包名未找到，则认为不可卸载
        false
    }
}




private val appNameCache = mutableMapOf<String, String>()

fun String.getAppNameWithCache(): String? {
    Log.e("zeng12345", "getAppNameWithCache: 当前要转换的包名是：${this}", )
    val appname =  appNameCache[this] ?: try {
        appContext.packageManager.getApplicationInfo(this, 0)
            .loadLabel(appContext.packageManager)
            .toString()
            .also { appNameCache[this] = it }
    } catch (e: PackageManager.NameNotFoundException) {
        null
    }
    Log.e("zeng12345", "getAppNameWithCache: 获取到的用户名是：${appname}", )
    return appname
}


// 获取应用版本号（Version Code）的扩展函数
val Context.appVersionCode: Long
    get() {
        return try {
            val packageInfo: PackageInfo = packageManager.getPackageInfo(packageName, 0)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                packageInfo.longVersionCode
            } else {
                @Suppress("DEPRECATION")
                packageInfo.versionCode.toLong()
            }
        } catch (e: PackageManager.NameNotFoundException) {
            -1
        }
    }

// 获取应用版本名称（Version Name）的扩展函数
val Context.appVersionName: String
    get() {
        return try {
            val packageInfo: PackageInfo = packageManager.getPackageInfo(packageName, 0)
            packageInfo.versionName ?: "Unknown"
        } catch (e: PackageManager.NameNotFoundException) {
            "Unknown"
        }
    }

fun Context.getAppName(): String {
    return try {
        val applicationInfo = packageManager.getApplicationInfo(packageName, 0)
        packageManager.getApplicationLabel(applicationInfo).toString()
    } catch (e: PackageManager.NameNotFoundException) {
        packageName // 异常情况下返回包名
    }
}