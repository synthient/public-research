package io.android.code.lib_base.base

import android.annotation.SuppressLint
import android.graphics.Bitmap
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.RelativeLayout
import androidx.core.graphics.toColorInt
import androidx.core.view.isVisible
import androidx.viewbinding.ViewBinding
import io.android.code.lib_base.databinding.ActivityBaseWebBinding

abstract class BaseWebNativeActivity<VDB : ViewBinding, VM : BaseViewModel> : BaseVMActivity<VDB, VM>() {

    protected lateinit var mUrl: String
    protected var mWebView: WebView? = null

    // 核心初始化方法（子类必须实现）
    abstract fun provideUrl(): String

    override fun initView() {
        mUrl = provideUrl()
        initWebView()
    }


    override fun initBeforeContent() {
        hookWebView()
    }

    @SuppressLint("SetJavaScriptEnabled")
    protected open fun initWebView() {
        val binding = mBind as ActivityBaseWebBinding

        // 初始化 WebView
        mWebView = WebView(this).apply {
            layoutParams = RelativeLayout.LayoutParams(
                RelativeLayout.LayoutParams.MATCH_PARENT,
                RelativeLayout.LayoutParams.MATCH_PARENT
            )
            binding.llContainer.addView(this)

            // 基础配置
            configureWebSettings(settings)

            // 客户端设置
            webViewClient = createWebViewClient()
            webChromeClient = createWebChromeClient()

            // 加载 URL
            loadUrl(mUrl)
        }
    }

    // WebView 配置
    protected open fun configureWebSettings(settings: WebSettings?) {
        settings?.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            useWideViewPort = true
            loadWithOverviewMode = true
            cacheMode = WebSettings.LOAD_NO_CACHE
            builtInZoomControls = false
            displayZoomControls = false
            allowFileAccess = true
            mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW

            mWebView?.isFocusable = true
            mWebView?.isFocusableInTouchMode = true
            mWebView?.setBackgroundColor("#1A2C3E".toColorInt())
        }
    }

    // WebChromeClient（默认实现，可扩展）
    protected open fun createWebChromeClient(): WebChromeClient = object : WebChromeClient() {
        override fun onReceivedTitle(view: WebView?, title: String?) {
            super.onReceivedTitle(view, title)
            // 默认空实现，子类可扩展
        }
    }

    // WebViewClient（默认实现，可扩展）
    protected open fun createWebViewClient(): WebViewClient = object : WebViewClient() {
        override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
            super.onPageStarted(view, url, favicon)
        }

        override fun onPageFinished(view: WebView?, url: String?) {
            super.onPageFinished(view, url)
        }

        override fun onReceivedError(
            view: WebView?,
            request: WebResourceRequest?,
            error: WebResourceError?
        ) {
            super.onReceivedError(view, request, error)
            handleWebError()
        }
    }

    protected open fun handleWebError() {
        runOnUiThread { (mBind as ActivityBaseWebBinding).rlNoData.isVisible = true }
    }

    override fun onDestroy() {
        mWebView?.apply {
            stopLoading()
            clearHistory()
            clearCache(true)
            loadUrl("about:blank")
            removeAllViews()
            destroy()
        }
        mWebView = null
        super.onDestroy()
    }

    override fun onBackPressed() {
        if (mWebView?.canGoBack() == true) {
            mWebView?.goBack()
        } else {
            super.onBackPressed()
        }
    }
}
