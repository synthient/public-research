package com_github_lib_base.ext

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ResolveInfo
import android.graphics.drawable.Drawable
import android.widget.ImageView
import com.bumptech.glide.Glide
import io.android.code.lib_base.appContext
import io.android.code.lib_base.bean.FavoriteApp

fun Context.getLaunchableApps(): List<FavoriteApp> {
    val packageManager = this.packageManager
    return arrayOf(
        Intent.CATEGORY_LEANBACK_LAUNCHER,
        Intent.CATEGORY_LAUNCHER,
    ).flatMap { category ->
        val intent = Intent(Intent.ACTION_MAIN).addCategory(category)
        packageManager.queryIntentActivities(intent,0)
    }.distinctBy { it.activityInfo.packageName }
        .map { it.toApp(packageManager) }
}

 fun ResolveInfo.toApp(packageManager: PackageManager) = FavoriteApp(
    id = "app:${activityInfo.packageName}",

    displayName = activityInfo.loadLabel(packageManager).toString(),
    packageName = activityInfo.packageName,

    launchIntentUriDefault = packageManager.getLaunchIntentForPackage(activityInfo.packageName)?.toUri(0),
    launchIntentUriLeanback = packageManager.getLeanbackLaunchIntentForPackage(activityInfo.packageName)?.toUri(0),

    favoriteOrder = null,
)

fun FavoriteApp.launchIntent(){
    val launchIntentUri = this.launchIntentUriLeanback ?: this.launchIntentUriDefault


    if (launchIntentUri != null) {
        appContext.startActivity(Intent.parseUri(launchIntentUri, 0))
    }
}

fun FavoriteApp.createDrawable(context: Context): Drawable {
    val packageManager = context.packageManager
    val intent = Intent.parseUri(launchIntentUriLeanback ?: launchIntentUriDefault, 0)

    return try {
        packageManager.getActivityBanner(intent) ?: packageManager.getActivityIcon(intent)
    } catch (err: PackageManager.NameNotFoundException) {
        packageManager.defaultActivityIcon
    }
}

fun FavoriteApp.loadAppDrawable(context: Context, ivBanner: ImageView,ivIcon: ImageView): Drawable {
    val packageManager = context.packageManager
    val intent = Intent.parseUri(launchIntentUriLeanback ?: launchIntentUriDefault, 0)

    val drawable = try {
        packageManager.getActivityBanner(intent) ?: packageManager.getActivityIcon(intent)
    } catch (err: PackageManager.NameNotFoundException) {
        packageManager.defaultActivityIcon
    }

    // 判断是否是 Banner
    val isBanner = drawable.isBanner()

    // 写死大小：Banner -> 320x180，Icon -> 96x96
    val (targetWidth, targetHeight) = if (isBanner) {
        320 to 180
    } else {
        96 to 96
    }

    Glide.with(context)
        .load(drawable)
        .override(targetWidth, targetHeight)
        .centerInside()
        .into(if(isBanner)ivBanner else ivIcon)

    return drawable
}


fun Drawable.isBanner(): Boolean {
    val width = this.intrinsicWidth
    val height = this.intrinsicHeight
    // 判断宽高比是否接近横屏（如大于 1.5:1）
    return width > 0 && height > 0 && width.toFloat() / height > 1.5f
}


// 获取已安装的应用 ResolveInfo 列表
 fun Context.getInstalledApps(): List<ResolveInfo> {
    val intent = Intent(Intent.ACTION_MAIN).apply {
        addCategory(Intent.CATEGORY_LAUNCHER)
    }
    return packageManager.queryIntentActivities(intent, 0)
}





fun String.getAppIconByPackage(context: Context): Drawable {
    val packageManager = context.packageManager
    return try {
        // 获取应用的启动意图
        val intent = packageManager.getLeanbackLaunchIntentForPackage(this)
            ?: packageManager.getLaunchIntentForPackage(this)
            ?: return packageManager.defaultActivityIcon

        // 优先获取横幅图标，不存在则获取活动图标
        packageManager.getActivityBanner(intent)
            ?: packageManager.getActivityIcon(intent)
            ?: packageManager.defaultActivityIcon
    } catch (e: PackageManager.NameNotFoundException) {
        packageManager.defaultActivityIcon
    }
}

fun String.getAppIcon(context: Context): Drawable {
    val packageManager = context.packageManager
    return try {
        // 获取应用的启动意图
        val intent = packageManager.getLeanbackLaunchIntentForPackage(this)
            ?: packageManager.getLaunchIntentForPackage(this)
            ?: return packageManager.defaultActivityIcon

        // 优先获取横幅图标，不存在则获取活动图标
        packageManager.getActivityIcon(intent)
            ?: packageManager.defaultActivityIcon
    } catch (e: PackageManager.NameNotFoundException) {
        packageManager.defaultActivityIcon
    }
}

fun String.getFavoriteAppByPackageName(): FavoriteApp? {
    if (this.isBlank()) return null
    val packageManager = appContext.packageManager
    return try {
        val appInfo = packageManager.getApplicationInfo(this, 0)
        FavoriteApp(
            id = "app:$this",
            displayName = appInfo.loadLabel(packageManager).toString(),
            packageName = this,
            launchIntentUriDefault = packageManager.getLaunchIntentForPackage(this)?.toUri(0),
            launchIntentUriLeanback = packageManager.getLeanbackLaunchIntentForPackage(this)?.toUri(0),
            favoriteOrder = null
        )
    } catch (e: PackageManager.NameNotFoundException) {
        null
    }
}