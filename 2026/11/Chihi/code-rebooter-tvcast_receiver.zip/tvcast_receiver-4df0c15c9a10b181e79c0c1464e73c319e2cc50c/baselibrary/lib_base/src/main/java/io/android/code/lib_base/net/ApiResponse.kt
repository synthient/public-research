package io.android.code.lib_base.net

data class ApiResponse<T>(
    val code: Int,
    val data: T?,
    val msg: String
)
