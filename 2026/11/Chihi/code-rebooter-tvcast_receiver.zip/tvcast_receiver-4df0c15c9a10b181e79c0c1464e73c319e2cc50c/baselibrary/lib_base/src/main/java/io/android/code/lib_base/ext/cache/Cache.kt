import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import io.android.code.lib_base.appContext

inline fun <reified T> preference(
    key: String,
    defaultValue: T
): PreferenceDelegate<T> {
    val type = object : TypeToken<T>() {}.type
    return PreferenceDelegate(
        context = appContext,
        key = key,
        defaultValue = defaultValue,
        deserializer = { Gson().fromJson(it, type) }
    )
}