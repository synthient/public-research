package io.android.code.lib_base.ext.rv

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import kotlin.reflect.KClass

class DslAdapter(
    internal val items: MutableList<Any>,
    private val typeConfig: Map<KClass<*>, (Any) -> Int>,
    private val bindAction: (BindAdapter) -> Unit
) : RecyclerView.Adapter<BindAdapter>() {

    override fun getItemViewType(position: Int): Int {
        val item = items[position]
        val layoutProvider = typeConfig[item::class]
        return layoutProvider?.invoke(item) ?: super.getItemViewType(position)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): BindAdapter {
        val view = LayoutInflater.from(parent.context).inflate(viewType, parent, false)
        return BindAdapter(view)
    }

    override fun onBindViewHolder(holder: BindAdapter, position: Int) {
        val item = items[position]
        holder.bindAdapter(this) // 直接在 holder 上绑定 adapter
        holder.bind(item)       // 直接在 holder 上绑定数据
        bindAction(holder)      // 直接使用 holder 调用 bindAction
    }


    override fun getItemCount(): Int = items.size

    /*class DslViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView)*/
}
