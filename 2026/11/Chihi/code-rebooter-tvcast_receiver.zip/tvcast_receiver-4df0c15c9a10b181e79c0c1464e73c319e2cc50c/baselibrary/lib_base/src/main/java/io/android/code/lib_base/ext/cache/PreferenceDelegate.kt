import android.content.Context
import androidx.core.content.edit
import com.google.gson.Gson
import kotlin.properties.ReadWriteProperty
import kotlin.reflect.KProperty

class PreferenceDelegate<T>(
    private val context: Context,
    private val key: String,
    private val defaultValue: T,
    private val serializer: (T) -> String = { Gson().toJson(it) },
    private val deserializer: (String) -> T
) : ReadWriteProperty<Any?, T> {

    private val sharedPreferences by lazy {
        context.getSharedPreferences("AppPreferences", Context.MODE_PRIVATE)
    }

    override fun getValue(thisRef: Any?, property: KProperty<*>): T {
        val value = sharedPreferences.getString(key, null)
        return value?.let { deserializer(it) } ?: defaultValue
    }

    override fun setValue(thisRef: Any?, property: KProperty<*>, value: T) {
        sharedPreferences.edit {
            putString(key, serializer(value))
        }
    }
}