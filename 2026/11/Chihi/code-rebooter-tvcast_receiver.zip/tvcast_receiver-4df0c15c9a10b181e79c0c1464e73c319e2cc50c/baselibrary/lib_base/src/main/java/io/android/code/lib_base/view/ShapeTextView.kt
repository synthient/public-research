package io.android.code.lib_base.view

import ShapeStyleHelper
import android.content.Context
import android.util.AttributeSet
import androidx.appcompat.widget.AppCompatTextView

class ShapeTextView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : AppCompatTextView(context, attrs, defStyleAttr) {

    private val styleHelper = ShapeStyleHelper(this)

    init {
        styleHelper.init(context, attrs)
        // 焦点监听（处理shape_solidFocusedColor等属性）
        setOnFocusChangeListener { _, hasFocus ->
            if (hasFocus) styleHelper.updateState()
        }
    }

    override fun drawableStateChanged() {
        super.drawableStateChanged()
        styleHelper.updateState()
    }
}