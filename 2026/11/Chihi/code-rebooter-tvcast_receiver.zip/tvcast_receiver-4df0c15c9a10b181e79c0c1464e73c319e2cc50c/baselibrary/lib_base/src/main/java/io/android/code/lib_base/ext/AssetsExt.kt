package io.android.code.lib_base.ext

import com.google.gson.Gson
import io.android.code.lib_base.appContext
import java.io.BufferedReader
import java.io.InputStreamReader

// 扩展函数，用于从 assets 目录读取 JSON 文件并解析为指定的 Bean 类型
inline fun <reified T> readJsonFromAssets(fileName: String = "home.json"): T? {
    return try {
        // 打开 assets 目录下的文件
        val inputStream = appContext.assets.open(fileName)  // "this" 指代调用该扩展函数的字符串（文件名）
        val bufferedReader = BufferedReader(InputStreamReader(inputStream))

        // 将文件内容读取为 String
        val jsonString = bufferedReader.use { it.readText() }

        // 使用 Gson 或其他 JSON 库将 String 转换为指定类型的对象
        Gson().fromJson(jsonString, T::class.java)
    } catch (e: Exception) {
        e.printStackTrace()
        null
    }
}