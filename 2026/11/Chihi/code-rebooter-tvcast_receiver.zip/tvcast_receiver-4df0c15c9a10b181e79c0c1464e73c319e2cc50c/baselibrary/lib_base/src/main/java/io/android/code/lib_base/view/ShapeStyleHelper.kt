import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.util.AttributeSet
import android.view.View
import android.widget.CompoundButton
import android.widget.TextView
import io.android.code.lib_base.R

class ShapeStyleHelper(private val view: View) {
    // 背景与边框
    private val backgroundDrawable = GradientDrawable()
    private var solidColorStateList: ColorStateList? = null
    private var strokeColorStateList: ColorStateList? = null
    private var strokeWidth: Int = 0  // 显式保存边框宽度

    // 文本颜色
    private var textColorStateList: ColorStateList? = null

    // 按钮图标（CheckBox/RadioButton）
    private var buttonDrawableStateList: StateListDrawable? = null

    fun init(context: Context, attrs: AttributeSet?) {
        context.obtainStyledAttributes(attrs, R.styleable.ShapeView).apply {
            try {
                // 圆角解析（支持8个方向）
                val defaultRadius = getDimension(R.styleable.ShapeView_shape_radius, 0f)
                backgroundDrawable.cornerRadii = floatArrayOf(
                    getDimension(R.styleable.ShapeView_shape_radiusInTopLeft, defaultRadius),
                    getDimension(R.styleable.ShapeView_shape_radiusInTopLeft, defaultRadius),
                    getDimension(R.styleable.ShapeView_shape_radiusInTopRight, defaultRadius),
                    getDimension(R.styleable.ShapeView_shape_radiusInTopRight, defaultRadius),
                    getDimension(R.styleable.ShapeView_shape_radiusInBottomRight, defaultRadius),
                    getDimension(R.styleable.ShapeView_shape_radiusInBottomRight, defaultRadius),
                    getDimension(R.styleable.ShapeView_shape_radiusInBottomLeft, defaultRadius),
                    getDimension(R.styleable.ShapeView_shape_radiusInBottomLeft, defaultRadius)
                )

                // 填充色（6种状态）
                solidColorStateList = createColorStateList(
                    defaultColor = getColor(R.styleable.ShapeView_shape_solidColor, Color.TRANSPARENT),
                    pressedColor = getColor(R.styleable.ShapeView_shape_solidPressedColor, Color.TRANSPARENT),
                    checkedColor = getColor(R.styleable.ShapeView_shape_solidCheckedColor, Color.TRANSPARENT),
                    disabledColor = getColor(R.styleable.ShapeView_shape_solidDisabledColor, Color.TRANSPARENT),
                    focusedColor = getColor(R.styleable.ShapeView_shape_solidFocusedColor, Color.TRANSPARENT),
                    selectedColor = getColor(R.styleable.ShapeView_shape_solidSelectedColor, Color.TRANSPARENT)
                )

                // 边框（颜色+宽度）
                strokeColorStateList = createColorStateList(
                    defaultColor = getColor(R.styleable.ShapeView_shape_strokeColor, Color.TRANSPARENT),
                    pressedColor = getColor(R.styleable.ShapeView_shape_strokePressedColor, Color.TRANSPARENT),
                    checkedColor = getColor(R.styleable.ShapeView_shape_strokeCheckedColor, Color.TRANSPARENT),
                    disabledColor = getColor(R.styleable.ShapeView_shape_strokeDisabledColor, Color.TRANSPARENT),
                    focusedColor = getColor(R.styleable.ShapeView_shape_strokeFocusedColor, Color.TRANSPARENT),
                    selectedColor = getColor(R.styleable.ShapeView_shape_strokeSelectedColor, Color.TRANSPARENT)
                )
                strokeWidth = getDimension(R.styleable.ShapeView_shape_strokeSize, 0f).toInt()

                // 文本颜色（6种状态）
                textColorStateList = createColorStateList(
                    defaultColor = getColor(R.styleable.ShapeView_shape_textColor, Color.BLACK),
                    pressedColor = getColor(R.styleable.ShapeView_shape_textPressedColor, Color.BLACK),
                    checkedColor = getColor(R.styleable.ShapeView_shape_textCheckedColor, Color.BLACK),
                    disabledColor = getColor(R.styleable.ShapeView_shape_textDisabledColor, Color.BLACK),
                    focusedColor = getColor(R.styleable.ShapeView_shape_textFocusedColor, Color.BLACK),
                    selectedColor = getColor(R.styleable.ShapeView_shape_textSelectedColor, Color.BLACK)
                )

                // 按钮图标（6种状态）
                buttonDrawableStateList = StateListDrawable().apply {
                    addState(intArrayOf(-android.R.attr.state_checked), getDrawable(R.styleable.ShapeView_shape_buttonDrawable))
                    addState(intArrayOf(android.R.attr.state_checked), getDrawable(R.styleable.ShapeView_shape_buttonCheckedDrawable))
                    addState(intArrayOf(android.R.attr.state_pressed), getDrawable(R.styleable.ShapeView_shape_buttonPressedDrawable))
                }

                // 应用初始背景
                view.background = backgroundDrawable
            } finally {
                recycle()
            }
        }
    }

    // 动态更新所有状态
    fun updateState() {
        val state = view.drawableState
        // 更新背景填充色
        backgroundDrawable.setColor(solidColorStateList?.getColorForState(state, Color.TRANSPARENT) ?: Color.TRANSPARENT)
        // 更新边框（颜色+宽度）
        backgroundDrawable.setStroke(
            strokeWidth,
            strokeColorStateList?.getColorForState(state, Color.TRANSPARENT) ?: Color.TRANSPARENT
        )
        // 更新文本颜色（适用于TextView）
        if (view is TextView) {
            view.setTextColor(textColorStateList?.getColorForState(state, Color.BLACK) ?: Color.BLACK)
        }
        // 更新按钮图标（适用于CompoundButton）
        if (view is CompoundButton) {
            view.buttonDrawable = buttonDrawableStateList?.getCurrent()
        }
    }

    // 创建支持6种状态的颜色列表
    private fun createColorStateList(
        defaultColor: Int, pressedColor: Int, checkedColor: Int,
        disabledColor: Int, focusedColor: Int, selectedColor: Int
    ): ColorStateList {
        return ColorStateList(
            arrayOf(
                intArrayOf(android.R.attr.state_pressed),
                intArrayOf(android.R.attr.state_checked),
                intArrayOf(-android.R.attr.state_enabled),
                intArrayOf(android.R.attr.state_focused),
                intArrayOf(android.R.attr.state_selected),
                intArrayOf()
            ),
            intArrayOf(pressedColor, checkedColor, disabledColor, focusedColor, selectedColor, defaultColor)
        )
    }
}