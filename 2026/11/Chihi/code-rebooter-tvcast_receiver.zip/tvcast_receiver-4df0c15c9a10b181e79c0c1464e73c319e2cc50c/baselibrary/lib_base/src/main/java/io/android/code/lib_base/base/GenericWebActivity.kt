package io.android.code.lib_base.base

import io.android.code.lib_base.AppCacheBase
import io.android.code.lib_base.databinding.ActivityBaseWebBinding


class GenericWebActivity : BaseWebActivity<ActivityBaseWebBinding, BaseViewModel>() {
    companion object {
        const val EXTRA_URL = "extra_url"
    }

    override fun provideUrl(): String {
        return intent.getStringExtra(EXTRA_URL) ?: "https://google.com/"
    }




}