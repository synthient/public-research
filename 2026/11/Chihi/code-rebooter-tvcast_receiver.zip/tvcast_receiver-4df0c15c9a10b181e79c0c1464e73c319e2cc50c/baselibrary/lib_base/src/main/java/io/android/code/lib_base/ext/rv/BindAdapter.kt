package io.android.code.lib_base.ext.rv

import android.view.View
import androidx.recyclerview.widget.RecyclerView
import androidx.viewbinding.ViewBinding

class BindAdapter(
    val itemView: View,

): RecyclerView.ViewHolder(itemView) {

    lateinit var data: Any private set


    lateinit var adapter: DslAdapter

    internal fun bind(model: Any) {
        this.data = model
    }

    internal fun bindAdapter(dslAdapter: DslAdapter) {
        this.adapter = dslAdapter
    }

    // 动态计算 modelPosition，基于 ViewHolder 的 layoutPosition
    val modelPosition: Int
        get() {
            return layoutPosition
        }


    inline fun <reified T> getModel(): T = data as T

    inline fun <reified VB : ViewBinding> getBinding(): VB {
        return VB::class.java.getMethod("bind", View::class.java)
            .invoke(null, itemView) as VB
    }

    val models: List<Any>
        get() = adapter.items

    val dslAdapter: DslAdapter
        get() = adapter


}

