package io.android.code.lib_base

import android.annotation.SuppressLint
import preference

object AppCacheBase {
    var isWebVisible: Boolean  = false
}