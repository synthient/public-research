package io.android.code.lib_base.base

import androidx.lifecycle.LifecycleObserver
import androidx.lifecycle.ViewModel

/**
 *
 * @ProjectName:  Ispruz_android
 * @Desc:
 * @Author:  zengyue
 * @Date:  2022/10/19 17:18
 * @PACKAGE_NAME:  com.thumbsupec.lib_base.base
 */
open class BaseViewModel: ViewModel(),LifecycleObserver{

}