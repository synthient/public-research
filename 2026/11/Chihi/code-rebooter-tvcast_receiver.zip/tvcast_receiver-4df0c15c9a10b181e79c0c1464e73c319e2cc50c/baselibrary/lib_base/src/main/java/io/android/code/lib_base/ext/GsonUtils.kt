package io.android.code.lib_base.ext

import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import java.lang.reflect.Type

/**
 * Gson 工具类，封装 Gson 的序列化和反序列化操作
 */
object GsonUtils {
    private val gson: Gson by lazy { Gson() } // 保持 private

    /**
     * 将对象序列化为 JSON 字符串
     */
    fun toJson(src: Any?): String = gson.toJson(src)

    /**
     * 将 JSON 字符串反序列化为指定类型的对象
     */
    fun <T> fromJson(json: String, type: Type): T {
        return try {
            gson.fromJson(json, type)
        } catch (e: Exception) {
            throw GsonConversionException("Failed to convert JSON to type $type", e)
        }
    }
}

/**
 * 自定义异常类，用于 Gson 转换错误
 */
class GsonConversionException(message: String, cause: Throwable? = null) : RuntimeException(message, cause)

/**
 * 将对象转换为 Map
 */
inline fun <reified K, reified V> Any.toMap(): Map<K, V> {
    return try {
        val json = GsonUtils.toJson(this)
        GsonUtils.fromJson(json, object : TypeToken<Map<K, V>>() {}.type)
    } catch (e: GsonConversionException) {
        emptyMap()
    }
}

/**
 * 将 JSON 字符串转换为 Map
 */
inline fun <reified K, reified V> String.toMap(): Map<K, V> {
    return try {
        GsonUtils.fromJson(this, object : TypeToken<Map<K, V>>() {}.type)
    } catch (e: GsonConversionException) {
        emptyMap()
    }
}

/**
 * 将 JSON 字符串转换为指定类型的 Bean
 */
inline fun <reified T : Any> String.jsonToBean(): T {
    return GsonUtils.fromJson(this, object : TypeToken<T>() {}.type)
}

/**
 * 将对象转换为 JSON 字符串
 */
fun <T : Any> T.jsonToString(): String { // 移除 inline
    return GsonUtils.toJson(this)
}

/**
 * 将 JSON 字符串转换为复杂类型（如 List、Map 等）
 */
inline fun <reified T : Any> String.jsonToTypeBean(): T {
    return GsonUtils.fromJson(this, object : TypeToken<T>() {}.type)
}