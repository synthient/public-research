package io.android.code.lib_base.base

import android.annotation.SuppressLint
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.FragmentActivity
import androidx.viewbinding.ViewBinding
import io.android.code.lib_base.databinding.ViewRootBinding
import java.lang.reflect.ParameterizedType

/**
 *
 * @ProjectName:  Ispruz_android
 * @Desc:
 * @Author:  zengyue
 * @Date:  2022/11/2 17:31
 * @PACKAGE_NAME:  com.thumbsupec.lib_base.base
 */
abstract class BaseActivity<VDB : ViewBinding> : FragmentActivity(), BaseVMView {




    val rootBinding: ViewRootBinding by lazy {
        ViewRootBinding.inflate(layoutInflater)
    }

    protected val mBind: VDB by lazy {
        var type = javaClass.genericSuperclass
        var vbClass: Class<VDB> = (type as ParameterizedType).actualTypeArguments[0] as Class<VDB>
        val method = vbClass.getDeclaredMethod("inflate", LayoutInflater::class.java)
        method.invoke(this, layoutInflater) as VDB
    }

    override fun setContentView(view: View?) {
        rootBinding.layoutBody.addView(
            view, 0, ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
            )
        )
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        initBeforeContent()
        super.setContentView(rootBinding.root)
        super.onCreate(savedInstanceState)
        initBeforeBaseLayout()
    }

     fun loadLayout() {
        setContentView(mBind.root)
        initPage()
    }


    fun initPage() {
        initView()
        initdata()
        initClick()
        initObserver()
    }


    @SuppressLint("SoonBlockedPrivateApi")
    fun hookWebView() {
        val sdkInt = Build.VERSION.SDK_INT
        try {
            val factoryClass = Class.forName("android.webkit.WebViewFactory")
            val field = factoryClass.getDeclaredField("sProviderInstance")
            field.isAccessible = true
            var sProviderInstance = field.get(null)
            if (sProviderInstance != null) {
                return // 如果 sProviderInstance 已存在，直接返回
            }

            // 根据 SDK 版本选择方法
            val getProviderClassMethod = when {
                sdkInt > 22 -> factoryClass.getDeclaredMethod("getProviderClass")
                sdkInt == 22 -> factoryClass.getDeclaredMethod("getFactoryClass")
                else -> return // 不支持低于 22 的版本
            }
            getProviderClassMethod.isAccessible = true
            val factoryProviderClass = getProviderClassMethod.invoke(factoryClass) as Class<*>

            // 获取 WebViewDelegate 类并创建实例
            val delegateClass = Class.forName("android.webkit.WebViewDelegate")
            val delegateConstructor = delegateClass.getDeclaredConstructor()
            delegateConstructor.isAccessible = true

            // 根据 SDK 版本创建 sProviderInstance
            sProviderInstance = if (sdkInt < 26) {
                val providerConstructor = factoryProviderClass.getConstructor(delegateClass)
                providerConstructor.isAccessible = true
                providerConstructor.newInstance(delegateConstructor.newInstance())
            } else {
                val chromiumMethodName = factoryClass.getDeclaredField("CHROMIUM_WEBVIEW_FACTORY_METHOD")
                chromiumMethodName.isAccessible = true
                val methodName = chromiumMethodName.get(null) as? String ?: "create"
                val staticFactory = factoryProviderClass.getMethod(methodName, delegateClass)
                staticFactory.invoke(null, delegateConstructor.newInstance())
            }

            // 设置 sProviderInstance
            if (sProviderInstance != null) {
                field.set(null, sProviderInstance)
            } else {
                Log.e("WebViewHook", "Failed to create sProviderInstance")
            }
        } catch (e: Throwable) {
            Log.e("WebViewHook", "Error during WebView hooking", e)
        }
    }


}