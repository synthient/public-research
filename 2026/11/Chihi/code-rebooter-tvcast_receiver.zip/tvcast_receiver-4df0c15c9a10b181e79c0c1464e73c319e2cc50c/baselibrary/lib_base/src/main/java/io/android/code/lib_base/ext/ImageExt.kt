package io.android.code.lib_base.ext

import android.graphics.drawable.Drawable
import androidx.core.content.ContextCompat
import io.android.code.lib_base.appContext

// Context 扩展函数，根据资源名称获取 Drawable
fun String.getDrawableByName(): Drawable? {
    val resId = appContext.resources.getIdentifier(this, "drawable", appContext.packageName)
    return if (resId != 0) {
        ContextCompat.getDrawable(appContext, resId)
    } else {
        null
    }
}
