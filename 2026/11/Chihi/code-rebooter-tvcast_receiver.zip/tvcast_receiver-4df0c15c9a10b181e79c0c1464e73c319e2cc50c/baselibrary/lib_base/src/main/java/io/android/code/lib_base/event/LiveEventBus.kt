package io.android.code.lib_base.event

import android.os.Handler
import android.os.Looper
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.Observer
import java.util.concurrent.atomic.AtomicBoolean

/**
 * 非粘性版本的 LiveEventBus，事件只消费一次，不会重复触发旧事件。
 */
object LiveEventBus {

    private val eventMap = mutableMapOf<String, SingleLiveEvent<Any>>()
    private val mainHandler = Handler(Looper.getMainLooper())

    @Suppress("UNCHECKED_CAST")
    private fun <T> getLiveEvent(key: String): SingleLiveEvent<T> {
        if (!eventMap.containsKey(key)) {
            eventMap[key] = SingleLiveEvent()
        }
        return eventMap[key] as SingleLiveEvent<T>
    }

    /** 发送事件（线程安全） */
    fun <T> post(key: String, data: T) {
        val liveEvent = getLiveEvent<T>(key)
        if (Looper.myLooper() == Looper.getMainLooper()) {
            liveEvent.value = data
        } else {
            mainHandler.post { liveEvent.value = data }
        }
    }

    /** 观察事件（只会收到一次） */
    fun <T> observe(key: String, owner: LifecycleOwner, observer: Observer<in T>) {
        getLiveEvent<T>(key).observe(owner, observer)
    }
}

/**
 * 单次事件分发的 LiveData 实现。
 * 每次 setValue() 后只会触发一次观察者回调。
 */
class SingleLiveEvent<T> : MutableLiveData<T>() {
    private val pending = AtomicBoolean(false)

    override fun observe(owner: LifecycleOwner, observer: Observer<in T>) {
        super.observe(owner) { t ->
            if (pending.compareAndSet(true, false)) {
                observer.onChanged(t)
            }
        }
    }

    override fun setValue(value: T?) {
        pending.set(true)
        super.setValue(value)
    }
}

// ===== Kotlin 扩展函数封装 =====

/** 快捷发送事件 */
inline fun <reified T> sendLiveEventData(key: String, data: T) {
    LiveEventBus.post(key, data)
}

/** 快捷接收事件 */
inline fun <reified T> LifecycleOwner.observeLiveEvent(
    key: String,
    noinline listener: (data: T) -> Unit
) {
    val observer = Observer<T> { data ->
        listener.invoke(data)
    }
    LiveEventBus.observe(key, this, observer)
}
