package io.android.code.lib_base.bean


data class FavoriteApp(
    val id: String,
    val displayName: String,
    val packageName: String,
    val launchIntentUriDefault: String?,
    val launchIntentUriLeanback: String?,
    val favoriteOrder: Long?,
    var isAdd: Boolean = false
)