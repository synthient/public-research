package io.android.code.lib_base.ext.rv

import kotlin.reflect.KClass

interface DslAdapterBuilder {
    fun <T : Any> addType(clazz: KClass<T>, layoutProvider: (T) -> Int)
    fun <T : Any> addType(clazz: KClass<T>, layoutResId: Int)
    fun onBind(action: BindAdapter.() -> Unit)
}

