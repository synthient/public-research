package io.android.code.lib_base.ext

import io.android.code.lib_base.appContext

fun Int.colorValue(): Int = appContext.resources.getColor(this, null)
fun Int.dimenValue(): Int = appContext.resources.getDimensionPixelSize(this)
fun Int.stringValue(): String = appContext.resources.getString(this)
fun Int.stringValueWithFormat(vararg args: Any?): String = appContext.resources.getString(this, *args)

