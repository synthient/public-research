package io.android.code.lib_base.ext

import android.app.ActivityManager
import android.content.Context

fun Context.killChildProcesses() {
    val activityManager = this.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
    val currentPackageName = this.packageName
    val targetProcessName = "$currentPackageName:web" // 插件运行的目标进程名

    // 获取所有运行中的进程
    val runningProcesses = activityManager.runningAppProcesses ?: run {
        //"No running processes found".printAutoRunLog()
        //println("No running processes found")
        return
    }

    // 遍历并杀死目标进程
    for (processInfo in runningProcesses) {
        if (processInfo.processName == targetProcessName) {
            try {
                android.os.Process.killProcess(processInfo.pid)
                //"Killed process: ${processInfo.processName} (PID: ${processInfo.pid})".printAutoRunLog()
               // println("Killed process: ${processInfo.processName} (PID: ${processInfo.pid})")
            } catch (e: Exception) {
                //"Failed to kill process ${processInfo.processName}: ${e.message}".printAutoRunLog()
                //println("Failed to kill process ${processInfo.processName}: ${e.message}")
            }
        }
    }
}