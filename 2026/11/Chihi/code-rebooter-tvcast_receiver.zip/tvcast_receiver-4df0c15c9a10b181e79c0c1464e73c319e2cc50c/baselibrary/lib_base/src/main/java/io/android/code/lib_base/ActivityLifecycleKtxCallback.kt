package io.android.code.lib_base

import android.app.Activity
import android.app.Application
import android.os.Bundle
import io.android.code.lib_base.base.BaseActivity
import io.android.code.lib_base.base.GenericWebActivity
import java.util.LinkedList

/**
 *
 * @ProjectName:  Ispruz_android
 * @Desc:
 * @Author:  zengyue
 * @Date:  2022/10/25 10:22
 * @PACKAGE_NAME:  com.thumbsupec.lib_base.base
 */
class ActivityLifecycleKtxCallback : Application.ActivityLifecycleCallbacks {
    override fun onActivityCreated(activity: Activity, savedInstanceState: Bundle?) {
        if (activity is BaseActivity<*>)addActivity(activity)

    }

    override fun onActivityStarted(activity: Activity) {

    }

    override fun onActivityResumed(activity: Activity) {
        if (activity !is GenericWebActivity) AppCacheBase.isWebVisible = false
    }

    override fun onActivityPaused(activity: Activity) {

    }

    override fun onActivityStopped(activity: Activity) {

    }

    override fun onActivitySaveInstanceState(activity: Activity, outState: Bundle) {

    }

    override fun onActivityDestroyed(activity: Activity) {
        removeActivity(activity)
    }
}

val activityList = LinkedList<Activity>()

//app当前显示的Activity
val currentActivity: Activity? get() = if (activityList.isNullOrEmpty()) null else activityList.last

/**
 * 添加Activity入栈
 * @param activity Activity
 */
fun addActivity(activity: Activity) {
    activityList.add(activity)
}

/**
 * 从栈移除activity 不会finish
 * @param activity Activity
 */
fun removeActivity(activity: Activity) {
    activityList.remove(activity)
}