package io.android.cast.receiver.tv.net

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class DomainCacheResetPolicyTest {

    @Test
    fun `should reset when app update is first handled and cached base url changed`() {
        val shouldReset = DomainCacheResetPolicy.shouldResetDomainCache(
            firstInstallTime = 100L,
            lastUpdateTime = 200L,
            lastHandledUpdateTime = -1L,
            cachedBaseUrl = "https://old.example.com/",
            currentBaseUrl = "https://new.example.com/"
        )

        assertTrue(shouldReset)
    }

    @Test
    fun `should not reset on first install`() {
        val shouldReset = DomainCacheResetPolicy.shouldResetDomainCache(
            firstInstallTime = 200L,
            lastUpdateTime = 200L,
            lastHandledUpdateTime = -1L,
            cachedBaseUrl = null,
            currentBaseUrl = "https://new.example.com/"
        )

        assertFalse(shouldReset)
    }

    @Test
    fun `should not reset when base url does not change during update`() {
        val shouldReset = DomainCacheResetPolicy.shouldResetDomainCache(
            firstInstallTime = 100L,
            lastUpdateTime = 200L,
            lastHandledUpdateTime = -1L,
            cachedBaseUrl = "https://same.example.com/",
            currentBaseUrl = "https://same.example.com/"
        )

        assertFalse(shouldReset)
    }

    @Test
    fun `should not reset after current update has already been handled`() {
        val shouldReset = DomainCacheResetPolicy.shouldResetDomainCache(
            firstInstallTime = 100L,
            lastUpdateTime = 200L,
            lastHandledUpdateTime = 200L,
            cachedBaseUrl = "https://old.example.com/",
            currentBaseUrl = "https://new.example.com/"
        )

        assertFalse(shouldReset)
    }
}
