package io.android.cast.receiver.tv.ext

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import io.android.cast.receiver.tv.AppCache
import io.android.cast.receiver.tv.ui.service.AirPlayService
import io.android.cast.receiver.tv.ui.service.DlnaRendererService
import io.android.cast.receiver.tv.ui.service.MiraCastService
import io.android.code.lib_base.AppCacheBase
import io.android.code.lib_base.base.GenericWebActivity
import io.android.code.lib_base.ext.startKtxActivity
import com.speed.ext.startServiceIfNotRunning
import com.speed.ext.stopCoreService
import java.util.Locale


fun Context.openPrivacyPolicy() {
    //隐私政策
    //println("当前拿到的语言是：${getLanguageTag()}")
    AppCacheBase.isWebVisible = true
    val url = "file:///android_asset/privacy_policy.html?lang=${getLanguageTag()}"
    startKtxActivity<GenericWebActivity>(
        values = arrayOf(
            Pair(GenericWebActivity.EXTRA_URL, url),
        )
    )
}

fun Context.openUserAgreement() {
    // 用户协议
    AppCacheBase.isWebVisible = true
    val url = "file:///android_asset/user_agreement.html?lang=${getLanguageTag()}"
    startKtxActivity<GenericWebActivity>(
        values = arrayOf(
            Pair(GenericWebActivity.EXTRA_URL, url),
        )
    )
}

fun Context.openDisclaimer() {
    // 免责声明
    AppCacheBase.isWebVisible = true
    val url = "file:///android_asset/disclaimer.html?lang=${getLanguageTag()}"
    startKtxActivity<GenericWebActivity>(
        values = arrayOf(
            Pair(GenericWebActivity.EXTRA_URL, url),
        )
    )
}

fun Context.openUserUsage() {
    // 使用说明
    AppCacheBase.isWebVisible = true
    val url = "file:///android_asset/screen_mirroring_tutorial.html?lang=${getLanguageTag()}"
    startKtxActivity<GenericWebActivity>(
        values = arrayOf(
            Pair(GenericWebActivity.EXTRA_URL, url),
        )
    )
}


fun getLanguageTag(): String? {
    // 获取完整的语言-地区代码
    val languageTag = Locale.getDefault().toLanguageTag()
    // 确保与translations对象中的键格式一致（如将zh-Hans-CN转换为zh-CN）
    if (languageTag.startsWith("zh-Hans")) {
        return "zh-CN" // 简体中文
    } else if (languageTag.startsWith("zh-Hant")) {
        return "zh-TW" // 繁体中文
    }
    val langStr = languageTag.split("-".toRegex()).dropLastWhile { it.isEmpty() }
        .toTypedArray()[0] // 仅取语言部分，匹配translations键
    if (langStr == "zh") return "zh-CN" // 简体中文
    // 其他语言直接返回（如en-US -> en, de-DE -> de）
    return langStr
}


fun Context.startAllService() {
    startServiceIfNotRunning(AirPlayService::class.java)
    startServiceIfNotRunning(MiraCastService::class.java)
    startServiceIfNotRunning(DlnaRendererService::class.java)
}

fun Context.stopAllService() {
    stopCoreService(AirPlayService::class.java)
    stopCoreService(MiraCastService::class.java)
    stopCoreService(DlnaRendererService::class.java)
}

