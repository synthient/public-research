// VideoSurfaceView.kt
package io.android.cast.receiver.tv.ui.view


import android.content.Context
import android.util.AttributeSet
import android.view.SurfaceView
import kotlin.math.roundToInt

class VideoSurfaceView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : SurfaceView(context, attrs, defStyleAttr) {

    private var videoWidth = 0
    private var videoHeight = 0

    fun setVideoSize(width: Int, height: Int) {
        if (width > 0 && height > 0 && (videoWidth != width || videoHeight != height)) {
            videoWidth = width
            videoHeight = height
            requestLayout() // 触发 onMeasure
        }
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        if (videoWidth <= 0 || videoHeight <= 0) {
            super.onMeasure(widthMeasureSpec, heightMeasureSpec)
            return
        }

        val viewWidth = MeasureSpec.getSize(widthMeasureSpec)
        val viewHeight = MeasureSpec.getSize(heightMeasureSpec)

        val videoRatio = videoWidth.toFloat() / videoHeight.toFloat()
        val viewRatio = viewWidth.toFloat() / viewHeight.toFloat()

        var targetWidth: Int
        var targetHeight: Int

        if (viewRatio > videoRatio) {
            // 屏幕更宽 → 按高度缩放，左右留黑
            targetHeight = viewHeight
            targetWidth = (viewHeight * videoRatio).roundToInt()
        } else {
            // 屏幕更高 → 按宽度缩放，上下留黑
            targetWidth = viewWidth
            targetHeight = (viewWidth / videoRatio).roundToInt()
        }

        val widthSpec = MeasureSpec.makeMeasureSpec(targetWidth, MeasureSpec.EXACTLY)
        val heightSpec = MeasureSpec.makeMeasureSpec(targetHeight, MeasureSpec.EXACTLY)
        super.onMeasure(widthSpec, heightSpec)
    }
}