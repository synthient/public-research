const translations = {
    "en": {
        "title": "Screen Mirroring Tutorial",
        "sections": [
            {
                "title": "Preparation",
                "list": [
                    "Ensure your smart device (e.g., smartphone, tablet, or laptop) and the screen mirroring receiver (e.g., smart TV, projector, or dedicated mirroring hardware) are connected to the same Wi-Fi network.",
                    "Check that the screen mirroring function on the receiver device is enabled."
                ]
            },
            {
                "title": "Operation Steps",
                "list": [
                    "<strong>Smartphone Mirroring</strong>",
                    "<strong>For Android Devices:</strong><ul><li>Pull down the notification bar and tap 'Cast' or 'Wireless Display'.</li><li>Select an available mirroring receiver.</li><li>Confirm the connection, and your phone’s screen will appear on the large screen.</li></ul>",
                    "<strong>For iOS Devices:</strong><ul><li>Swipe up from the bottom of the screen (or swipe down from the top-right corner on devices without a Home button) to open the Control Center.</li><li>Tap the 'Screen Mirroring' button.</li><li>Select your mirroring receiver.</li><li>If prompted, enter the mirroring password or confirm the connection.</li><li>Your iPhone or iPad screen will appear on the large screen.</li></ul>"
                ]
            },
            {
                "title": "Mirroring Tips",
                "list": [
                    "Ensure a stable network connection to avoid lagging or disconnections during mirroring.",
                    "Close unnecessary background apps during mirroring to reduce bandwidth usage.",
                    "If connection issues occur, try restarting your smart device and mirroring receiver, or check your network settings."
                ]
            },
            {
                "title": "Ending Mirroring",
                "content": "When you no longer need to mirror, you can disconnect by selecting the option in your smart device’s mirroring settings or by turning off the mirroring function."
            }
        ]
    },
    "ar": {
        "title": "دليل استخدام عكس الشاشة",
        "sections": [
            {
                "title": "التحضير",
                "list": [
                    "تأكد من أن جهازك الذكي (مثل الهاتف الذكي، الجهاز اللوحي، أو الكمبيوتر المحمول) وجهاز استقبال عكس الشاشة (مثل التلفزيون الذكي، جهاز العرض، أو أجهزة عكس مخصصة) متصلان بنفس شبكة Wi-Fi.",
                    "تحقق من أن وظيفة عكس الشاشة في جهاز الاستقبال مفعلة."
                ]
            },
            {
                "title": "خطوات التشغيل",
                "list": [
                    "<strong>عكس شاشة الهاتف الذكي</strong>",
                    "<strong>لأجهزة Android:</strong><ul><li>اسحب شريط الإشعارات للأسفل واضغط على خيار 'عكس الشاشة' أو 'العرض اللاسلكي'.</li><li>اختر جهاز استقبال عكس متاح.</li><li>أكد الاتصال، وستظهر شاشة هاتفك على الشاشة الكبيرة.</li></ul>",
                    "<strong>لأجهزة iOS:</strong><ul><li>اسحب للأعلى من أسفل الشاشة (أو اسحب للأسفل من الزاوية العلوية اليمنى في الأجهزة بدون زر الصفحة الرئيسية) لفتح مركز التحكم.</li><li>اضغط على زر 'عكس الشاشة'.</li><li>اختر جهاز استقبال العكس الخاص بك.</li><li>إذا لزم الأمر، أدخل كلمة مرور العكس أو أكد الاتصال.</li><li>ستظهر شاشة iPhone أو iPad على الشاشة الكبيرة.</li></ul>"
                ]
            },
            {
                "title": "نصائح لعكس الشاشة",
                "list": [
                    "تأكد من استقرار الاتصال بالشبكة لتجنب التأخير أو الانقطاع أثناء العكس.",
                    "أغلق التطبيقات الخلفية غير الضرورية أثناء العكس لتقليل استهلاك النطاق الترددي.",
                    "إذا واجهت مشاكل في الاتصال، حاول إعادة تشغيل جهازك الذكي وجهاز استقبال العكس، أو تحقق من إعدادات الشبكة."
                ]
            },
            {
                "title": "إنهاء العكس",
                "content": "عندما لا تحتاج إلى عكس الشاشة، يمكنك قطع الاتصال من خلال خيار في إعدادات عكس الشاشة في جهازك الذكي أو إيقاف تشغيل وظيفة العكس."
            }
        ]
    },
    "de": {
        "title": "Anleitung zur Bildschirmspiegelung",
        "sections": [
            {
                "title": "Vorbereitung",
                "list": [
                    "Stellen Sie sicher, dass Ihr Smart-Gerät (z. B. Smartphone, Tablet oder Laptop) und das Empfangsgerät für die Bildschirmspiegelung (z. B. Smart-TV, Projektor oder spezielle Spiegelungshardware) mit demselben Wi-Fi-Netzwerk verbunden sind.",
                    "Überprüfen Sie, ob die Bildschirmspiegelungsfunktion des Empfangsgeräts aktiviert ist."
                ]
            },
            {
                "title": "Bedienungsschritte",
                "list": [
                    "<strong>Smartphone-Spiegelung</strong>",
                    "<strong>Für Android-Geräte:</strong><ul><li>Ziehen Sie die Benachrichtigungsleiste herunter und tippen Sie auf 'Bildschirmübertragung' oder 'Wireless Display'.</li><li>Wählen Sie ein verfügbares Empfangsgerät aus.</li><li>Bestätigen Sie die Verbindung, und der Bildschirm Ihres Telefons wird auf dem großen Bildschirm angezeigt.</li></ul>",
                    "<strong>Für iOS-Geräte:</strong><ul><li>Wischen Sie vom unteren Bildschirmrand nach oben (oder bei Geräten ohne Home-Taste vom oberen rechten Rand nach unten), um das Kontrollzentrum zu öffnen.</li><li>Tippen Sie auf die Schaltfläche 'Bildschirmspiegelung'.</li><li>Wählen Sie Ihr Empfangsgerät für die Spiegelung aus.</li><li>Geben Sie bei Bedarf das Spiegelungspasswort ein oder bestätigen Sie die Verbindung.</li><li>Der Bildschirm Ihres iPhone oder iPad wird auf dem großen Bildschirm angezeigt.</li></ul>"
                ]
            },
            {
                "title": "Tipps zur Spiegelung",
                "list": [
                    "Sorgen Sie für eine stabile Netzwerkverbindung, um Verzögerungen oder Verbindungsabbrüche während der Spiegelung zu vermeiden.",
                    "Schließen Sie unnötige Hintergrund-Apps während der Spiegelung, um den Bandbreitenverbrauch zu reduzieren.",
                    "Falls Verbindungsprobleme auftreten, versuchen Sie, Ihr Smart-Gerät und das Empfangsgerät neu zu starten oder die Netzwerkeinstellungen zu überprüfen."
                ]
            },
            {
                "title": "Beenden der Spiegelung",
                "content": "Wenn Sie die Spiegelung nicht mehr benötigen, können Sie die Verbindung über die Spiegelungseinstellungen Ihres Smart-Geräts trennen oder die Spiegelungsfunktion deaktivieren."
            }
        ]
    },
    "es": {
        "title": "Tutorial de Duplicación de Pantalla",
        "sections": [
            {
                "title": "Preparación",
                "list": [
                    "Asegúrese de que su dispositivo inteligente (como un smartphone, tableta o portátil) y el receptor de duplicación de pantalla (como un televisor inteligente, proyector o hardware de duplicación dedicado) estén conectados a la misma red Wi-Fi.",
                    "Verifique que la función de duplicación de pantalla en el dispositivo receptor esté habilitada."
                ]
            },
            {
                "title": "Pasos de Operación",
                "list": [
                    "<strong>Duplicación de Smartphone</strong>",
                    "<strong>Para Dispositivos Android:</strong><ul><li>Deslice hacia abajo la barra de notificaciones y toque 'Transmitir' o 'Pantalla Inalámbrica'.</li><li>Seleccione un receptor de duplicación disponible.</li><li>Confirme la conexión, y la pantalla de su teléfono aparecerá en la pantalla grande.</li></ul>",
                    "<strong>Para Dispositivos iOS:</strong><ul><li>Deslice hacia arriba desde la parte inferior de la pantalla (o hacia abajo desde la esquina superior derecha en dispositivos sin botón de inicio) para abrir el Centro de Control.</li><li>Toque el botón 'Duplicar Pantalla'.</li><li>Seleccione su receptor de duplicación.</li><li>Si se le solicita, ingrese la contraseña de duplicación o confirme la conexión.</li><li>La pantalla de su iPhone o iPad aparecerá en la pantalla grande.</li></ul>"
                ]
            },
            {
                "title": "Consejos para la Duplicación",
                "list": [
                    "Asegúrese de tener una conexión de red estable para evitar retrasos o desconexiones durante la duplicación.",
                    "Cierre aplicaciones en segundo plano innecesarias durante la duplicación para reducir el uso de ancho de banda.",
                    "Si hay problemas de conexión, intente reiniciar su dispositivo inteligente y el receptor de duplicación, o verifique la configuración de red."
                ]
            },
            {
                "title": "Finalizar la Duplicación",
                "content": "Cuando ya no necesite duplicar, puede desconectar seleccionando la opción en la configuración de duplicación de su dispositivo inteligente o desactivando la función de duplicación."
            }
        ]
    },
    "fr": {
        "title": "Tutoriel de Mise en Miroir d'Écran",
        "sections": [
            {
                "title": "Préparation",
                "list": [
                    "Assurez-vous que votre appareil intelligent (comme un smartphone, une tablette ou un ordinateur portable) et le récepteur de mise en miroir (comme une télévision intelligente, un projecteur ou un matériel de mise en miroir dédié) sont connectés au même réseau Wi-Fi.",
                    "Vérifiez que la fonction de mise en miroir d'écran sur le récepteur est activée."
                ]
            },
            {
                "title": "Étapes d'Opération",
                "list": [
                    "<strong>Mise en Miroir de Smartphone</strong>",
                    "<strong>Pour les Appareils Android :</strong><ul><li>Faites glisser la barre de notifications vers le bas et appuyez sur 'Caster' ou 'Affichage Sans Fil'.</li><li>Sélectionnez un récepteur de mise en miroir disponible.</li><li>Confirmez la connexion, et l’écran de votre téléphone apparaîtra sur le grand écran.</li></ul>",
                    "<strong>Pour les Appareils iOS :</strong><ul><li>Faites glisser vers le haut depuis le bas de l’écran (ou vers le bas depuis le coin supérieur droit sur les appareils sans bouton d’accueil) pour ouvrir le Centre de Contrôle.</li><li>Appuyez sur le bouton 'Mise en Miroir d’Écran'.</li><li>Sélectionnez votre récepteur de mise en miroir.</li><li>Si nécessaire, entrez le mot de passe de mise en miroir ou confirmez la connexion.</li><li>L’écran de votre iPhone ou iPad apparaîtra sur le grand écran.</li></ul>"
                ]
            },
            {
                "title": "Conseils pour la Mise en Miroir",
                "list": [
                    "Assurez-vous d’avoir une connexion réseau stable pour éviter les retards ou les déconnexions pendant la mise en miroir.",
                    "Fermez les applications en arrière-plan inutiles pendant la mise en miroir pour réduire l’utilisation de la bande passante.",
                    "En cas de problèmes de connexion, essayez de redémarrer votre appareil intelligent et le récepteur de mise en miroir, ou vérifiez les paramètres réseau."
                ]
            },
            {
                "title": "Arrêter la Mise en Miroir",
                "content": "Lorsque vous n’avez plus besoin de mettre en miroir, vous pouvez déconnecter en sélectionnant l’option dans les paramètres de mise en miroir de votre appareil intelligent ou en désactivant la fonction de mise en miroir."
            }
        ]
    },
    "it": {
        "title": "Tutorial sulla Duplicazione dello Schermo",
        "sections": [
            {
                "title": "Preparazione",
                "list": [
                    "Assicurati che il tuo dispositivo intelligente (come smartphone, tablet o laptop) e il ricevitore di duplicazione dello schermo (come una smart TV, un proiettore o hardware dedicato) siano connessi alla stessa rete Wi-Fi.",
                    "Verifica che la funzione di duplicazione dello schermo sul dispositivo ricevente sia attivata."
                ]
            },
            {
                "title": "Passaggi Operativi",
                "list": [
                    "<strong>Duplicazione dello Smartphone</strong>",
                    "<strong>Per Dispositivi Android:</strong><ul><li>Scorri verso il basso la barra delle notifiche e tocca 'Trasmetti' o 'Display Wireless'.</li><li>Seleziona un ricevitore di duplicazione disponibile.</li><li>Conferma la connessione, e lo schermo del tuo telefono apparirà sul grande schermo.</li></ul>",
                    "<strong>Per Dispositivi iOS:</strong><ul><li>Scorri verso l’alto dal bordo inferiore dello schermo (o verso il basso dall’angolo superiore destro sui dispositivi senza pulsante Home) per aprire il Centro di Controllo.</li><li>Tocca il pulsante 'Duplicazione Schermo'.</li><li>Seleziona il tuo ricevitore di duplicazione.</li><li>Se richiesto, inserisci la password di duplicazione o conferma la connessione.</li><li>Lo schermo del tuo iPhone o iPad appar Ascolta apparirà sul grande schermo.</li></ul>"
                ]
            },
            {
                "title": "Consigli per la Duplicazione",
                "list": [
                    "Assicurati che la connessione di rete sia stabile per evitare ritardi o disconnessioni durante la duplicazione.",
                    "Chiudi le applicazioni in background non necessarie durante la duplicazione per ridurre l’uso della larghezza di banda.",
                    "In caso di problemi di connessione, prova a riavviare il tuo dispositivo intelligente e il ricevitore di duplicazione, o verifica le impostazioni di rete."
                ]
            },
            {
                "title": "Terminare la Duplicazione",
                "content": "Quando non hai più bisogno di duplicare, puoi disconnetterti selezionando l’opzione nelle impostazioni di duplicazione del tuo dispositivo intelligente o disattivando la funzione di duplicazione."
            }
        ]
    },
    "ja": {
        "title": "スクリーンミラーリングチュートリアル",
        "sections": [
            {
                "title": "準備",
                "list": [
                    "スマートデバイス（スマートフォン、タブレット、ノートパソコンなど）とミラーリング受信デバイス（スマートテレビ、プロジェクター、専用ミラーリングハードウェアなど）が同じWi-Fiネットワークに接続されていることを確認してください。",
                    "受信デバイスのスクリーンミラーリング機能が有効になっていることを確認してください。"
                ]
            },
            {
                "title": "操作手順",
                "list": [
                    "<strong>スマートフォンのミラーリング</strong>",
                    "<strong>Androidデバイスの場合:</strong><ul><li>通知バーを下にスワイプし、「キャスト」または「ワイヤレスディスプレイ」をタップします。</li><li>利用可能なミラーリング受信デバイスを選択します。</li><li>接続を確認すると、スマートフォンの画面が大画面に表示されます。</li></ul>",
                    "<strong>iOSデバイスの場合:</strong><ul><li>画面下部から上にスワイプ（またはホームボタンのないデバイスでは右上から下にスワイプ）してコントロールセンターを開きます。</li><li>「スクリーンミラーリング」ボタンをタップします。</li><li>ミラーリング受信デバイスを選択します。</li><li>必要に応じて、ミラーリングパスワードを入力または接続を確認します。</li><li>iPhoneまたはiPadの画面が大画面に表示されます。</li></ul>"
                ]
            },
            {
                "title": "ミラーリングのヒント",
                "list": [
                    "ミラーリング中に遅延や切断を避けるため、ネットワーク接続が安定していることを確認してください。",
                    "ミラーリング中に不要なバックグラウンドアプリを閉じて、帯域幅の使用を減らしてください。",
                    "接続に問題が発生した場合は、スマートデバイスとミラーリング受信デバイスを再起動するか、ネットワーク設定を確認してください。"
                ]
            },
            {
                "title": "ミラーリングの終了",
                "content": "ミラーリングが不要になった場合、スマートデバイスのミラーリング設定で切断オプションを選択するか、ミラーリング機能をオフにしてください。"
            }
        ]
    },
    "ko": {
        "title": "스크린 미러링 튜토리얼",
        "sections": [
            {
                "title": "준비",
                "list": [
                    "스마트 기기(스마트폰, 태블릿, 노트북 등)와 미러링 수신 기기(스마트 TV, 프로젝터, 전용 미러링 하드웨어 등)가 동일한 Wi-Fi 네트워크에 연결되어 있는지 확인하세요.",
                    "수신 기기의 스크린 미러링 기능이 활성화되어 있는지 확인하세요."
                ]
            },
            {
                "title": "작업 단계",
                "list": [
                    "<strong>스마트폰 미러링</strong>",
                    "<strong>Android 기기의 경우:</strong><ul><li>알림 바를 아래로 스와이프하여 '캐스트' 또는 '무선 디스플레이'를 탭하세요.</li><li>사용 가능한 미러링 수신 기기를 선택하세요.</li><li>연결을 확인하면 스마트폰 화면이 큰 화면에 표시됩니다.</li></ul>",
                    "<strong>iOS 기기의 경우:</strong><ul><li>화면 하단에서 위로 스와이프(또는 홈 버튼이 없는 기기에서는 오른쪽 상단에서 아래로 스와이프)하여 제어 센터를 엽니다.</li><li>'스크린 미러링' 버튼을 탭하세요.</li><li>미러링 수신 기기를 선택하세요.</li><li>필요한 경우 미러링 비밀번호를 입력하거나 연결을 확인하세요.</li><li>iPhone 또는 iPad 화면이 큰 화면에 표시됩니다.</li></ul>"
                ]
            },
            {
                "title": "미러링 팁",
                "list": [
                    "미러링 중 지연이나 연결 끊김을 방지하려면 네트워크 연결이 안정적인지 확인하세요.",
                    "미러링 중 불필요한 백그라운드 앱을 닫아 대역폭 사용을 줄이세요.",
                    "연결 문제가 발생하면 스마트 기기와 미러링 수신 기기를 재부팅하거나 네트워크 설정을 확인하세요."
                ]
            },
            {
                "title": "미러링 종료",
                "content": "미러링이 더 이상 필요하지 않을 때, 스마트 기기의 미러링 설정에서 연결 해제 옵션을 선택하거나 미러링 기능을 끄세요."
            }
        ]
    },
    "ru": {
        "title": "Руководство по зеркалированию экрана",
        "sections": [
            {
                "title": "Подготовка",
                "list": [
                    "Убедитесь, что ваше смарт-устройство (например, смартфон, планшет или ноутбук) и устройство-приемник зеркалирования (например, смарт-телевизор, проектор или специализированное оборудование для зеркалирования) подключены к одной сети Wi-Fi.",
                    "Проверьте, включена ли функция зеркалирования экрана на устройстве-приемнике."
                ]
            },
            {
                "title": "Шаги по выполнению",
                "list": [
                    "<strong>Зеркалирование смартфона</strong>",
                    "<strong>Для устройств Android:</strong><ul><li>Проведите вниз по панели уведомлений и нажмите 'Трансляция' или 'Беспроводной дисплей'.</li><li>Выберите доступное устройство-приемник зеркалирования.</li><li>Подтвердите соединение, и экран вашего телефона появится на большом экране.</li></ul>",
                    "<strong>Для устройств iOS:</strong><ul><li>Проведите вверх от нижнего края экрана (или вниз от правого верхнего угла на устройствах без кнопки 'Домой'), чтобы открыть Центр управления.</li><li>Нажмите кнопку 'Зеркалирование экрана'.</li><li>Выберите устройство-приемник зеркалирования.</li><li>При необходимости введите пароль для зеркалирования или подтвердите соединение.</li><li>Экран вашего iPhone или iPad появится на большом экране.</li></ul>"
                ]
            },
            {
                "title": "Советы по зеркалированию",
                "list": [
                    "Убедитесь в стабильности сетевого соединения, чтобы избежать задержек или разрывов во время зеркалирования.",
                    "Закройте ненужные фоновые приложения во время зеркалирования, чтобы уменьшить использование пропускной способности.",
                    "Если возникают проблемы с соединением, попробуйте перезагрузить смарт-устройство и устройство-приемник зеркалирования или проверьте настройки сети."
                ]
            },
            {
                "title": "Завершение зеркалирования",
                "content": "Когда зеркалирование больше не требуется, вы можете отключиться, выбрав соответствующую опцию в настройках зеркалирования вашего смарт-устройства или выключив функцию зеркалирования."
            }
        ]
    },
    "zh-CN": {
        "title": "投屏使用教程",
        "sections": [
            {
                "title": "准备工作",
                "list": [
                    "确保您的智能设备（如智能手机、平板电脑或笔记本电脑）和投屏接收设备（如智能电视、投影仪或专用的投屏硬件）已连接到同一个Wi-Fi网络。",
                    "检查投屏接收设备的投屏功能是否已经开启。"
                ]
            },
            {
                "title": "操作步骤",
                "list": [
                    "<strong>智能手机投屏</strong>",
                    "<strong>对于Android设备：</strong><ul><li>下拉通知栏，找到并点击“投屏”或“无线显示”选项。</li><li>选择可用的投屏接收设备。</li><li>确认连接，您的手机屏幕内容将显示在大屏幕上。</li></ul>",
                    "<strong>对于iOS设备：</strong><ul><li>从屏幕底部向上滑动（或在没有Home键的设备上从屏幕右上角向下滑动）打开控制中心。</li><li>点击“屏幕镜像”按钮。</li><li>选择您的投屏接收设备。</li><li>如果需要，输入投屏密码或确认连接。</li><li>您的iPhone或iPad屏幕内容将显示在大屏幕上。</li></ul>"
                ]
            },
            {
                "title": "投屏技巧",
                "list": [
                    "确保网络连接稳定，以避免投屏过程中出现卡顿或断开。",
                    "在投屏时，关闭不必要的后台应用，以减少对网络带宽的占用。",
                    "如果遇到连接问题，尝试重启智能设备和投屏接收设备，或检查网络设置。"
                ]
            },
            {
                "title": "结束投屏",
                "content": "当您不再需要投屏时，可以在智能设备的投屏设置中选择断开连接，或直接关闭投屏功能。"
            }
        ]
    },
    "zh-TW": {
        "title": "投屏使用教程",
        "sections": [
            {
                "title": "準備工作",
                "list": [
                    "確保您的智慧設備（如智慧型手機、平板電腦或筆記型電腦）與投屏接收設備（如智慧型電視、投影機或專用投屏硬體）已連接到同一個Wi-Fi網路。",
                    "檢查投屏接收設備的投屏功能是否已開啟。"
                ]
            },
            {
                "title": "操作步驟",
                "list": [
                    "<strong>智慧型手機投屏</strong>",
                    "<strong>對於Android設備：</strong><ul><li>下拉通知欄，找到並點擊「投屏」或「無線顯示」選項。</li><li>選擇可用的投屏接收設備。</li><li>確認連線，您的手機螢幕內容將顯示在大螢幕上。</li></ul>",
                    "<strong>對於iOS設備：</strong><ul><li>從螢幕底部向上滑動（或在無Home鍵的設備上從螢幕右上角向下滑動）開啟控制中心。</li><li>點擊「螢幕鏡像」按鈕。</li><li>選擇您的投屏接收設備。</li><li>如需要，輸入投屏密碼或確認連線。</li><li>您的iPhone或iPad螢幕內容將顯示在大螢幕上。</li></ul>"
                ]
            },
            {
                "title": "投屏技巧",
                "list": [
                    "確保網路連線穩定，以避免投屏過程中出現卡頓或斷開。",
                    "在投屏時，關閉不必要的後台應用程式，以減少對網路頻寬的占用。",
                    "如果遇到連線問題，嘗試重新啟動智慧設備和投屏接收設備，或檢查網路設定。"
                ]
            },
            {
                "title": "結束投屏",
                "content": "當您不再需要投屏時，可在智慧設備的投屏設定中選擇斷開連線，或直接關閉投屏功能。"
            }
        ]
    }
};

function getLangFromUrl() {
    const params = new URLSearchParams(window.location.search);
    return params.get('lang') || 'en'; // 默认英语
}

function loadLanguage(lang) {
    try {
        const data = translations[lang] || translations['en'];
        const source = document.getElementById('tutorial-template').innerHTML;
        const template = Handlebars.compile(source);
        document.getElementById('tutorial-container').innerHTML = template(data);
        document.getElementById('page-title').textContent = data.title;
        document.documentElement.lang = lang;
    } catch (error) {
        console.error('Language rendering error:', error);
        loadLanguage('en');
    }
}

// 暴露给 Android 原生调用的函数
window.switchLanguage = function(lang) {
    loadLanguage(lang || 'en');
};

// 根据 URL 参数加载语言
const lang = getLangFromUrl();
loadLanguage(lang);