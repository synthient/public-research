package io.android.cast.receiver.tv.ui.dialog

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.os.Bundle
import android.os.IBinder
import android.view.Gravity
import android.view.ViewGroup
import android.view.WindowManager
import androidx.annotation.OptIn
import androidx.media3.common.util.UnstableApi
import io.android.cast.receiver.tv.constants.MIRROER_DISCONNECT
import io.android.cast.receiver.tv.databinding.DialogMiracastMirrorBinding
import io.android.cast.receiver.tv.ui.dialog.base.BaseDialogFragment
import io.android.cast.receiver.tv.ui.service.MiraCastService
import io.android.cast.receiver.tv.ui.view.MirrorReceiver
import io.android.cast.receiver.tv.ui.view.MirrorVideoPlayer
import io.android.code.lib_base.event.observeLiveEvent

class MiracastMirrorDialog : BaseDialogFragment<DialogMiracastMirrorBinding>() {

    private var mirrorReceiver: MirrorReceiver? = null
    private var serviceConnection: ServiceConnection? = null

    override val dialogGravity: Int = Gravity.CENTER
    override val dialogWidth: Int = ViewGroup.LayoutParams.MATCH_PARENT
    override val dialogHeight: Int = ViewGroup.LayoutParams.MATCH_PARENT


    @OptIn(UnstableApi::class)
    override fun initView(savedInstanceState: Bundle?) {
        // TV 优化：屏幕常亮
        requireActivity().window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        initObServer()
        bindService()
    }

    private fun bindService() {
        val intent = Intent(requireContext(), MiraCastService::class.java)
        serviceConnection = object : ServiceConnection {
            override fun onServiceConnected(name: ComponentName?, service: IBinder?) {
                val binder = service as MiraCastService.MirrorReceiverBinder
                mirrorReceiver = binder.getMirrorReceiver()
                mirrorReceiver?.start(binding.videoSurface)
            }

            override fun onServiceDisconnected(name: ComponentName?) {
                mirrorReceiver?.unbindSurfaceView()
                mirrorReceiver = null
            }
        }
        requireContext().bindService(intent, serviceConnection!!, Context.BIND_AUTO_CREATE)
    }

    @OptIn(UnstableApi::class)
    private fun initObServer() {

        observeLiveEvent<Boolean>(MIRROER_DISCONNECT) {
            //镜像流断开了
            dismiss()
        }
    }

    @OptIn(UnstableApi::class)
    override fun onDestroyView() {
        mirrorReceiver?.unbindSurfaceView()
        mirrorReceiver = null
        serviceConnection?.let { requireContext().unbindService(it) }
        serviceConnection = null
        requireActivity().window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        super.onDestroyView()
    }

}