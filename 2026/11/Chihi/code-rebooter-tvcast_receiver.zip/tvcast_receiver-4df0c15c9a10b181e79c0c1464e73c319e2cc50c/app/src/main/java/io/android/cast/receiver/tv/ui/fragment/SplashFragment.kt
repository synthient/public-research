package io.android.cast.receiver.tv.ui.fragment

import androidx.lifecycle.lifecycleScope
import io.android.cast.receiver.tv.MainActivity
import io.android.cast.receiver.tv.databinding.FragmentSplashBinding
import io.android.code.lib_base.base.BaseVMFragment
import io.android.code.lib_base.base.BaseViewModel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class SplashFragment : BaseVMFragment<FragmentSplashBinding, BaseViewModel>() {

    override fun initView() {
        lifecycleScope.launch {
            delay(3000)
            (requireActivity() as MainActivity).endSplash()
        }

    }
}