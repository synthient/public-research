// AudioPlayer.kt（完整修复版）
package io.android.cast.receiver.tv.ui.view

import android.media.*
import com.xiaoyi.fdkaac.FDKCodec
import java.util.concurrent.*

class MirrorAudioPlayer : Runnable {

    private val SAMPLE_RATE = 44100
    private val CHANNEL_CONFIG = AudioFormat.CHANNEL_OUT_STEREO
    private val AUDIO_FORMAT = AudioFormat.ENCODING_PCM_16BIT

    private val queue = LinkedBlockingDeque<ByteArray>(50)
    private val executor = Executors.newSingleThreadExecutor()

    private var audioTrack: AudioTrack? = null
    private var isRunning = false
    private var isDestroyed = false

    private var minBufferSize = 0

    fun start() {
        if (isRunning) return
        isRunning = true
        isDestroyed = false
        createAudioTrack()
        audioTrack?.play()
        executor.execute(this)
       // println("AudioPlayer 启动")
    }

    fun write(aacData: ByteArray) {
        if (!isRunning || aacData.isEmpty()) return
        if (!queue.offer(aacData.copyOf())) {
            queue.poll()
            queue.offer(aacData.copyOf())
        }
    }

    fun stop() {
        isRunning = false
        audioTrack?.stop()
    }

    fun release() {
        isDestroyed = true
        isRunning = false
        executor.shutdownNow()
        try { executor.awaitTermination(2, TimeUnit.SECONDS) } catch (e: Exception) { }
        try { audioTrack?.stop(); audioTrack?.release() } catch (e: Exception) { }
        audioTrack = null
        queue.clear()
       // println("AudioPlayer 已释放")
    }

    private fun createAudioTrack() {
        minBufferSize = AudioTrack.getMinBufferSize(SAMPLE_RATE, CHANNEL_CONFIG, AUDIO_FORMAT)
        audioTrack = AudioTrack(
            AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                .build(),
            AudioFormat.Builder()
                .setSampleRate(SAMPLE_RATE)
                .setEncoding(AUDIO_FORMAT)
                .setChannelMask(CHANNEL_CONFIG)
                .build(),
            minBufferSize,
            AudioTrack.MODE_STREAM,
            AudioManager.AUDIO_SESSION_ID_GENERATE
        )
    }

    override fun run() {
        // 关键：和 Java 版一模一样！480 * 4 = 1920 字节
        val audioDecoded = ByteArray(480 * 4)

        while (!isDestroyed && !Thread.currentThread().isInterrupted) {
            try {
                val currentSpeech = queue.take()

                // 解码
                FDKCodec.decodeFrame(currentSpeech, audioDecoded)

                // 关键：Java 原版逻辑！
                val buffer = minBufferSize.coerceAtMost(audioDecoded.size)
                audioTrack?.let { track ->
                    val written = track.write(audioDecoded, 0, buffer, AudioTrack.WRITE_BLOCKING)
                    if (written < 0) {
                       // println("AudioTrack write 失败: $written")
                    }
                }

            } catch (e: InterruptedException) {
                Thread.currentThread().interrupt()
                break
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }
}