package io.android.cast.receiver.tv.constants

const val DLNA_STOPED = "dlna_stoped"
const val MIRROER_DISCONNECT = "mirroer_disconnect"