package io.android.cast.receiver.tv.ui.view

import android.content.Context
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.util.AttributeSet
import android.view.KeyEvent
import android.view.View
import android.widget.FrameLayout
import androidx.media3.common.MediaItem
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.hls.HlsMediaSource
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.PlayerView
import io.android.cast.receiver.tv.R

@UnstableApi
class VideoPlayerView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : FrameLayout(context, attrs, defStyleAttr) {

    private var exoPlayer: ExoPlayer? = null
    private var playerView: PlayerView? = null
    private val SHORT_SEEK_MS = 10_000L // 短按 10秒
    private val LONG_SEEK_MS = 30_000L  // 长按 30秒
    private var isSeeking = false

    // ✅ 新增：保存 Handler 与 Runnable 引用，用于清理
    private val handler = Handler(Looper.getMainLooper())
    private var seekRunnable: Runnable? = null

    init {
        inflate(context, R.layout.view_video_player, this)
        playerView = findViewById(R.id.playerView)
        isFocusable = true
        isFocusableInTouchMode = true
        setupPlayer()
    }

    private fun setupPlayer() {
        exoPlayer = ExoPlayer.Builder(context)
            .setLoadControl(
                DefaultLoadControl.Builder()
                    .setBufferDurationsMs(500, 1000, 500, 500)
                    .build()
            )
            .setMediaSourceFactory(DefaultMediaSourceFactory(context))
            .setSeekBackIncrementMs(SHORT_SEEK_MS)
            .setSeekForwardIncrementMs(SHORT_SEEK_MS)
            .build()

        playerView?.apply {
            player = exoPlayer
            useController = true
            controllerShowTimeoutMs = 3000
            setControllerVisibilityListener(PlayerView.ControllerVisibilityListener { visibility ->
                if (visibility == View.VISIBLE) {
                    scheduleControlHide()
                }
            })
            setControllerHideOnTouch(false)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                systemUiVisibility = SYSTEM_UI_FLAG_FULLSCREEN or SYSTEM_UI_FLAG_HIDE_NAVIGATION
            }
        }
    }

    fun start() {
        // 初始化已完成，无需额外操作
    }

    // ✅ 修改：彻底释放所有引用、回调与 handler 消息
    fun release() {
        handler.removeCallbacksAndMessages(null) // ✅ 移除所有延迟任务
        seekRunnable = null

        exoPlayer?.stop()
        exoPlayer?.release()
        exoPlayer = null
        playerView?.player?.stop()
        playerView?.player?.release()


        playerView?.player = null
        playerView = null // ✅ 可选，确保 View 层释放引用
    }

    fun playUrl(url: String) {
        exoPlayer?.let { player ->
            // ⚠️ 原逻辑保留，只是小优化：统一 MediaItem 创建
            val mediaItem = MediaItem.fromUri(url)
            if (url.substringAfterLast("/").contains(".m3u8", ignoreCase = true)) {
                val dataSourceFactory = DefaultHttpDataSource.Factory()
                val hlsMediaSource = HlsMediaSource.Factory(dataSourceFactory)
                    .createMediaSource(mediaItem)
                player.setMediaSource(hlsMediaSource)
            } else {
                player.setMediaItem(mediaItem)
            }
            player.prepare()
            player.playWhenReady = true
        }
    }

    private fun scheduleControlHide() {
        playerView?.controllerShowTimeoutMs = 3000
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        return when (keyCode) {
            KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE -> {
                if (exoPlayer?.isPlaying == true) {
                    exoPlayer?.pause()
                } else {
                    exoPlayer?.play()
                }
                playerView?.showController()
                scheduleControlHide()
                true
            }
            KeyEvent.KEYCODE_DPAD_LEFT -> handleSeek(-1, event)
            KeyEvent.KEYCODE_DPAD_RIGHT -> handleSeek(1, event)
            else -> super.onKeyDown(keyCode, event)
        }
    }

    // ✅ 修改：handleSeek 使用 handler 保存 runnable 引用，避免匿名泄漏
    private fun handleSeek(direction: Int, event: KeyEvent?): Boolean {
        if (event?.isLongPress == false) {
            exoPlayer?.seekTo(exoPlayer?.currentPosition?.plus(direction * SHORT_SEEK_MS) ?: 0)
        } else {
            isSeeking = true
            seekRunnable = object : Runnable {
                override fun run() {
                    if (isSeeking) {
                        exoPlayer?.seekTo(
                            exoPlayer?.currentPosition?.plus(direction * LONG_SEEK_MS) ?: 0
                        )
                        handler.postDelayed(this, 200)
                    }
                }
            }
            handler.post(seekRunnable!!) // ✅ 改为通过 handler 统一调度
        }

        playerView?.showController()
        scheduleControlHide()
        return true
    }

    // ✅ 修改：释放长按快进的回调
    override fun onKeyUp(keyCode: Int, event: KeyEvent?): Boolean {
        if (keyCode == KeyEvent.KEYCODE_DPAD_LEFT || keyCode == KeyEvent.KEYCODE_DPAD_RIGHT) {
            isSeeking = false
            seekRunnable?.let { handler.removeCallbacks(it) }
            seekRunnable = null
        }
        return super.onKeyUp(keyCode, event)
    }
}