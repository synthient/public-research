package io.android.cast.receiver.tv.ui.service

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.Binder
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.fragment.app.FragmentActivity
import io.android.cast.receiver.tv.constants.MIRROER_DISCONNECT
import io.android.cast.receiver.tv.ui.dialog.AirPlayMirrorDialog
import io.android.cast.receiver.tv.ui.dialog.MiracastMirrorDialog
import io.android.cast.receiver.tv.ui.dialog.base.showDialog
import io.android.cast.receiver.tv.ui.view.MirrorReceiver
import io.android.code.lib_base.currentActivity
import io.android.code.lib_base.event.sendLiveEventData
import io.android.code.lib_cast.manager.MirrorManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MiraCastService : Service() {

    companion object {
        const val CHANNEL_ID = "miracast_service_channel"
        const val NOTIF_ID = 2003
    }

    private var mirrorReceiver: MirrorReceiver?=null
    private val binder = MirrorReceiverBinder()

    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    override fun onBind(intent: Intent?): IBinder {
        return binder
    }

    override fun onCreate() {
        super.onCreate()
        startForegroundCompat()
        scope.launch {
            mirrorReceiver = MirrorReceiver()
            startMiraCastReceiver()
        }
    }

    private fun startForegroundCompat() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "MiraCast Service", NotificationManager.IMPORTANCE_LOW)
            )
        }

        val notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("A-Player")
            .setContentText("MiraCast 服务运行中...")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()

        startForeground(NOTIF_ID, notification)
    }

    private var dialog: MiracastMirrorDialog? = null
    private suspend fun startMiraCastReceiver() = withContext(Dispatchers.IO) {
        MirrorManager.start(
            onVideo = { data ->
                mirrorReceiver?.onVideo(data)
            },
            onAudio = { data ->
                mirrorReceiver?.onAudio(data)
            },
            onConnect = {
                mirrorReceiver?.createPlayer()
                dialog?.dismiss()
                dialog = null
                dialog = (currentActivity as FragmentActivity).showDialog(MiracastMirrorDialog()) {}
            },
            onDisconnect = {
                sendLiveEventData(MIRROER_DISCONNECT, true)
            }
        )

    }


    override fun onDestroy() {
        MirrorManager.stop()
        mirrorReceiver?.unbindSurfaceView()
        mirrorReceiver?.release()
        mirrorReceiver = null
        scope.cancel()
        super.onDestroy()
    }

    inner class MirrorReceiverBinder : Binder() {
        fun getMirrorReceiver(): MirrorReceiver = mirrorReceiver!!
    }
}