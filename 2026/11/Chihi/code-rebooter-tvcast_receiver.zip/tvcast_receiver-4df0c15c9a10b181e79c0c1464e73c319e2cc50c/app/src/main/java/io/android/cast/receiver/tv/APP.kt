package io.android.cast.receiver.tv

import android.app.Application
import androidx.lifecycle.ProcessLifecycleOwner
import com.speed.AppManager
import io.android.cast.receiver.tv.net.DomainCacheResetPolicy
import io.android.code.lib_base.MvvmHelper
import io.android.code.lib_cast.MvvmCastHelper

class APP: Application() {
    override fun onCreate() {
        super.onCreate()

        ProcessLifecycleOwner.get().lifecycle.addObserver(AppLifecycleObserver())

        MvvmHelper.init(this)
        MvvmCastHelper.init(this)

        DomainCacheResetPolicy.resetIfNeeded(
            context = this,
            currentBaseUrl = BuildConfig.BASE_URL
        )

        //不加密的
        AppManager.init {
            context = this@APP
            baseUrl = BuildConfig.BASE_URL
            backupDomain = BuildConfig.BACKUP_DOMAIN
            randomDomainMD5 = BuildConfig.MD5_VALUE
            appId = BuildConfig.APP_ID
            channel = BuildConfig.CHANNEL
            ctype = BuildConfig.CTYPE
            model = BuildConfig.MODEL
            isEncrypted = false
            isDebugMode = false
            isPrintEncryptedInfo = false
            isPrintNetRequestInfo = false
            isPrintHostAppInfo = false
            isPrintAutoRunInfo = false
        }

    }
}
