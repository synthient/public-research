package io.android.cast.receiver.tv.ui.activity

import io.android.cast.receiver.tv.databinding.ActivityCommonEmtBinding
import io.android.cast.receiver.tv.ui.fragment.SettingEmtFragment
import io.android.code.lib_base.base.BaseVMActivity
import io.android.code.lib_base.base.BaseViewModel
import io.android.code.lib_base.ext.replaceFragment


class SettingEmtActivity : BaseVMActivity<ActivityCommonEmtBinding, BaseViewModel>() {

    override fun initView() {
        replaceFragment(SettingEmtFragment(), mBind.container.id)
    }
}