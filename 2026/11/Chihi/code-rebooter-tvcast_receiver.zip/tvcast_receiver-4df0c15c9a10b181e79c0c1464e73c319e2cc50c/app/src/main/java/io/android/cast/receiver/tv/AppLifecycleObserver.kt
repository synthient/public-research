package io.android.cast.receiver.tv

import androidx.lifecycle.DefaultLifecycleObserver
import androidx.lifecycle.LifecycleOwner
import io.android.cast.receiver.tv.ext.stopAllService
import io.android.code.lib_base.appContext
import kotlinx.coroutines.*   // ✅ 新增：引入协程支持

class AppLifecycleObserver : DefaultLifecycleObserver {

    // ✅ 新增：定义一个协程作用域（生命周期在整个Observer期间）
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    // ✅ 新增：用于取消延迟任务的 Job
    private var stopJob: Job? = null

    override fun onStart(owner: LifecycleOwner) {
        // 应用进入前台
        // ✅ 新增：如果用户回来，取消之前的延迟停止任务
        stopJob?.cancel()
        stopJob = null
    }

    override fun onStop(owner: LifecycleOwner) {
        // 应用进入后台
       // println("进入后台，准备1分钟后停止所有service")

        // ✅ 修改：延迟 1 分钟后再执行停止操作
        stopJob?.cancel() // 防止重复调度
        stopJob = scope.launch {
            delay(60_000) // 延迟 1 分钟
            //println("后台停留超过1分钟，停止所有service")
            appContext.stopAllService()
        }
    }

    // ✅ 新增：销毁时取消所有协程，防止内存泄漏
    fun clear() {
        scope.cancel()
    }
}
