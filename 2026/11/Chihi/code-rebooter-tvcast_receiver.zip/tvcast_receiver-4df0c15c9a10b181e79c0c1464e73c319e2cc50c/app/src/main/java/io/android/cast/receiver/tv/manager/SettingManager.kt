package io.android.cast.receiver.tv.manager

import io.android.cast.receiver.tv.R
import io.android.cast.receiver.tv.bean.SettingDto
import io.android.code.lib_base.ext.stringValue

object SettingManager {
     fun getSettingItem(): MutableList<SettingDto>  = run {
        mutableListOf(

            SettingDto(
                "about",
                R.drawable.icon_about,
                R.drawable.icon_about_foc,
                R.string.about.stringValue(),
                ""
            ),
            SettingDto(
                "disclaimer",
                R.drawable.icon_disclaimer,
                R.drawable.icon_disclaimer_foc,
                R.string.disclaimer.stringValue(),
                ""
            ),
            SettingDto(
                "usage_statement",
                R.drawable.icon_usage,
                R.drawable.icon_usage_foc,
                R.string.usage_statement.stringValue(),
                ""
            ),
            SettingDto(
                "privacy_policy",
                R.drawable.icon_privacy_policy,
                R.drawable.icon_privacy_policy_foc,
                R.string.privacy_policy.stringValue(),
                ""
            ),
            SettingDto(
                "user_agreement",
                R.drawable.icon_user_agreement,
                R.drawable.icon_user_agreement_foc,
                R.string.user_agreement.stringValue(),
                ""
            ),

        )
    }

}