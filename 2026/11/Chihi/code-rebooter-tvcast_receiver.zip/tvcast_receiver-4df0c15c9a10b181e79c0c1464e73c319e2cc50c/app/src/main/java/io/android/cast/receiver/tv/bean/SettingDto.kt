package io.android.cast.receiver.tv.bean

data class SettingDto(
    var id:String,
    var icon_res: Int,
    var icon_res_focus: Int,
    var title_name: String,
    var subtitle_name: String,
)
