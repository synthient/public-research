package io.android.cast.receiver.tv

import androidx.lifecycle.lifecycleScope
import io.android.cast.receiver.tv.databinding.ActivityMainBinding
import io.android.cast.receiver.tv.ext.startAllService
import io.android.cast.receiver.tv.ext.stopAllService
import io.android.cast.receiver.tv.ui.fragment.MainFragment
import io.android.cast.receiver.tv.ui.fragment.PrivacyPolicyFragment
import io.android.cast.receiver.tv.ui.fragment.SplashFragment
import io.android.code.lib_base.appContext
import io.android.code.lib_base.base.BaseVMActivity
import io.android.code.lib_base.base.BaseViewModel
import io.android.code.lib_base.ext.replaceFragment
import kotlinx.coroutines.launch

class MainActivity : BaseVMActivity<ActivityMainBinding, BaseViewModel>() {


    override fun initView() {

        replaceFragment(SplashFragment(), mBind.flContainner.id)
    }



    fun endSplash() {
        if (AppCache.isPrivacyPolicyAgreed) {
            replaceFragment(MainFragment(), mBind.flContainner.id)
        } else {
            replaceFragment(PrivacyPolicyFragment(), mBind.flContainner.id)
        }
    }

    fun loadMain() {
        replaceFragment(MainFragment(), mBind.flContainner.id)
    }



    override fun onDestroy() {
        super.onDestroy()
        //println("首页销毁，停止所有service")
        appContext.stopAllService()
    }

}



