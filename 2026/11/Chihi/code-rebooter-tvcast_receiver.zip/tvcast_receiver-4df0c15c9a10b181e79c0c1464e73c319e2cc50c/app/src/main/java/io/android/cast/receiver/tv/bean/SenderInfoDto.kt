package io.android.cast.receiver.tv.bean

data class SenderInfoDto(
    val downloadurl:String? = null
)
