 // 语言数据嵌入 HTML
    const translations = {
      "en": {
        "title": "User Agreement",
        "effective_date": "Effective Date of this User Agreement: March 24, 2025",
        "version": "Version of this User Agreement: 2025V1.0",
        "intro": "Welcome to our services. This User Agreement (hereinafter 'Agreement') sets forth the terms and conditions for your use of [Service Name] (hereinafter 'Service'). By using our services, you agree to abide by the terms of this Agreement. If you do not agree, please do not use our services. We reserve the right to update this Agreement at any time, and the updated version will be posted within the Service or on this page. Please review this Agreement regularly.",
        "sections": [
          {
            "title": "Scope of Service",
            "content": "This Service provides [description of service content, e.g., 'online applications, data analytics tools, or social platforms'], aimed at providing [description of service goal, e.g., 'a convenient digital experience']. The specific features and availability of the Service may vary by region or device. We reserve the right to modify, suspend, or terminate part or all of the Service without prior notice, but we will make reasonable efforts to inform you of significant changes through in-Service notifications."
          },
          {
            "title": "User Eligibility and Account",
            "content": "You must be at least 16 years old (or the legal age in your country/region) to use this Service. If required to create an account, you must provide true, accurate, and complete registration information and update it as necessary. You are fully responsible for the security of your account and all activities associated with it, including any unauthorized use. You may not transfer or share your account with others.",
            "subcontent": "We reserve the right to suspend or terminate your account or access to the Service without prior notice if we detect any violation of this Agreement."
          },
          {
            "title": "User Conduct Rules",
            "content": "You agree to comply with the following rules when using the Service: 1) Do not engage in illegal, fraudulent, or rights-infringing activities; 2) Do not upload or distribute malware, viruses, or other harmful content; 3) Do not interfere with or disrupt the normal operation of the Service; 4) Comply with all applicable laws and the terms of this Agreement.",
            "subcontent": "Violating these rules may result in account suspension, termination, or legal action. We reserve the right to monitor user content and activities to ensure compliance, but we are not obligated to review all content."
          },
          {
            "title": "Intellectual Property",
            "content": "All content within the Service (including but not limited to text, images, code, and designs) is protected by copyright, trademark, or other laws and belongs to us or our licensors. You may use the Service content only for personal, non-commercial purposes and may not copy, modify, distribute, or otherwise use the content without authorization.",
            "subcontent": "Content you upload through the Service ('User Content') remains your property, but you grant us a worldwide, non-exclusive, royalty-free license to use, store, reproduce, and display such content for the purpose of providing and promoting the Service."
          },
          {
            "title": "Third-Party Services and Links",
            "content": "The Service may include third-party services or links (e.g., Google Play, Firebase Analytics). These services are subject to their own terms and privacy policies, and we are not responsible for their content, functionality, or behavior. We recommend reviewing the terms of the relevant third parties.",
            "list": [
              "Google Play Services (for app distribution)",
              "Google Analytics (for data analytics)",
              "Firebase Analytics (for performance monitoring)",
              "Crashlytics (for error log collection)"
            ]
          },
          {
            "title": "Limitation of Liability",
            "content": "We strive to ensure the availability and accuracy of the Service, but the Service is provided 'as is' without any express or implied warranties, including but not limited to warranties of merchantability or fitness for a particular purpose. To the extent permitted by applicable law, we are not liable for any direct, indirect, incidental, or consequential damages arising from the use of the Service.",
            "subcontent": "You agree to assume full responsibility for any claims, losses, or liabilities arising from your conduct or content and to indemnify us and our affiliates for any resulting losses."
          },
          {
            "title": "Service Termination",
            "content": "You may stop using the Service at any time. If you violate this Agreement or we deem it necessary (e.g., for security or legal reasons), we may suspend or terminate your access to the Service without prior notice. Upon termination, your account and related data may be deleted in accordance with our Privacy Policy.",
            "subcontent": "After termination of the Service, provisions related to intellectual property, limitation of liability, and dispute resolution will remain in effect."
          },
          {
            "title": "Applicable Law and Dispute Resolution",
            "content": "This Agreement is governed by [insert applicable law, e.g., 'EU law' or the law of a specific country]. In the event of a dispute, both parties shall first attempt to resolve it amicably. If negotiations fail, the dispute shall be submitted to [insert jurisdiction, e.g., 'the competent courts in your country/region'].",
            "subcontent": "In accordance with GDPR and relevant laws, you have the right to file a complaint with the data protection authority in your country regarding any disputes related to data processing."
          },
          {
            "title": "Agreement Updates",
            "content": "We may update this User Agreement from time to time. The updated version will be posted on this page or within the Service, with a new effective date. Significant changes will be communicated through in-Service notifications or email. We recommend reviewing this Agreement regularly to stay informed of the latest terms.",
            "subcontent": "Continued use of the Service constitutes acceptance of the updated Agreement."
          },
          {
            "title": "Contact Us",
            "content": "If you have any questions about this User Agreement or the Service, please submit your request through the 'Contact Us' function within the Service or the Help Center. We will respond promptly and ensure compliance with the transparency and accountability requirements of applicable laws."
          }
        ]
      },
      "zh-CN": {
        "title": "用户协议",
        "effective_date": "本用户协议生效日期：2025年3月24日",
        "version": "本用户协议版本：2025V1.0",
        "intro": "欢迎使用我们的服务。本用户协议（以下简称‘协议’）规定了您使用[服务名称]（以下简称‘服务’）的条款和条件。使用我们的服务即表示您同意遵守本协议的条款。如不同意，请勿使用我们的服务。我们保留随时更新本协议的权利，更新版本将在服务内或本页面发布。请定期审阅本协议。",
        "sections": [
          {
            "title": "服务范围",
            "content": "本服务提供[描述服务内容，如‘在线应用程序、数据分析工具或社交平台’]，旨在为用户提供[描述服务目标，如‘便捷的数字体验’]。服务的具体功能和可用性可能因地区或设备而异。我们保留随时修改、暂停或终止部分或全部服务的权利，恕不另行通知，但会尽力通过服务内通知告知重大变更。"
          },
          {
            "title": "用户资格与账户",
            "content": "您须年满16岁（或您所在国家/地区规定的法定年龄）方可使用本服务。如需创建账户，您应提供真实、准确且完整的注册信息，并及时更新。您对账户的安全性和所有活动负全部责任，包括任何未经授权的使用。不得将账户转让或分享给他人。",
            "subcontent": "我们保留在发现任何违反本协议的行为时，暂停或终止您的账户或服务访问权限的权利，恕不另行通知。"
          },
          {
            "title": "用户行为规范",
            "content": "您同意在使用服务时遵守以下规则：1) 不从事非法、欺诈或侵犯他人权利的活动；2) 不上传或传播恶意软件、病毒或其他有害内容；3) 不干扰或破坏服务的正常运行；4) 遵守所有适用法律和本协议条款。",
            "subcontent": "违反上述规则可能导致账户暂停、终止或法律行动。我们保留监控用户内容和活动的权利，以确保合规性，但不承诺审查所有内容。"
          },
          {
            "title": "知识产权",
            "content": "服务中的所有内容（包括但不限于文本、图像、代码、设计）均受版权、商标或其他法律保护，归我们或我们的许可方所有。您可仅为个人、非商业目的使用服务内容，不得复制、修改、分发或以其他方式使用未经授权的内容。",
            "subcontent": "您通过服务上传的内容（‘用户内容’）仍归您所有，但您授予我们全球性、非独占、免版税的许可，允许我们在提供和推广服务时使用、存储、复制和展示该内容。"
          },
          {
            "title": "第三方服务与链接",
            "content": "本服务可能包含第三方服务或链接（如Google Play、Firebase Analytics）。这些服务受其自身条款和隐私政策约束，我们不对其内容、功能或行为负责。建议您审阅相关第三方的条款。",
            "list": [
              "Google Play 服务（用于应用分发）",
              "Google Analytics（用于数据分析）",
              "Firebase Analytics（用于性能监控）",
              "Crashlytics（用于错误日志收集）"
            ]
          },
          {
            "title": "责任限制",
            "content": "我们尽力确保服务的可用性和准确性，但服务按‘现状’提供，不提供任何明示或暗示的保证，包括但不限于适销性或特定用途适用性的保证。在适用法律允许的范围内，我们对因使用服务导致的任何直接、间接、附带或后果性损失不承担责任。",
            "subcontent": "您同意对因您的行为或内容引起的任何索赔、损失或责任承担全部责任，并赔偿我们及我们的关联方因此遭受的损失。"
          },
          {
            "title": "服务终止",
            "content": "您可随时停止使用服务。如您违反本协议或我们认为有必要（如出于安全或法律原因），我们可随时暂停或终止您对服务的访问，恕不另行通知。终止后，您的账户和相关数据可能被删除，符合我们的隐私政策。",
            "subcontent": "在终止服务后，本协议中与知识产权、责任限制和争议解决相关的条款将继续有效。"
          },
          {
            "title": "适用法律与争议解决",
            "content": "本协议受[插入适用法律，如‘欧盟法律’或具体国家法律]管辖。如发生争议，双方应首先尝试通过友好协商解决。若协商失败，争议应提交[插入管辖区，如‘您所在国家/地区的有管辖权法院’]处理。",
            "subcontent": "根据GDPR及相关法律，您有权向您所在国家的数据保护机构投诉任何与数据处理相关的争议。"
          },
          {
            "title": "协议更新",
            "content": "我们可能不时更新本用户协议。更新版本将在本页面或服务内发布，并注明新生效日期。重大变更将通过服务内通知或电子邮件告知您。建议您定期审阅本协议以了解最新条款。",
            "subcontent": "继续使用服务即表示您接受更新后的协议。"
          },
          {
            "title": "联系我们",
            "content": "如对本用户协议或服务有任何疑问，请通过我们服务内的‘联系我们’功能或帮助中心提交您的请求。我们将尽快回应，并确保遵守适用法律的透明度和问责制要求。"
          }
        ]
      },
      "ar": {
        "title": "اتفاقية المستخدم",
        "effective_date": "تاريخ سريان اتفاقية المستخدم هذه: 24 مارس 2025",
        "version": "إصدار اتفاقية المستخدم: 2025V1.0",
        "intro": "مرحبًا بكم في استخدام خدماتنا. تحدد اتفاقية المستخدم هذه (المشار إليها فيما يلي بـ 'الاتفاقية') الشروط والأحكام لاستخدامكم [اسم الخدمة] (المشار إليها فيما يلي بـ 'الخدمة'). باستخدام خدماتنا، فإنكم توافقون على الالتزام بشروط هذه الاتفاقية. إذا كنتم لا توافقون، يرجى عدم استخدام الخدمة. نحتفظ بالحق في تحديث هذه الاتفاقية في أي وقت، وسيتم نشر النسخة المحدثة داخل الخدمة أو على هذه الصفحة. يرجى مراجعة الاتفاقية بانتظام.",
        "sections": [
          {
            "title": "نطاق الخدمة",
            "content": "توفر هذه الخدمة [وصف محتوى الخدمة، مثل 'تطبيقات عبر الإنترنت، أدوات تحليل البيانات، أو منصة اجتماعية']، بهدف تقديم [وصف هدف الخدمة، مثل 'تجربة رقمية مريحة']. قد تختلف وظائف الخدمة وتوفرها حسب المنطقة أو الجهاز. نحتفظ بالحق في تعديل الخدمة أو تعليقها أو إنهائها جزئيًا أو كليًا دون إشعار مسبق، لكننا سنبذل قصارى جهدنا لإبلاغكم بالتغييرات الجوهرية عبر إشعارات داخل الخدمة."
          },
          {
            "title": "أهلية المستخدم والحساب",
            "content": "يجب أن تكونوا في سن 16 عامًا على الأقل (أو السن القانوني في بلدكم/منطقتكم) لاستخدام هذه الخدمة. إذا كان يلزم إنشاء حساب، يجب تقديم معلومات تسجيل صحيحة ودقيقة وكاملة، وتحديثها عند الحاجة. أنتم مسؤولون بالكامل عن أمان الحساب وجميع الأنشطة المرتبطة به، بما في ذلك أي استخدام غير مصرح به. يُمنع نقل الحساب أو مشاركته مع الآخرين.",
            "subcontent": "نحتفظ بالحق في تعليق أو إنهاء حسابكم أو وصولكم إلى الخدمة دون إشعار مسبق إذا اكتشفنا أي انتهاك لهذه الاتفاقية."
          },
          {
            "title": "قواعد سلوك المستخدم",
            "content": "أنتم توافقون على الالتزام بالقواعد التالية عند استخدام الخدمة: 1) عدم الانخراط في أنشطة غير قانونية أو احتيالية أو تنتهك حقوق الآخرين؛ 2) عدم رفع أو نشر برمجيات خبيثة، فيروسات، أو محتوى ضار آخر؛ 3) عدم التدخل أو تعطيل التشغيل الطبيعي للخدمة؛ 4) الامتثال لجميع القوانين المعمول بها وشروط هذه الاتفاقية.",
            "subcontent": "قد يؤدي خرق هذه القواعد إلى تعليق الحساب، إنهائه، أو اتخاذ إجراءات قانونية. نحتفظ بالحق في مراقبة محتوى المستخدم وأنشطته لضمان الامتثال، ولكننا لا نلتزم بمراجعة كل المحتوى."
          },
          {
            "title": "الملكية الفكرية",
            "content": "جميع المحتويات في الخدمة (بما في ذلك، على سبيل المثال لا الحصر، النصوص، الصور، الأكواد، التصاميم) محمية بحقوق الطبع والنشر، العلامات التجارية، أو غيرها من القوانين، وهي مملوكة لنا أو للجهات المرخصة لنا. يمكنكم استخدام محتوى الخدمة لأغراض شخصية وغير تجارية فقط، ولا يجوز نسخ، تعديل، توزيع، أو استخدام المحتوى بطرق أخرى دون إذن.",
            "subcontent": "المحتوى الذي ترفعونه عبر الخدمة (‘محتوى المستخدم’) يظل ملكًا لكم، لكنكم تمنحوننا ترخيصًا عالميًا، غير حصري، خالٍ من الرسوم لاستخدام، تخزين، نسخ، وعرض هذا المحتوى لتقديم الخدمة والترويج لها."
          },
          {
            "title": "خدمات وروابط الطرف الثالث",
            "content": "قد تحتوي الخدمة على خدمات أو روابط لأطراف ثالثة (مثل Google Play، Firebase Analytics). تخضع هذه الخدمات لشروطها وسياسات الخصوصية الخاصة بها، ولا نتحمل مسؤولية عن محتواها، وظائفها، أو سلوكها. نوصي بمراجعة شروط الطرف الثالث ذات الصلة.",
            "list": [
              "خدمات Google Play (لتوزيع التطبيقات)",
              "Google Analytics (لتحليل البيانات)",
              "Firebase Analytics (لمراقبة الأداء)",
              "Crashlytics (لتجميع سجلات الأخطاء)"
            ]
          },
          {
            "title": "تحديد المسؤولية",
            "content": "نبذل قصارى جهدنا لضمان توفر الخدمة ودقتها، لكن الخدمة تُقدم 'كما هي' دون أي ضمانات صريحة أو ضمنية، بما في ذلك، على سبيل المثال لا الحصر، ضمانات القابلية للتسويق أو الملاءمة لغرض معين. في حدود القانون المعمول به، لا نتحمل مسؤولية أي خسائر مباشرة أو غير مباشرة أو عرضية أو تبعية ناتجة عن استخدام الخدمة.",
            "subcontent": "أنتم توافقون على تحمل المسؤولية الكاملة عن أي مطالبات، خسائر، أو مسؤوليات تنشأ عن سلوككم أو محتواكم، وتعويضنا وشركاتنا التابعة عن أي خسائر ناتجة عن ذلك."
          },
          {
            "title": "إنهاء الخدمة",
            "content": "يمكنكم التوقف عن استخدام الخدمة في أي وقت. إذا انتهكتم هذه الاتفاقية أو رأينا ذلك ضروريًا (لأسباب أمنية أو قانونية)، يجوز لنا تعليق أو إنهاء وصولكم إلى الخدمة دون إشعار مسبق. بعد الإنهاء، قد يتم حذف حسابكم والبيانات ذات الصلة وفقًا لسياسة الخصوصية الخاصة بنا.",
            "subcontent": "بعد إنهاء الخدمة، ستظل الشروط المتعلقة بالملكية الفكرية، تحديد المسؤولية، وتسوية النزاعات سارية المفعول."
          },
          {
            "title": "القانون المعمول به وتسوية النزاعات",
            "content": "تخضع هذه الاتفاقية لـ[إدراج القانون المعمول به، مثل 'القانون الأوروبي' أو قانون بلد معين]. في حالة النزاع، يجب على الطرفين محاولة حله وديًا أولاً. إذا فشلت المفاوضات، يتم تقديم النزاع إلى [إدراج الاختصاص القضائي، مثل 'المحاكم المختصة في بلدكم/منطقتكم'].",
            "subcontent": "وفقًا للائحة GDPR والقوانين ذات الصلة، يحق لكم تقديم شكوى إلى هيئة حماية البيانات في بلدكم بشأن أي نزاع متعلق بمعالجة البيانات."
          },
          {
            "title": "تحديثات الاتفاقية",
            "content": "قد نحدّث اتفاقية المستخدم هذه من وقت لآخر. سيتم نشر النسخة المحدثة على هذه الصفحة أو داخل الخدمة، مع ذكر تاريخ السريان الجديد. سنخطركم بالتغييرات الجوهرية عبر إشعارات داخل الخدمة أو البريد الإلكتروني. نوصي بمراجعة هذه الاتفاقية بانتظام لمعرفة أحدث الشروط.",
            "subcontent": "استمراركم في استخدام الخدمة يعني قبولكم للاتفاقية المحدثة."
          },
          {
            "title": "اتصلوا بنا",
            "content": "إذا كانت لديكم أي أسئلة حول اتفاقية المستخدم هذه أو الخدمة، يرجى تقديم طلبكم عبر وظيفة 'الاتصال بنا' داخل الخدمة أو مركز المساعدة. سنرد بسرعة ونلتزم بمتطلبات الشفافية والمسؤولية وفقًا للقوانين المعمول بها."
          }
        ]
      },
      "de": {
        "title": "Nutzungsbedingungen",
        "effective_date": "Datum des Inkrafttretens dieser Nutzungsbedingungen: 24. März 2025",
        "version": "Version der Nutzungsbedingungen: 2025V1.0",
        "intro": "Willkommen bei unseren Diensten. Diese Nutzungsbedingungen (nachfolgend „Bedingungen“) regeln die Nutzung von [Dienstname] (nachfolgend „Dienst“). Durch die Nutzung unserer Dienste erklären Sie sich mit diesen Bedingungen einverstanden. Wenn Sie nicht einverstanden sind, nutzen Sie den Dienst bitte nicht. Wir behalten uns das Recht vor, diese Bedingungen jederzeit zu aktualisieren. Die aktualisierte Version wird im Dienst oder auf dieser Seite veröffentlicht. Bitte überprüfen Sie diese Bedingungen regelmäßig.",
        "sections": [
          {
            "title": "Umfang des Dienstes",
            "content": "Dieser Dienst bietet [Beschreibung des Dienstes, z. B. „Online-Anwendungen, Datenanalysetools oder soziale Plattformen“], um [Beschreibung des Dienstziels, z. B. „eine bequeme digitale Erfahrung“] zu ermöglichen. Die spezifischen Funktionen und Verfügbarkeit des Dienstes können je nach Region oder Gerät variieren. Wir behalten uns das Recht vor, den Dienst jederzeit zu ändern, auszusetzen oder ganz oder teilweise einzustellen, ohne vorherige Ankündigung, werden jedoch bestrebt sein, wesentliche Änderungen durch Benachrichtigungen im Dienst mitzuteilen."
          },
          {
            "title": "Nutzungsberechtigung und Konto",
            "content": "Sie müssen mindestens 16 Jahre alt sein (oder das gesetzliche Mindestalter in Ihrem Land/Ihrer Region), um den Dienst zu nutzen. Wenn Sie ein Konto erstellen, müssen Sie wahrheitsgemäße, genaue und vollständige Registrierungsinformationen angeben und diese bei Bedarf aktualisieren. Sie sind vollständig für die Sicherheit Ihres Kontos und alle damit verbundenen Aktivitäten verantwortlich, einschließlich unbefugter Nutzung. Ihr Konto darf nicht übertragen oder mit anderen geteilt werden.",
            "subcontent": "Wir behalten uns das Recht vor, Ihr Konto oder den Zugang zum Dienst ohne Vorankündigung auszusetzen oder zu beenden, wenn wir Verstöße gegen diese Bedingungen feststellen."
          },
          {
            "title": "Verhaltensregeln für Nutzer",
            "content": "Sie erklären sich damit einverstanden, bei der Nutzung des Dienstes die folgenden Regeln einzuhalten: 1) Keine illegalen, betrügerischen oder die Rechte anderer verletzenden Aktivitäten; 2) Kein Hochladen oder Verbreiten von Malware, Viren oder anderem schädlichem Inhalt; 3) Keine Störung oder Beeinträchtigung des normalen Betriebs des Dienstes; 4) Einhaltung aller geltenden Gesetze und dieser Bedingungen.",
            "subcontent": "Ein Verstoß gegen diese Regeln kann zur Aussetzung oder Kündigung Ihres Kontos oder zu rechtlichen Schritten führen. Wir behalten uns das Recht vor, Nutzerinhalte und -aktivitäten zu überwachen, um die Einhaltung sicherzustellen, verpflichten uns jedoch nicht, alle Inhalte zu überprüfen."
          },
          {
            "title": "Geistiges Eigentum",
            "content": "Alle Inhalte des Dienstes (einschließlich, aber nicht beschränkt auf Texte, Bilder, Code, Designs) sind durch Urheberrechte, Marken oder andere Gesetze geschützt und gehören uns oder unseren Lizenzgebern. Sie dürfen die Inhalte des Dienstes nur für persönliche, nicht-kommerzielle Zwecke nutzen und diese nicht ohne Genehmigung kopieren, modifizieren, verteilen oder anderweitig verwenden.",
            "subcontent": "Inhalte, die Sie über den Dienst hochladen („Nutzerinhalte“), bleiben Ihr Eigentum, aber Sie gewähren uns eine weltweite, nicht-exklusive, gebührenfreie Lizenz zur Nutzung, Speicherung, Vervielfältigung und Anzeige dieser Inhalte zur Bereitstellung und Förderung des Dienstes."
          },
          {
            "title": "Drittdienste und Links",
            "content": "Der Dienst kann Dienste oder Links von Drittanbietern enthalten (z. B. Google Play, Firebase Analytics). Diese Dienste unterliegen ihren eigenen Nutzungsbedingungen und Datenschutzrichtlinien, und wir sind nicht verantwortlich für deren Inhalte, Funktionen oder Verhalten. Wir empfehlen, die Bedingungen der jeweiligen Drittanbieter zu überprüfen.",
            "list": [
              "Google Play-Dienste (für App-Verteilung)",
              "Google Analytics (für Datenanalyse)",
              "Firebase Analytics (für Leistungsüberwachung)",
              "Crashlytics (für Fehlerprotokollierung)"
            ]
          },
          {
            "title": "Haftungsbeschränkung",
            "content": "Wir bemühen uns, die Verfügbarkeit und Genauigkeit des Dienstes zu gewährleisten, stellen den Dienst jedoch „wie besehen“ ohne ausdrückliche oder stillschweigende Garantien zur Verfügung, einschließlich, aber nicht beschränkt auf Garantien der Marktgängigkeit oder Eignung für einen bestimmten Zweck. Im Rahmen des geltenden Rechts haften wir nicht für direkte, indirekte, zufällige oder Folgeschäden, die durch die Nutzung des Dienstes entstehen.",
            "subcontent": "Sie erklären sich bereit, die volle Verantwortung für Ansprüche, Verluste oder Haftungen zu übernehmen, die aus Ihrem Verhalten oder Inhalten resultieren, und uns sowie unsere verbundenen Unternehmen für daraus resultierende Verluste zu entschädigen."
          },
          {
            "title": "Beendigung des Dienstes",
            "content": "Sie können die Nutzung des Dienstes jederzeit einstellen. Wenn Sie gegen diese Bedingungen verstoßen oder wir dies für erforderlich halten (z. B. aus Sicherheits- oder rechtlichen Gründen), können wir Ihren Zugang zum Dienst ohne Vorankündigung aussetzen oder beenden. Nach der Beendigung können Ihr Konto und die zugehörigen Daten gemäß unserer Datenschutzrichtlinie gelöscht werden.",
            "subcontent": "Nach Beendigung des Dienstes bleiben die Bestimmungen zu geistigem Eigentum, Haftungsbeschränkung und Streitbeilegung weiterhin in Kraft."
          },
          {
            "title": "Anwendbares Recht und Streitbeilegung",
            "content": "Diese Bedingungen unterliegen [anwendbares Recht einfügen, z. B. „EU-Recht“ oder das Recht eines bestimmten Landes]. Im Falle eines Streits sollten beide Parteien zunächst versuchen, diesen einvernehmlich zu lösen. Scheitert die Verhandlung, wird der Streit an [Gerichtsstand einfügen, z. B. „die zuständigen Gerichte in Ihrem Land/Ihrer Region“] verwiesen.",
            "subcontent": "Gemäß GDPR und den einschlägigen Gesetzen haben Sie das Recht, Beschwerden über datenbezogene Streitigkeiten bei der Datenschutzbehörde Ihres Landes einzureichen."
          },
          {
            "title": "Aktualisierung der Bedingungen",
            "content": "Wir können diese Nutzungsbedingungen von Zeit zu Zeit aktualisieren. Die aktualisierte Version wird auf dieser Seite oder im Dienst veröffentlicht und mit einem neuen Inkrafttretensdatum versehen. Wesentliche Änderungen werden über Benachrichtigungen im Dienst oder per E-Mail mitgeteilt. Wir empfehlen, diese Bedingungen regelmäßig zu überprüfen, um die neuesten Bedingungen zu kennen.",
            "subcontent": "Die fortgesetzte Nutzung des Dienstes bedeutet Ihre Zustimmung zu den aktualisierten Bedingungen."
          },
          {
            "title": "Kontaktieren Sie uns",
            "content": "Bei Fragen zu diesen Nutzungsbedingungen oder dem Dienst reichen Sie Ihre Anfrage bitte über die Funktion ‚Kontaktieren Sie uns‘ im Dienst oder über das Hilfe-Center ein. Wir werden schnell antworten und die Anforderungen an Transparenz und Rechenschaftspflicht gemäß den geltenden Gesetzen einhalten."
          }
        ]
      },
      "es": {
        "title": "Términos de Servicio",
        "effective_date": "Fecha de entrada en vigor de estos Términos de Servicio: 24 de marzo de 2025",
        "version": "Versión de los Términos de Servicio: 2025V1.0",
        "intro": "Bienvenido a nuestros servicios. Estos Términos de Servicio (en adelante, „Términos“) regulan el uso de [Nombre del Servicio] (en adelante, „Servicio“). Al utilizar nuestros servicios, usted acepta cumplir con estos Términos. Si no está de acuerdo, por favor no utilice el Servicio. Nos reservamos el derecho de actualizar estos Términos en cualquier momento, y la versión actualizada se publicará en el Servicio o en esta página. Le recomendamos revisar estos Términos regularmente.",
        "sections": [
          {
            "title": "Alcance del Servicio",
            "content": "Este Servicio ofrece [descripción del contenido del servicio, como „aplicaciones en línea, herramientas de análisis de datos o plataformas sociales“], con el objetivo de proporcionar [descripción del objetivo del servicio, como „una experiencia digital conveniente“]. Las funciones específicas y la disponibilidad del Servicio pueden variar según la región o el dispositivo. Nos reservamos el derecho de modificar, suspender o finalizar parcial o totalmente el Servicio sin notificación previa, aunque haremos todo lo posible para informar sobre cambios significativos a través de notificaciones en el Servicio."
          },
          {
            "title": "Elegibilidad del Usuario y Cuenta",
            "content": "Debe tener al menos 16 años (o la edad legal en su país/región) para utilizar este Servicio. Si es necesario crear una cuenta, debe proporcionar información de registro veraz, precisa y completa, y actualizarla cuando sea necesario. Usted es completamente responsable de la seguridad de su cuenta y de todas las actividades asociadas, incluido cualquier uso no autorizado. No puede transferir ni compartir su cuenta con otros.",
            "subcontent": "Nos reservamos el derecho de suspender o terminar su cuenta o acceso al Servicio sin notificación previa si detectamos alguna violación de estos Términos."
          },
          {
            "title": "Normas de Conducta del Usuario",
            "content": "Usted acepta cumplir con las siguientes reglas al usar el Servicio: 1) No participar en actividades ilegales, fraudulentas o que infrinjan los derechos de otros; 2) No cargar ni difundir malware, virus u otro contenido dañino; 3) No interferir ni interrumpir el funcionamiento normal del Servicio; 4) Cumplir con todas las leyes aplicables y estos Términos.",
            "subcontent": "El incumplimiento de estas reglas puede resultar en la suspensión o terminación de la cuenta o en acciones legales. Nos reservamos el derecho de monitorear el contenido y las actividades de los usuarios para garantizar el cumplimiento, pero no nos comprometemos a revisar todo el contenido."
          },
          {
            "title": "Propiedad Intelectual",
            "content": "Todo el contenido del Servicio (incluidos, entre otros, textos, imágenes, código, diseños) está protegido por derechos de autor, marcas registradas u otras leyes, y pertenece a nosotros o a nuestros licenciantes. Puede usar el contenido del Servicio solo para fines personales y no comerciales, y no puede copiar, modificar, distribuir ni utilizar el contenido de ninguna otra manera sin autorización.",
            "subcontent": "El contenido que usted carga a través del Servicio („Contenido del Usuario“) sigue siendo de su propiedad, pero nos otorga una licencia mundial, no exclusiva y libre de regalías para usar, almacenar, reproducir y mostrar dicho contenido para proporcionar y promover el Servicio."
          },
          {
            "title": "Servicios y Enlaces de Terceros",
            "content": "El Servicio puede incluir servicios o enlaces de terceros (como Google Play, Firebase Analytics). Estos servicios están sujetos a sus propios términos y políticas de privacidad, y no somos responsables de su contenido, funciones o comportamiento. Le recomendamos revisar los términos de los terceros relevantes.",
            "list": [
              "Servicios de Google Play (para distribución de aplicaciones)",
              "Google Analytics (para análisis de datos)",
              "Firebase Analytics (para monitoreo de rendimiento)",
              "Crashlytics (para recolección de registros de errores)"
            ]
          },
          {
            "title": "Limitación de Responsabilidad",
            "content": "Nos esforzamos por garantizar la disponibilidad y precisión del Servicio, pero el Servicio se proporciona „tal cual“ sin garantías expresas o implícitas, incluidas, entre otras, garantías de comerciabilidad o idoneidad para un propósito particular. En la medida permitida por la ley aplicable, no seremos responsables de ningún daño directo, indirecto, incidental o consecuente derivado del uso del Servicio.",
            "subcontent": "Usted acepta asumir toda la responsabilidad por cualquier reclamación, pérdida o responsabilidad derivada de su conducta o contenido, y nos indemnizará a nosotros y a nuestras afiliadas por cualquier pérdida resultante."
          },
          {
            "title": "Terminación del Servicio",
            "content": "Puede dejar de usar el Servicio en cualquier momento. Si incumple estos Términos o lo consideramos necesario (por ejemplo, por razones de seguridad o legales), podemos suspender o terminar su acceso al Servicio sin notificación previa. Tras la terminación, su cuenta y los datos asociados pueden eliminarse conforme a nuestra Política de Privacidad.",
            "subcontent": "Tras la terminación del Servicio, las disposiciones relacionadas con la propiedad intelectual, la limitación de responsabilidad y la resolución de disputas seguirán vigentes."
          },
          {
            "title": "Ley Aplicable y Resolución de Disputas",
            "content": "Estos Términos se rigen por [inserte la ley aplicable, como „ley de la UE“ o la ley de un país específico]. En caso de disputa, las partes intentarán primero resolverla de manera amistosa. Si la negociación falla, la disputa se someterá a [inserte jurisdicción, como „los tribunales competentes en su país/región“].",
            "subcontent": "De acuerdo con el RGPD y las leyes aplicables, tiene derecho a presentar quejas sobre disputas relacionadas con el procesamiento de datos ante la autoridad de protección de datos de su país."
          },
          {
            "title": "Actualización de los Términos",
            "content": "Podemos actualizar estos Términos de Servicio de vez en cuando. La versión actualizada se publicará en esta página o dentro del Servicio, con una nueva fecha de entrada en vigor. Los cambios significativos se notificarán mediante notificaciones en el Servicio o por correo electrónico. Le recomendamos revisar estos Términos regularmente para conocer los términos más recientes.",
            "subcontent": "El uso continuado del Servicio implica la aceptación de los Términos actualizados."
          },
          {
            "title": "Contáctenos",
            "content": "Si tiene alguna pregunta sobre estos Términos de Servicio o el Servicio, envíe su solicitud a través de la función ‚Contáctenos‘ dentro del Servicio o el centro de ayuda. Responderemos rápidamente y cumpliremos con los requisitos de transparencia y responsabilidad de las leyes aplicables."
          }
        ]
      },
      "fr": {
        "title": "Conditions d'Utilisation",
        "effective_date": "Date d'entrée en vigueur de ces Conditions d'Utilisation : 24 mars 2025",
        "version": "Version des Conditions d'Utilisation : 2025V1.0",
        "intro": "Bienvenue sur nos services. Ces Conditions d'Utilisation (ci-après „Conditions“) régissent l'utilisation de [Nom du Service] (ci-après „Service“). En utilisant nos services, vous acceptez de respecter ces Conditions. Si vous n'êtes pas d'accord, veuillez ne pas utiliser le Service. Nous nous réservons le droit de mettre à jour ces Conditions à tout moment, et la version mise à jour sera publiée dans le Service ou sur cette page. Veuillez consulter ces Conditions régulièrement.",
        "sections": [
          {
            "title": "Portée du Service",
            "content": "Ce Service propose [description du contenu du service, comme „applications en ligne, outils d'analyse de données ou plateformes sociales“], visant à offrir [description de l'objectif du service, comme „une expérience numérique pratique“]. Les fonctionnalités spécifiques et la disponibilité du Service peuvent varier selon la région ou l'appareil. Nous nous réservons le droit de modifier, suspendre ou mettre fin partiellement ou totalement au Service sans préavis, bien que nous nous efforcions d'informer des changements significatifs via des notifications dans le Service."
          },
          {
            "title": "Éligibilité de l'Utilisateur et Compte",
            "content": "Vous devez avoir au moins 16 ans (ou l'âge légal dans votre pays/région) pour utiliser ce Service. Si vous devez créer un compte, vous devez fournir des informations d'inscription véridiques, précises et complètes, et les mettre à jour si nécessaire. Vous êtes entièrement responsable de la sécurité de votre compte et de toutes les activités associées, y compris tout usage non autorisé. Vous ne pouvez pas transférer ou partager votre compte avec d'autres.",
            "subcontent": "Nous nous réservons le droit de suspendre ou de résilier votre compte ou l'accès au Service sans préavis si nous constatons une violation de ces Conditions."
          },
          {
            "title": "Règles de Conduite des Utilisateurs",
            "content": "Vous acceptez de respecter les règles suivantes lors de l'utilisation du Service : 1) Ne pas vous engager dans des activités illégales, frauduleuses ou violant les droits d'autrui ; 2) Ne pas télécharger ou diffuser de logiciels malveillants, virus ou autre contenu nuisible ; 3) Ne pas perturber ou interférer avec le fonctionnement normal du Service ; 4) Respecter toutes les lois applicables et ces Conditions.",
            "subcontent": "Le non-respect de ces règles peut entraîner la suspension ou la résiliation du compte ou des actions légales. Nous nous réservons le droit de surveiller le contenu et les activités des utilisateurs pour garantir le respect, mais nous ne nous engageons pas à examiner tout le contenu."
          },
          {
            "title": "Propriété Intellectuelle",
            "content": "Tout le contenu du Service (y compris, mais sans s'y limiter, textes, images, code, designs) est protégé par le droit d'auteur, les marques déposées ou d'autres lois, et appartient à nous ou à nos concédants de licence. Vous pouvez utiliser le contenu du Service uniquement à des fins personnelles et non commerciales, et vous ne pouvez pas copier, modifier, distribuer ou utiliser le contenu d'une autre manière sans autorisation.",
            "subcontent": "Le contenu que vous téléchargez via le Service („Contenu Utilisateur“) reste votre propriété, mais vous nous accordez une licence mondiale, non exclusive et sans redevance pour utiliser, stocker, reproduire et afficher ce contenu afin de fournir et de promouvoir le Service."
          },
          {
            "title": "Services et Liens de Tiers",
            "content": "Le Service peut inclure des services ou des liens de tiers (comme Google Play, Firebase Analytics). Ces services sont soumis à leurs propres conditions et politiques de confidentialité, et nous ne sommes pas responsables de leur contenu, de leurs fonctionnalités ou de leur comportement. Nous vous recommandons de consulter les conditions des tiers concernés.",
            "list": [
              "Services Google Play (pour la distribution d'applications)",
              "Google Analytics (pour l'analyse de données)",
              "Firebase Analytics (pour la surveillance des performances)",
              "Crashlytics (pour la collecte de journaux d'erreurs)"
            ]
          },
          {
            "title": "Limitation de Responsabilité",
            "content": "Nous nous efforçons de garantir la disponibilité et l'exactitude du Service, mais le Service est fourni „tel quel“ sans garanties expresses ou implicites, y compris, mais sans s'y limiter, les garanties de qualité marchande ou d'adéquation à un usage particulier. Dans la mesure permise par la loi applicable, nous ne serons pas responsables des dommages directs, indirects, accessoires ou consécutifs découlant de l'utilisation du Service.",
            "subcontent": "Vous acceptez d'assumer l'entière responsabilité des réclamations, pertes ou responsabilités découlant de votre conduite ou contenu, et de nous indemniser, ainsi que nos affiliés, pour toute perte en résultant."
          },
          {
            "title": "Résiliation du Service",
            "content": "Vous pouvez cesser d'utiliser le Service à tout moment. Si vous violez ces Conditions ou si nous le jugeons nécessaire (par exemple, pour des raisons de sécurité ou légales), nous pouvons suspendre ou résilier votre accès au Service sans préavis. Après la résiliation, votre compte et les données associées peuvent être supprimés conformément à notre Politique de Confidentialité.",
            "subcontent": "Après la résiliation du Service, les dispositions relatives à la propriété intellectuelle, à la limitation de responsabilité et à la résolution des litiges resteront en vigueur."
          },
          {
            "title": "Loi Applicable et Résolution des Litiges",
            "content": "Ces Conditions sont régies par [insérer la loi applicable, comme „le droit de l'UE“ ou la loi d'un pays spécifique]. En cas de litige, les parties tenteront d'abord de le résoudre à l'amiable. Si la négociation échoue, le litige sera soumis à [insérer la juridiction, comme „les tribunaux compétents dans votre pays/région“].",
            "subcontent": "Conformément au RGPD et aux lois applicables, vous avez le droit de porter plainte concernant les litiges liés au traitement des données auprès de l'autorité de protection des données de votre pays."
          },
          {
            "title": "Mise à jour des Conditions",
            "content": "Nous pouvons mettre à jour ces Conditions d'Utilisation de temps à autre. La version mise à jour sera publiée sur cette page ou dans le Service, avec une nouvelle date d'entrée en vigueur. Les changements significatifs seront notifiés via des notifications dans le Service ou par e-mail. Nous vous recommandons de consulter ces Conditions régulièrement pour connaître les termes les plus récents.",
            "subcontent": "L'utilisation continue du Service implique l'acceptation des Conditions mises à jour."
          },
          {
            "title": "Contactez-nous",
            "content": "Si vous avez des questions concernant ces Conditions d'Utilisation ou le Service, veuillez soumettre votre demande via la fonction ‚Contactez-nous‘ dans le Service ou le centre d'aide. Nous répondrons rapidement et respecterons les exigences de transparence et de responsabilité des lois applicables."
          }
        ]
      },
      "it": {
        "title": "Termini di Servizio",
        "effective_date": "Data di entrata in vigore di questi Termini di Servizio: 24 marzo 2025",
        "version": "Versione dei Termini di Servizio: 2025V1.0",
        "intro": "Benvenuto nei nostri servizi. Questi Termini di Servizio (di seguito „Termini“) regolano l'uso di [Nome del Servizio] (di seguito „Servizio“). Utilizzando i nostri servizi, accetti di rispettare questi Termini. Se non sei d'accordo, ti preghiamo di non utilizzare il Servizio. Ci riserviamo il diritto di aggiornare questi Termini in qualsiasi momento, e la versione aggiornata sarà pubblicata nel Servizio o su questa pagina. Ti consigliamo di rivedere regolarmente questi Termini.",
        "sections": [
          {
            "title": "Ambito del Servizio",
            "content": "Questo Servizio offre [descrizione del contenuto del servizio, come „applicazioni online, strumenti di analisi dei dati o piattaforme sociali“], con l'obiettivo di fornire [descrizione dell'obiettivo del servizio, come „un'esperienza digitale conveniente“]. Le funzionalità specifiche e la disponibilità del Servizio possono variare a seconda della regione o del dispositivo. Ci riserviamo il diritto di modificare, sospendere o terminare parzialmente o totalmente il Servizio senza preavviso, anche se faremo del nostro meglio per informarti di cambiamenti significativi tramite notifiche nel Servizio."
          },
          {
            "title": "Eleggibilità dell'Utente e Account",
            "content": "Devi avere almeno 16 anni (o l'età legale nel tuo paese/regione) per utilizzare questo Servizio. Se devi creare un account, devi fornire informazioni di registrazione veritiere, accurate e complete, e aggiornarle quando necessario. Sei interamente responsabile della sicurezza del tuo account e di tutte le attività associate, incluso qualsiasi uso non autorizzato. Non puoi trasferire o condividere il tuo account con altri.",
            "subcontent": "Ci riserviamo il diritto di sospendere o terminare il tuo account o l'accesso al Servizio senza preavviso se rileviamo una violazione di questi Termini."
          },
          {
            "title": "Norme di Condotta dell'Utente",
            "content": "Accetti di rispettare le seguenti regole quando utilizzi il Servizio: 1) Non intraprendere attività illegali, fraudolente o che violino i diritti altrui; 2) Non caricare o diffondere malware, virus o altri contenuti dannosi; 3) Non interferire o interrompere il normale funzionamento del Servizio; 4) Rispettare tutte le leggi applicabili e questi Termini.",
            "subcontent": "La violazione di queste regole può comportare la sospensione o la terminazione dell'account o azioni legali. Ci riserviamo il diritto di monitorare i contenuti e le attività degli utenti per garantire il rispetto, ma non ci impegniamo a rivedere tutti i contenuti."
          },
          {
            "title": "Proprietà Intellettuale",
            "content": "Tutti i contenuti del Servizio (inclusi, ma non limitati a, testi, immagini, codice, design) sono protetti da copyright, marchi registrati o altre leggi e appartengono a noi o ai nostri licenziatari. Puoi utilizzare i contenuti del Servizio solo per scopi personali e non commerciali, e non puoi copiare, modificare, distribuire o utilizzare i contenuti in altri modi senza autorizzazione.",
            "subcontent": "I contenuti che carichi tramite il Servizio („Contenuti dell'Utente“) rimangono di tua proprietà, ma ci concedi una licenza mondiale, non esclusiva e senza royalty per utilizzare, archiviare, riprodurre e mostrare tali contenuti per fornire e promuovere il Servizio."
          },
          {
            "title": "Servizi e Link di Terzi",
            "content": "Il Servizio può includere servizi o link di terzi (come Google Play, Firebase Analytics). Questi servizi sono soggetti ai loro termini e politiche di privacy, e non siamo responsabili dei loro contenuti, funzionalità o comportamenti. Ti consigliamo di rivedere i termini dei terzi pertinenti.",
            "list": [
              "Servizi Google Play (per la distribuzione di applicazioni)",
              "Google Analytics (per l'analisi dei dati)",
              "Firebase Analytics (per il monitoraggio delle prestazioni)",
              "Crashlytics (per la raccolta di log di errori)"
            ]
          },
          {
            "title": "Limitazione di Responsabilità",
            "content": "Ci impegniamo a garantire la disponibilità e l'accuratezza del Servizio, ma il Servizio è fornito „così com'è“ senza garanzie espresse o implicite, incluse, ma non limitate a, garanzie di commerciabilità o idoneità per uno scopo particolare. Nella misura consentita dalla legge applicabile, non saremo responsabili per eventuali danni diretti, indiretti, accidentali o consequenziali derivanti dall'uso del Servizio.",
            "subcontent": "Accetti di assumerti la piena responsabilità per eventuali reclami, perdite o responsabilità derivanti dalla tua condotta o contenuti, e di indennizzarci, insieme alle nostre affiliate, per eventuali perdite risultanti."
          },
          {
            "title": "Terminazione del Servizio",
            "content": "Puoi smettere di utilizzare il Servizio in qualsiasi momento. Se violi questi Termini o se lo riteniamo necessario (ad esempio, per motivi di sicurezza o legali), possiamo sospendere o terminare il tuo accesso al Servizio senza preavviso. Dopo la terminazione, il tuo account e i dati associati possono essere eliminati in conformità con la nostra Politica di Privacy.",
            "subcontent": "Dopo la terminazione del Servizio, le disposizioni relative alla proprietà intellettuale, alla limitazione di responsabilità e alla risoluzione delle controversie rimarranno in vigore."
          },
          {
            "title": "Legge Applicabile e Risoluzione delle Controversie",
            "content": "Questi Termini sono regolati da [inserire la legge applicabile, come „diritto dell'UE“ o la legge di un paese specifico]. In caso di controversia, le parti tenteranno prima di risolverla amichevolmente. Se la negoziazione fallisce, la controversia sarà sottoposta a [inserire giurisdizione, come „i tribunali competenti nel tuo paese/regione“].",
            "subcontent": "In conformità al GDPR e alle leggi applicabili, hai il diritto di presentare reclami relativi a controversie sul trattamento dei dati all'autorità di protezione dei dati del tuo paese."
          },
          {
            "title": "Aggiornamento dei Termini",
            "content": "Possiamo aggiornare questi Termini di Servizio di tanto in tanto. La versione aggiornata sarà pubblicata su questa pagina o nel Servizio, con una nuova data di entrata in vigore. Le modifiche significative saranno comunicate tramite notifiche nel Servizio o via e-mail. Ti consigliamo di rivedere regolarmente questi Termini per conoscere i termini più recenti.",
            "subcontent": "L'uso continuato del Servizio implica l'accettazione dei Termini aggiornati."
          },
          {
            "title": "Contattaci",
            "content": "In caso di domande su questi Termini di Servizio o sul Servizio, invia la tua richiesta tramite la funzione ‚Contattaci‘ nel Servizio o il centro di assistenza. Risponderemo rapidamente e rispetteremo i requisiti di trasparenza e responsabilità delle leggi applicabili."
          }
        ]
      },
      "ja": {
        "title": "利用規約",
        "effective_date": "本利用規約の発効日：2025年3月24日",
        "version": "本利用規約のバージョン：2025V1.0",
        "intro": "当社のサービスをご利用いただきありがとうございます。本利用規約（以下「規約」）は、[サービス名]（以下「サービス」）の利用に関する条件を定めます。サービスを利用することで、本規約の条件に同意したものとみなされます。同意しない場合は、サービスをご利用にならないでください。当社は本規約をいつでも更新する権利を留保し、更新版はサービス内または本ページに掲載されます。本規約を定期的にご確認ください。",
        "sections": [
          {
            "title": "サービスの範囲",
            "content": "本サービスは[サービスの内容を記述、例：「オンラインアプリケーション、データ分析ツール、またはソーシャルプラットフォーム」]を提供し、[サービス目標を記述、例：「便利なデジタル体験」]を目指します。サービスの具体的な機能や利用可能性は、地域やデバイスによって異なる場合があります。当社は、事前通知なしにサービスの一部または全部を変更、一時停止、または終了する権利を留保しますが、重要な変更についてはサービス内通知を通じてお知らせするよう努めます。"
          },
          {
            "title": "ユーザーの資格とアカウント",
            "content": "本サービスを利用するには、16歳以上（またはお住まいの国/地域で定められた法定年齢）である必要があります。アカウントを作成する場合、正確、完全、かつ最新の登録情報を提供し、必要に応じて更新する必要があります。アカウントの安全性および関連するすべての活動（不正使用を含む）に対して、ユーザーは全責任を負います。アカウントの譲渡または共有は禁止されています。",
            "subcontent": "本規約に違反する行為が確認された場合、当社は事前通知なしにアカウントまたはサービスのアクセスを一時停止または終了する権利を留保します。"
          },
          {
            "title": "ユーザーの行動規範",
            "content": "サービス利用時に以下のルールを遵守することに同意します：1) 違法、詐欺的、または他者の権利を侵害する活動を行わない；2) マルウェア、ウイルス、その他の有害なコンテンツをアップロードまたは拡散しない；3) サービスの正常な運営を妨害または中断しない；4) すべての適用法および本規約を遵守する。",
            "subcontent": "これらのルールに違反した場合、アカウントの一時停止、終了、または法的措置が取られる可能性があります。当社はコンプライアンスを確保するため、ユーザーコンテンツおよび活動を監視する権利を留保しますが、すべてのコンテンツを監視する義務はありません。"
          },
          {
            "title": "知的財産",
            "content": "サービス内のすべてのコンテンツ（テキスト、画像、コード、デザインなどを含むがこれに限定されない）は、著作権、商標、またはその他の法律により保護されており、当社または当社のライセンサーに帰属します。ユーザーは個人かつ非商業的な目的でのみサービスコンテンツを使用でき、許可なく複製、改変、配布、またはその他の方法で使用することはできません。",
            "subcontent": "ユーザーがサービスを通じてアップロードするコンテンツ（「ユーザーコンテンツ」）はユーザーの所有物ですが、サービスの提供およびプロモーションのために、当社に対し世界的、非独占的、ロイヤリティフリーのライセンスを付与するものとします。"
          },
          {
            "title": "第三者サービスおよびリンク",
            "content": "本サービスには、第三者のサービスまたはリンク（例：Google Play、Firebase Analytics）が含まれる場合があります。これらのサービスは、それぞれの規約およびプライバシーポリシーに従い、当社はそれらのコンテンツ、機能、または行動について責任を負いません。関連する第三者の規約を確認することをお勧めします。",
            "list": [
              "Google Playサービス（アプリ配布用）",
              "Google Analytics（データ分析用）",
              "Firebase Analytics（パフォーマンス監視用）",
              "Crashlytics（エラーログ収集用）"
            ]
          },
          {
            "title": "責任の制限",
            "content": "当社はサービスの可用性および正確性を確保するよう努めますが、サービスは「現状のまま」提供され、商品性や特定目的への適合性を含む、明示的または黙示的な保証は一切ありません。適用法の範囲内で、当社はサービス利用に起因する直接的、間接的、偶発的、または結果的な損害について責任を負いません。",
            "subcontent": "ユーザーは自身の行為またはコンテンツに起因する請求、損失、または責任について全責任を負い、当社および関連会社に生じた損失を補償することに同意します。"
          },
          {
            "title": "サービスの終了",
            "content": "ユーザーはいつでもサービスの利用を停止できます。本規約に違反した場合、または当社が必要と判断した場合（例：セキュリティまたは法的な理由）、当社は事前通知なしにサービスへのアクセスを一時停止または終了できます。終了後、アカウントおよび関連データは当社のプライバシーポリシーに従って削除される場合があります。",
            "subcontent": "サービス終了後、知的財産、責任の制限、紛争解決に関する条項は引き続き有効です。"
          },
          {
            "title": "適用法および紛争解決",
            "content": "本規約は[適用法を挿入、例：「EU法」または特定の国の法律]に準拠します。紛争が発生した場合、両当事者はまず友好的に解決を試みます。交渉が失敗した場合、紛争は[管轄地を挿入、例：「お住まいの国/地域の管轄裁判所」]に提出されます。",
            "subcontent": "GDPRおよび関連法に基づき、データ処理に関する紛争について、お住まいの国のデータ保護機関に苦情を申し立てる権利があります。"
          },
          {
            "title": "規約の更新",
            "content": "本利用規約は随時更新される場合があります。更新版は本ページまたはサービス内に掲載され、新しい発効日が記載されます。重要な変更は、サービス内通知またはメールで通知されます。最新の条件を知るため、本規約を定期的に確認することをお勧めします。",
            "subcontent": "サービスの継続利用は、更新された規約への同意を意味します。"
          },
          {
            "title": "お問い合わせ",
            "content": "本利用規約またはサービスに関するご質問がある場合、サービス内の「お問い合わせ」機能またはヘルプセンターを通じてご依頼ください。迅速に対応し、適用法の透明性と説明責任の要件を遵守します。"
          }
        ]
      },
      "ko": {
        "title": "이용 약관",
        "effective_date": "본 이용 약관의 발효일: 2025년 3월 24일",
        "version": "본 이용 약관 버전: 2025V1.0",
        "intro": "저희 서비스를 이용해 주셔서 감사합니다. 본 이용 약관(이하 '약관')은 [서비스명](이하 '서비스')의 이용 조건을 규정합니다. 서비스를 이용함으로써 본 약관의 조건에 동의하는 것으로 간주됩니다. 동의하지 않을 경우, 서비스를 이용하지 마시기 바랍니다. 저희는 본 약관을 언제든지 업데이트할 권리를 보유하며, 업데이트된 버전은 서비스 내 또는 본 페이지에 게시됩니다. 본 약관을 정기적으로 검토해 주세요.",
        "sections": [
          {
            "title": "서비스 범위",
            "content": "본 서비스는 [서비스 내용 설명, 예: '온라인 애플리케이션, 데이터 분석 도구 또는 소셜 플랫폼']을 제공하여 [서비스 목표 설명, 예: '편리한 디지털 경험']을 목표로 합니다. 서비스의 구체적인 기능과 가용성은 지역 또는 기기에 따라 다를 수 있습니다. 저희는 사전 통지 없이 서비스의 일부 또는 전체를 수정, 중단 또는 종료할 권리를 보유하며, 중요한 변경 사항은 서비스 내 알림을 통해 알려드리도록 노력하겠습니다."
          },
          {
            "title": "사용자 자격 및 계정",
            "content": "본 서비스를 이용하려면 최소 16세 이상(또는 귀하의 국가/지역에서 정한 법적 연령)이어야 합니다. 계정을 생성해야 하는 경우, 정확하고 완전하며 최신의 등록 정보를 제공하고 필요 시 업데이트해야 합니다. 귀하는 계정의 보안과 관련된 모든 활동(무단 사용 포함)에 대해 전적으로 책임이 있습니다. 계정을 타인에게 양도하거나 공유할 수 없습니다.",
            "subcontent": "본 약관을 위반하는 행위가 발견될 경우, 저희는 사전 통지 없이 귀하의 계정 또는 서비스 접근을 중단하거나 종료할 권리를 보유합니다."
          },
          {
            "title": "사용자 행동 규범",
            "content": "서비스 이용 시 다음 규칙을 준수해야 합니다: 1) 불법적이거나 사기적이거나 타인의 권리를 침해하는 활동을 하지 않음; 2) 악성 소프트웨어, 바이러스 또는 기타 유해한 콘텐츠를 업로드하거나 배포하지 않음; 3) 서비스의 정상적인 운영을 방해하거나 중단하지 않음; 4) 모든 적용 법률 및 본 약관을 준수함.",
            "subcontent": "이 규칙을 위반하면 계정 중단, 종료 또는 법적 조치가 취해질 수 있습니다. 저희는 준수 여부를 확인하기 위해 사용자 콘텐츠와 활동을 모니터링할 권리를 보유하며, 모든 콘텐츠를 검토할 의무는 없습니다."
          },
          {
            "title": "지적 재산",
            "content": "서비스 내 모든 콘텐츠(텍스트, 이미지, 코드, 디자인 등을 포함하되 이에 국한되지 않음)는 저작권, 상표 또는 기타 법률에 의해 보호되며, 저희 또는 저희의 라이선스 제공자에게 귀속됩니다. 사용자는 개인적이고 비상업적인 목적으로만 서비스 콘텐츠를 사용할 수 있으며, 허가 없이 복제, 수정, 배포 또는 기타 방식으로 사용할 수 없습니다.",
            "subcontent": "사용자가 서비스를 통해 업로드한 콘텐츠('사용자 콘텐츠')는 여전히 사용자의 소유이나, 서비스 제공 및 홍보를 위해 저희에게 전 세계적, 비독점적, 로열티 없는 라이선스를 부여합니다."
          },
          {
            "title": "제3자 서비스 및 링크",
            "content": "본 서비스에는 제3자 서비스 또는 링크(예: Google Play, Firebase Analytics)가 포함될 수 있습니다. 이러한 서비스는 자체 약관 및 개인정보 처리방침에 따르며, 저희는 그 콘텐츠, 기능 또는 행동에 대해 책임지지 않습니다. 관련 제3자의 약관을 검토할 것을 권장합니다.",
            "list": [
              "Google Play 서비스(앱 배포용)",
              "Google Analytics(데이터 분석용)",
              "Firebase Analytics(성능 모니터링용)",
              "Crashlytics(오류 로그 수집용)"
            ]
          },
          {
            "title": "책임 제한",
            "content": "저희는 서비스의 가용성과 정확성을 보장하기 위해 노력하지만, 서비스는 '있는 그대로' 제공되며, 상품성 또는 특정 목적에의 적합성을 포함한 명시적 또는 묵시적 보증을 제공하지 않습니다. 적용 법률이 허용하는 범위 내에서, 서비스 이용으로 인한 직접적, 간접적, 부수적 또는 결과적 손해에 대해 책임지지 않습니다.",
            "subcontent": "귀하는 귀하의 행동 또는 콘텐츠로 인한 청구, 손실 또는 책임에 대해 전적으로 책임지며, 저희 및 저희의 계열사를 이에 따른 손실로부터 면책해야 합니다."
          },
          {
            "title": "서비스 종료",
            "content": "귀하는 언제든지 서비스 이용을 중단할 수 있습니다. 귀하가 본 약관을 위반하거나 저희가 필요하다고 판단할 경우(예: 보안 또는 법적 이유), 사전 통지 없이 서비스 접근을 중단하거나 종료할 수 있습니다. 종료 후, 귀하의 계정 및 관련 데이터는 저희의 개인정보 처리방침에 따라 삭제될 수 있습니다.",
            "subcontent": "서비스 종료 후, 지적 재산, 책임 제한, 분쟁 해결 관련 조항은 계속 유효합니다."
          },
          {
            "title": "적용 법률 및 분쟁 해결",
            "content": "본 약관은 [적용 법률 삽입, 예: 'EU 법률' 또는 특정 국가 법률]에 의해 규율됩니다. 분쟁이 발생할 경우, 양 당사자는 먼저 우호적으로 해결을 시도해야 합니다. 협상이 실패할 경우, 분쟁은 [관할지 삽입, 예: '귀하의 국가/지역의 관할 법원']에 제출됩니다.",
            "subcontent": "GDPR 및 관련 법률에 따라, 데이터 처리와 관련된 분쟁에 대해 귀하의 국가 데이터 보호 기관에 불만을 제기할 권리가 있습니다."
          },
          {
            "title": "약관 업데이트",
            "content": "본 이용 약관은 수시로 업데이트될 수 있습니다. 업데이트된 버전은 본 페이지 또는 서비스 내에 게시되며, 새로운 발효일이 명시됩니다. 중대한 변경은 서비스 내 알림 또는 이메일로 알려드립니다. 최신 약관을 알기 위해 본 약관을 정기적으로 검토할 것을 권장합니다.",
            "subcontent": "서비스를 계속 이용하면 업데이트된 약관에 동의한 것으로 간주됩니다."
          },
          {
            "title": "문의하기",
            "content": "본 이용 약관 또는 서비스에 대한 질문이 있는 경우, 서비스 내의 '문의하기' 기능 또는 헬프센터를 통해 요청을 제출해 주세요. 신속히 응답하며 적용 법률의 투명성과 책임 요구사항을 준수합니다."
          }
        ]
      },
      "ru": {
        "title": "Условия использования",
        "effective_date": "Дата вступления в силу этих Условий использования: 24 марта 2025 года",
        "version": "Версия Условий использования: 2025V1.0",
        "intro": "Добро пожаловать в наши сервисы. Настоящие Условия использования (далее „Условия“) регулируют использование [Название сервиса] (далее „Сервис“). Используя наши сервисы, вы соглашаетесь соблюдать эти Условия. Если вы не согласны, пожалуйста, не используйте Сервис. Мы оставляем за собой право обновлять эти Условия в любое время, и обновленная версия будет опубликована в Сервисе или на этой странице. Рекомендуем регулярно проверять эти Условия.",
        "sections": [
          {
            "title": "Объем услуг",
            "content": "Этот Сервис предоставляет [описание содержания сервиса, например, „онлайн-приложения, инструменты анализа данных или социальные платформы“], чтобы обеспечить [описание цели сервиса, например, „удобный цифровой опыт“]. Конкретные функции и доступность Сервиса могут варьироваться в зависимости от региона или устройства. Мы оставляем за собой право изменять, приостанавливать или прекращать часть или весь Сервис без предварительного уведомления, но будем стремиться информировать о значительных изменениях через уведомления в Сервисе."
          },
          {
            "title": "Квалификация пользователя и учетная запись",
            "content": "Вы должны быть не моложе 16 лет (или установленного законом возраста в вашей стране/регионе), чтобы использовать этот Сервис. Если требуется создание учетной записи, вы должны предоставить правдивую, точную и полную регистрационную информацию и обновлять ее при необходимости. Вы несете полную ответственность за безопасность своей учетной записи и все связанные с ней действия, включая несанкционированное использование. Передача или совместное использование учетной записи с другими запрещены.",
            "subcontent": "Мы оставляем за собой право приостановить или прекратить действие вашей учетной записи или доступ к Сервису без предварительного уведомления, если мы обнаружим нарушение этих Условий."
          },
          {
            "title": "Правила поведения пользователей",
            "content": "Вы соглашаетесь соблюдать следующие правила при использовании Сервиса: 1) Не участвовать в незаконных, мошеннических или нарушающих права других лиц действиях; 2) Не загружать и не распространять вредоносное ПО, вирусы или другой вредоносный контент; 3) Не мешать и не нарушать нормальное функционирование Сервиса; 4) Соблюдать все применимые законы и настоящие Условия.",
            "subcontent": "Нарушение этих правил может привести к приостановке или прекращению действия учетной записи или к юридическим действиям. Мы оставляем за собой право отслеживать контент и действия пользователей для обеспечения соответствия, но не обязуемся проверять весь контент."
          },
          {
            "title": "Интеллектуальная собственность",
            "content": "Весь контент Сервиса (включая, но не ограничиваясь текстами, изображениями, кодом, дизайнами) защищен авторским правом, товарными знаками или другими законами и принадлежит нам или нашим лицензиарам. Вы можете использовать контент Сервиса только для личных некоммерческих целей и не можете копировать, изменять, распространять или иным образом использовать контент без разрешения.",
            "subcontent": "Контент, который вы загружаете через Сервис („Пользовательский контент“), остается вашей собственностью, но вы предоставляете нам всемирную, неэксклюзивную, безвозмездную лицензию на использование, хранение, воспроизведение и отображение этого контента для предоставления и продвижения Сервиса."
          },
          {
            "title": "Сторонние сервисы и ссылки",
            "content": "Сервис может включать сторонние сервисы или ссылки (например, Google Play, Firebase Analytics). Эти сервисы подчиняются их собственным условиям и политикам конфиденциальности, и мы не несем ответственности за их контент, функции или поведение. Рекомендуем ознакомиться с условиями соответствующих сторонних сервисов.",
            "list": [
              "Сервисы Google Play (для распространения приложений)",
              "Google Analytics (для анализа данных)",
              "Firebase Analytics (для мониторинга производительности)",
              "Crashlytics (для сбора логов ошибок)"
            ]
          },
          {
            "title": "Ограничение ответственности",
            "content": "Мы стремимся обеспечить доступность и точность Сервиса, но Сервис предоставляется „как есть“ без каких-либо явных или подразумеваемых гарантий, включая, но не ограничиваясь гарантиями товарной пригодности или пригодности для определенной цели. В пределах, допускаемых применимым законодательством, мы не несем ответственности за любые прямые, косвенные, случайные или последующие убытки, возникшие в результате использования Сервиса.",
            "subcontent": "Вы соглашаетесь нести полную ответственность за любые претензии, убытки или обязательства, возникшие в результате вашего поведения или контента, и возместить нам и нашим аффилированным лицам любые убытки, связанные с этим."
          },
          {
            "title": "Прекращение использования Сервиса",
            "content": "Вы можете прекратить использование Сервиса в любое время. Если вы нарушаете эти Условия или мы сочтем это необходимым (например, по соображениям безопасности или юридическим причинам), мы можем приостановить или прекратить ваш доступ к Сервису без предварительного уведомления. После прекращения ваша учетная запись и связанные данные могут быть удалены в соответствии с нашей Политикой конфиденциальности.",
            "subcontent": "После прекращения использования Сервиса положения, касающиеся интеллектуальной собственности, ограничения ответственности и разрешения споров, остаются в силе."
          },
          {
            "title": "Применимое право и разрешение споров",
            "content": "Эти Условия регулируются [вставить применимое право, например, „законодательство ЕС“ или закон конкретной страны]. В случае спора стороны сначала попытаются разрешить его мирным путем. Если переговоры не увенчаются успехом, спор будет передан в [вставить юрисдикцию, например, „компетентные суды в вашей стране/регионе“].",
            "subcontent": "В соответствии с GDPR и применимыми законами вы имеете право подавать жалобы по спорам, связанным с обработкой данных, в орган по защите данных вашей страны."
          },
          {
            "title": "Обновление Условий",
            "content": "Мы можем обновлять эти Условия использования время от времени. Обновленная версия будет опубликована на этой странице или в Сервисе с указанием новой даты вступления в силу. О существенных изменениях мы уведомим вас через уведомления в Сервисе или по электронной почте. Рекомендуем регулярно проверять эти Условия, чтобы быть в курсе последних условий.",
            "subcontent": "Продолжение использования Сервиса означает ваше согласие с обновленными Условиями."
          },
          {
            "title": "Свяжитесь с нами",
            "content": "Если у вас есть вопросы по этим Условиям использования или Сервису, отправьте ваш запрос через функцию ‚Связаться с нами‘ в Сервисе или через центр помощи. Мы ответим быстро и будем соблюдать требования прозрачности и подотчетности применимых законов."
          }
        ]
      },
      "zh-TW": {
          "title": "用戶協議",
          "effective_date": "本用戶協議生效日期：2025年3月24日",
          "version": "本用戶協議版本：2025V1.0",
          "intro": "歡迎使用我們的服務。本用戶協議（以下簡稱‘協議’）規定了您使用[服務名稱]（以下簡稱‘服務’）的條款和條件。使用我們的服務即表示您同意遵守本協議的條款。如不同意，請勿使用我們的服務。我們保留隨時更新本協議的權利，更新版本將在服務內或本頁面發布。請定期審閱本協議。",
          "sections": [
            {
              "title": "服務範圍",
              "content": "本服務提供[描述服務內容，如‘線上應用程式、數據分析工具或社交平台’]，旨在為用戶提供[描述服務目標，如‘便捷的數位體驗’]。服務的具體功能和可用性可能因地區或設備而異。我們保留隨時修改、暫停或終止部分或全部服務的權利，恕不另行通知，但會盡力通過服務內通知告知重大變更。"
            },
            {
              "title": "用戶資格與帳戶",
              "content": "您須年滿16歲（或您所在國家/地區規定的法定年齡）方可使用本服務。如需創建帳戶，您應提供真實、準確且完整的註冊資訊，並及時更新。您對帳戶的安全性和所有活動負全部責任，包括任何未經授權的使用。不得將帳戶轉讓或分享給他人。",
              "subcontent": "我們保留在發現任何違反本協議的行為時，暫停或終止您的帳戶或服務訪問權限的權利，恕不另行通知。"
            },
            {
              "title": "用戶行為規範",
              "content": "您同意在使用服務時遵守以下規則：1) 不從事非法、欺詐或侵犯他人權利的活動；2) 不上傳或傳播惡意軟體、病毒或其他有害內容；3) 不干擾或破壞服務的正常運行；4) 遵守所有適用法律和本協議條款。",
              "subcontent": "違反上述規則可能導致帳戶暫停、終止或法律行動。我們保留監控用戶內容和活動的權利，以確保合規性，但不承諾審查所有內容。"
            },
            {
              "title": "智慧財產權",
              "content": "服務中的所有內容（包括但不限於文字、圖像、程式碼、設計）均受版權、商標或其他法律保護，歸我們或我們的許可方所有。您僅可為個人、非商業目的使用服務內容，不得複製、修改、分發或以其他方式使用未經授權的內容。",
              "subcontent": "您通過服務上傳的內容（‘用戶內容’）仍歸您所有，但您授予我們全球性、非獨占、免版稅的許可，允許我們在提供和推廣服務時使用、儲存、複製和展示該內容。"
            },
            {
              "title": "第三方服務與連結",
              "content": "本服務可能包含第三方服務或連結（如Google Play、Firebase Analytics）。這些服務受其自身條款和隱私政策約束，我們不對其內容、功能或行為負責。建議您審閱相關第三方的條款。",
              "list": [
                "Google Play 服務（用於應用分發）",
                "Google Analytics（用於數據分析）",
                "Firebase Analytics（用於性能監控）",
                "Crashlytics（用於錯誤日誌收集）"
              ]
            },
            {
              "title": "責任限制",
              "content": "我們盡力確保服務的可用性和準確性，但服務按‘現狀’提供，不提供任何明示或暗示的保證，包括但不限於適銷性或特定用途適用性的保證。在適用法律允許的範圍內，我們對因使用服務導致的任何直接、間接、附帶或後果性損失不承擔責任。",
              "subcontent": "您同意對因您的行為或內容引起的任何索賠、損失或責任承擔全部責任，並賠償我們及我們的關聯方因此遭受的損失。"
            },
            {
              "title": "服務終止",
              "content": "您可隨時停止使用服務。如您違反本協議或我們認為有必要（如出於安全或法律原因），我們可隨時暫停或終止您對服務的訪問，恕不另行通知。終止後，您的帳戶和相關數據可能被刪除，符合我們的隱私政策。",
              "subcontent": "在終止服務後，本協議中與智慧財產權、責任限制和爭議解決相關的條款將繼續有效。"
            },
            {
              "title": "適用法律與爭議解決",
              "content": "本協議受[插入適用法律，如‘歐盟法律’或具體國家法律]管轄。如發生爭議，雙方應首先嘗試通過友好協商解決。若協商失敗，爭議應提交[插入管轄區，如‘您所在國家/地區的有管轄權法院’]處理。",
              "subcontent": "根據GDPR及相關法律，您有權向您所在國家的數據保護機構投訴任何與數據處理相關的爭議。"
            },
            {
              "title": "協議更新",
              "content": "我們可能不時更新本用戶協議。更新版本將在本頁面或服務內發布，並註明新生效日期。重大變更將通過服務內通知或電子郵件告知您。建議您定期審閱本協議以了解最新條款。",
              "subcontent": "繼續使用服務即表示您接受更新後的協議。"
            },
            {
              "title": "聯繫我們",
              "content": "如對本用戶協議或服務有任何疑問，請通過我們服務內的‘聯繫我們’功能或幫助中心提交您的請求。我們將盡快回應，並確保遵守適用法律的透明度和問責制要求。"
            }
          ]
        }
      };

    function getLangFromUrl() {
    const params = new URLSearchParams(window.location.search);
    return params.get('lang') || 'en'; // 默认中文
  }

  function loadLanguage(lang) {
    try {
      const data = translations[lang] || translations['en'];

      const source = document.getElementById('privacy-agreement-template').innerHTML;
      const template = Handlebars.compile(source);

      document.getElementById('privacy-agreement-container').innerHTML = template(data);

      document.getElementById('page-title').textContent = data.title;
      document.documentElement.lang = lang;
    } catch (error) {
      console.error('Language rendering error:', error);
      loadLanguage('en');
    }
  }

  // 暴露给 Android 原生调用的函数
  window.switchLanguage = function(lang) {
    loadLanguage(lang || 'en');
  };

  // 根据 URL 参数加载语言
  const lang = getLangFromUrl();
  loadLanguage(lang);