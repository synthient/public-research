package io.android.cast.receiver.tv.ext

import android.content.Context
import android.net.wifi.WifiManager
import android.os.Build
import java.net.Inet4Address
import java.net.NetworkInterface
import java.util.Locale

/**
 * 获取当前连接的 Wi-Fi 名称与 IP 地址
 * @return Pair(SSID, IP地址)，任意一个获取失败时返回空字符串
 */
fun Context.getConnectedWifiInfo(): Pair<String, String> {
    var ssid = ""
    var ipAddress = ""

    val wifiManager = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager

    try {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            // Android 10+ 无法直接取 SSID，只能取最后一次连接信息
            ssid = wifiManager.connectionInfo?.ssid?.replace("\"", "") ?: ""

            // 通过 NetworkInterface 获取 IP
            NetworkInterface.getNetworkInterfaces()?.iterator()?.forEach { network ->
                if (network.name.equals("wlan0", ignoreCase = true)) {
                    network.inetAddresses.iterator().forEach { address ->
                        if (!address.isLoopbackAddress && address is Inet4Address) {
                            ipAddress = address.hostAddress ?: ""
                        }
                    }
                }
            }
        } else {
            val wifiInfo = wifiManager.connectionInfo
            ssid = wifiInfo.ssid?.replace("\"", "") ?: ""
            val ip = wifiInfo.ipAddress
            if (ip != 0) {
                ipAddress = String.format(
                    Locale.US,
                    "%d.%d.%d.%d",
                    ip and 0xff,
                    ip shr 8 and 0xff,
                    ip shr 16 and 0xff,
                    ip shr 24 and 0xff
                )
            }
        }
    } catch (e: Exception) {
        e.printStackTrace()
    }

    return Pair(ssid, ipAddress)
}
