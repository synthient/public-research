package io.android.cast.receiver.tv.ui.fragment

import android.app.ActivityManager
import android.content.Context
import android.os.Process
import io.android.cast.receiver.tv.AppCache
import io.android.cast.receiver.tv.MainActivity
import io.android.cast.receiver.tv.databinding.FragmentPrivacypolicyBinding
import io.android.cast.receiver.tv.ext.openPrivacyPolicy
import io.android.code.lib_base.base.BaseVMFragment
import io.android.code.lib_base.base.BaseViewModel
import io.android.code.lib_base.ext.clickNoRepeat
import kotlin.system.exitProcess

class PrivacyPolicyFragment : BaseVMFragment<FragmentPrivacypolicyBinding, BaseViewModel>() {
    override fun initView() {
        mBind.apply {
            tvAgree.requestFocus()
            tvPrivacyPolicy.clickNoRepeat {
                //点击隐私政策跳转
                requireActivity().openPrivacyPolicy()
            }
            tvAgree.clickNoRepeat {
                //点击同意
                AppCache.isPrivacyPolicyAgreed = true
                //sendLiveEventData(AGREE_PRIVACY_POLICY,true)
                (requireActivity() as MainActivity).loadMain()

            }
            tvDisagree.clickNoRepeat {
                //点击不同意
                //finishAllActivity()
                Process.killProcess(Process.myPid());
                exitProcess(0);


            }
        }
    }

    fun forceStopApp(context: Context, packageName: String) {
        try {
            val activityManager =
                context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            activityManager::class.java.getMethod("forceStopPackage", String::class.java)
                .invoke(activityManager, packageName)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

}