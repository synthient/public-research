package io.android.cast.receiver.tv.ui.fragment

import io.android.cast.receiver.tv.R
import io.android.cast.receiver.tv.bean.SettingDto
import io.android.cast.receiver.tv.databinding.FragmentSettingEmtBinding
import io.android.cast.receiver.tv.databinding.ItemSettingBinding
import io.android.cast.receiver.tv.ext.openDisclaimer
import io.android.cast.receiver.tv.ext.openPrivacyPolicy
import io.android.cast.receiver.tv.ext.openUserAgreement
import io.android.cast.receiver.tv.ext.openUserUsage
import io.android.cast.receiver.tv.ext.scaleAnimation
import io.android.cast.receiver.tv.manager.SettingManager
import io.android.cast.receiver.tv.ui.dialog.CenterCommonDialog
import io.android.cast.receiver.tv.ui.dialog.base.showDialog
import io.android.code.lib_base.appContext
import io.android.code.lib_base.base.BaseVMFragment
import io.android.code.lib_base.base.BaseViewModel
import io.android.code.lib_base.ext.appVersionName
import io.android.code.lib_base.ext.clickNoRepeatWithAnim
import io.android.code.lib_base.ext.dimenValue
import io.android.code.lib_base.ext.rv.setup
import io.android.code.lib_base.ext.stringValueWithFormat

class SettingEmtFragment : BaseVMFragment<FragmentSettingEmtBinding, BaseViewModel>() {

    override fun initView() {
        initRV()
    }

    private fun initRV() {

        val settingList = SettingManager.getSettingItem()
        mBind.rvSetting.setItemSpacing(com.codeZeng.lib_dimen.R.dimen.qb_px_20.dimenValue())
        mBind.rvSetting.setup(settingList) {
            addType(SettingDto::class, R.layout.item_setting)
            onBind {

                val itemBinding = getBinding<ItemSettingBinding>()
                val item = getModel<SettingDto>()
                itemBinding.ivIcon.setImageResource(item.icon_res)
                itemBinding.tvTitle.text = item.title_name

                itemBinding.tvSubtitle.text = item.subtitle_name


                itemView.setOnFocusChangeListener { v, hasFocus ->
                    itemView.scaleAnimation(hasFocus, 1.03f)
                    itemBinding.tvTitle.isSelected = hasFocus
                    itemBinding.tvSubtitle.isSelected = hasFocus
                    if (hasFocus) itemBinding.ivIcon.setImageResource(item.icon_res_focus) else itemBinding.ivIcon.setImageResource(
                        item.icon_res
                    )

                }
                itemView.clickNoRepeatWithAnim(shrinkScale = 0.96f) {
                    when (item.id) {
                        "about" -> {
                            //关于
                            showDialog(CenterCommonDialog()) {
                                isShowSingleBtn.value = true
                                textTip.value =
                                    R.string.about_text.stringValueWithFormat(appContext.appVersionName,appContext.packageName)
                            }
                        }

                        "disclaimer" -> {
                            //免责声明
                            requireActivity().openDisclaimer()
                        }

                        "usage_statement" -> {
                            //使用声明
                            requireActivity().openUserUsage()
                        }

                        "privacy_policy" -> {
                            //隐私政策
                            requireActivity().openPrivacyPolicy()
                        }

                        "user_agreement" -> {
                            //用户协议
                            requireActivity().openUserAgreement()
                        }


                    }
                }
            }
        }
    }


}