const translations = {
    "en": {
        "title": "Disclaimer",
        "intro": "Welcome to our screen mirroring application (hereinafter referred to as 'the App'). Before using the App, please carefully read the following disclaimer. Any use of the App constitutes your acknowledgment, understanding, and agreement to the following terms.",
        "sections": [
            {
                "title": "Limitation of Liability",
                "content": "The App provides functionality to mirror content from one device to another. We make no express or implied warranties regarding the accuracy, completeness, reliability, suitability, or availability of the mirrored content. Users are responsible for ensuring the legality and compliance of the content they mirror and bear all associated responsibilities."
            },
            {
                "title": "Copyright and Intellectual Property",
                "content": "All content mirrored through the App, including but not limited to videos, audio, images, and text, must be used with legal rights or necessary authorization. Users must not use the App to infringe on any third party’s copyright, trademark, patent, or other intellectual property rights. Users bear full legal responsibility for any violations."
            },
            {
                "title": "Privacy Protection",
                "content": "We respect your privacy. All information provided while using the App will be protected in accordance with our Privacy Policy. Users should understand and agree that content mirrored through the App may be received and viewed by other devices or users."
            },
            {
                "title": "Service Interruption or Termination",
                "content": "We reserve the right to interrupt or terminate the App’s services at any time, temporarily or permanently, without liability for any damages caused to users or third parties due to such interruption or termination."
            },
            {
                "title": "Third-Party Links",
                "content": "The App may provide links to third-party websites or services. We are not responsible for the content, privacy policies, or practices of these third-party sites or services. Users access and use these linked sites or services at their own discretion and risk."
            },
            {
                "title": "Modification of Terms",
                "content": "We reserve the right to modify this Disclaimer at any time. The updated terms take effect immediately upon publication. Continued use of the App implies acceptance of the modified terms."
            },
            {
                "title": "Entire Agreement",
                "content": "This Disclaimer constitutes the entire agreement between you and us regarding the use of the App, superseding any prior communications, representations, or understandings, whether written or oral, concerning the App."
            }
        ]
    },
    "ar": {
        "title": "إخلاء المسؤولية",
        "intro": "مرحبًا بكم في تطبيقنا لعكس الشاشة (يُشار إليه فيما بعد بـ 'التطبيق'). قبل استخدام التطبيق، يرجى قراءة إخلاء المسؤولية التالي بعناية. يعتبر أي استخدام للتطبيق موافقة منكم على قراءة هذه الشروط وفهمها وقبولها.",
        "sections": [
            {
                "title": "تحديد المسؤولية",
                "content": "يوفر التطبيق وظيفة عكس المحتوى من جهاز إلى آخر. لا نقدم أي ضمانات صريحة أو ضمنية بشأن دقة المحتوى المعكوس أو اكتماله أو موثوقيته أو ملاءمته أو توفره. يتحمل المستخدمون مسؤولية ضمان شرعية وامتثال المحتوى الذي يعكسونه ويتحملون جميع المسؤوليات المرتبطة بذلك."
            },
            {
                "title": "حقوق الطبع والملكية الفكرية",
                "content": "يجب أن يكون لدى المستخدمين حقوق استخدام قانونية أو ترخيص ضروري لجميع المحتويات المعكوسة عبر التطبيق، بما في ذلك على سبيل المثال لا الحصر الفيديوهات، الصوتيات، الصور، والنصوص. يُمنع استخدام التطبيق لانتهاك حقوق الطبع والنشر أو العلامات التجارية أو براءات الاختراع أو غيرها من حقوق الملكية الفكرية لأي طرف ثالث. يتحمل المستخدمون المسؤولية القانونية الكاملة عن أي انتهاكات."
            },
            {
                "title": "حماية الخصوصية",
                "content": "نحن نحترم خصوصية المستخدمين. سيتم حماية جميع المعلومات المقدمة أثناء استخدام التطبيق وفقًا لسياسة الخصوصية الخاصة بنا. يجب على المستخدمين فهم وتأكيد أن المحتوى المعكوس عبر التطبيق قد يتم استقباله وعرضه بواسطة أجهزة أو مستخدمين آخرين."
            },
            {
                "title": "انقطاع الخدمة أو إنهاؤها",
                "content": "نحتفظ بالحق في تعليق أو إنهاء خدمات التطبيق في أي وقت، بشكل مؤقت أو دائم، دون تحمل أي مسؤولية عن الأضرار التي قد تلحق بالمستخدمين أو أي طرف ثالث نتيجة هذا الانقطاع أو الإنهاء."
            },
            {
                "title": "روابط الطرف الثالث",
                "content": "قد يوفر التطبيق روابط لمواقع أو خدمات طرف ثالث. نحن لسنا مسؤولين عن محتوى هذه المواقع أو الخدمات أو سياسات الخصوصية أو الممارسات الخاصة بها. يتحمل المستخدمون مسؤولية الوصول إلى هذه المواقع أو الخدمات المرتبطة والاستخدام على مسؤوليتهم الخاصة."
            },
            {
                "title": "تعديل الشروط",
                "content": "نحتفظ بالحق في تعديل إخلاء المسؤولية هذا في أي وقت. تسري الشروط المعدلة فور نشرها. استمرار استخدام التطبيق يعني قبول الشروط المعدلة."
            },
            {
                "title": "الاتفاقية الكاملة",
                "content": "يشكل إخلاء المسؤولية هذا الاتفاقية الكاملة بينكم وبيننا بشأن استخدام التطبيق، ويحل محل أي اتصالات أو تمثيلات أو تفاهمات سابقة، سواء كانت مكتوبة أو شفهية، تتعلق بالتطبيق."
            }
        ]
    },
    "de": {
        "title": "Haftungsausschluss",
        "intro": "Willkommen bei unserer Bildschirmspiegelungsanwendung (im Folgenden als 'die App' bezeichnet). Bitte lesen Sie den folgenden Haftungsausschluss sorgfältig durch, bevor Sie die App verwenden. Jegliche Nutzung der App gilt als Ihre Bestätigung, dass Sie die folgenden Bedingungen gelesen, verstanden und akzeptiert haben.",
        "sections": [
            {
                "title": "Haftungsbeschränkung",
                "content": "Die App ermöglicht das Spiegeln von Inhalten von einem Gerät auf ein anderes. Wir geben keine ausdrücklichen oder stillschweigenden Garantien hinsichtlich der Genauigkeit, Vollständigkeit, Zuverlässigkeit, Eignung oder Verfügbarkeit der gespiegelten Inhalte. Nutzer sind verantwortlich für die Sicherstellung der Rechtmäßigkeit und Konformität der gespiegelten Inhalte und tragen alle damit verbundenen Verantwortlichkeiten."
            },
            {
                "title": "Urheberrecht und geistiges Eigentum",
                "content": "Alle durch die App gespiegelten Inhalte, einschließlich, aber nicht beschränkt auf Videos, Audio, Bilder und Texte, müssen mit rechtmäßigen Nutzungsrechten oder erforderlichen Genehmigungen verwendet werden. Nutzer dürfen die App nicht verwenden, um Urheberrechte, Marken, Patente oder andere geistige Eigentumsrechte Dritter zu verletzen. Nutzer tragen die volle rechtliche Verantwortung für Verstöße."
            },
            {
                "title": "Datenschutz",
                "content": "Wir respektieren Ihre Privatsphäre. Alle Informationen, die während der Nutzung der App bereitgestellt werden, werden gemäß unserer Datenschutzrichtlinie geschützt. Nutzer sollten verstehen und zustimmen, dass gespiegelte Inhalte von anderen Geräten oder Nutzern empfangen und eingesehen werden können."
            },
            {
                "title": "Unterbrechung oder Beendigung des Dienstes",
                "content": "Wir behalten uns das Recht vor, die Dienste der App jederzeit vorübergehend oder dauerhaft zu unterbrechen oder zu beenden, ohne Haftung für Schäden, die Nutzern oder Dritten durch solche Unterbrechungen oder Beendigungen entstehen."
            },
            {
                "title": "Links zu Drittanbietern",
                "content": "Die App kann Links zu Websites oder Diensten Dritter enthalten. Wir sind nicht verantwortlich für die Inhalte, Datenschutzrichtlinien oder Praktiken dieser Drittanbieter-Websites oder -Dienste. Nutzer greifen auf diese verlinkten Websites oder Dienste auf eigenes Risiko zu."
            },
            {
                "title": "Änderung der Bedingungen",
                "content": "Wir behalten uns das Recht vor, diesen Haftungsausschluss jederzeit zu ändern. Die geänderten Bedingungen treten sofort nach Veröffentlichung in Kraft. Die fortgesetzte Nutzung der App bedeutet die Annahme der geänderten Bedingungen."
            },
            {
                "title": "Gesamte Vereinbarung",
                "content": "Dieser Haftungsausschluss stellt die gesamte Vereinbarung zwischen Ihnen und uns in Bezug auf die Nutzung der App dar und ersetzt alle vorherigen Mitteilungen, Darstellungen oder Vereinbarungen, ob schriftlich oder mündlich, bezüglich der App."
            }
        ]
    },
    "es": {
        "title": "Descargo de Responsabilidad",
        "intro": "Bienvenido a nuestra aplicación de duplicación de pantalla (en adelante, 'la App'). Antes de usar la App, lea cuidadosamente el siguiente descargo de responsabilidad. Cualquier uso de la App implica que ha leído, comprendido y aceptado los siguientes términos.",
        "sections": [
            {
                "title": "Limitación de Responsabilidad",
                "content": "La App permite duplicar contenido de un dispositivo a otro. No ofrecemos garantías expresas o implícitas sobre la exactitud, integridad, fiabilidad, idoneidad o disponibilidad del contenido duplicado. Los usuarios son responsables de garantizar la legalidad y conformidad del contenido duplicado y asumen todas las responsabilidades asociadas."
            },
            {
                "title": "Derechos de Autor y Propiedad Intelectual",
                "content": "Todo el contenido duplicado a través de la App, incluyendo, pero no limitado a videos, audio, imágenes y textos, debe usarse con derechos legales o autorización necesaria. Los usuarios no deben usar la App para infringir los derechos de autor, marcas registradas, patentes u otros derechos de propiedad intelectual de terceros. Los usuarios asumen toda la responsabilidad legal por cualquier infracción."
            },
            {
                "title": "Protección de la Privacidad",
                "content": "Respetamos su privacidad. Toda la información proporcionada durante el uso de la App estará protegida de acuerdo con nuestra Política de Privacidad. Los usuarios deben entender y aceptar que el contenido duplicado a través de la App puede ser recibido y visto por otros dispositivos o usuarios."
            },
            {
                "title": "Interrupción o Terminación del Servicio",
                "content": "Nos reservamos el derecho de interrumpir o terminar los servicios de la App en cualquier momento, de forma temporal o permanente, sin responsabilidad por los daños causados a los usuarios o terceros debido a dicha interrupción o terminación."
            },
            {
                "title": "Enlaces a Terceros",
                "content": "La App puede incluir enlaces a sitios web o servicios de terceros. No somos responsables del contenido, políticas de privacidad o prácticas de estos sitios o servicios de terceros. Los usuarios acceden y usan estos sitios o servicios vinculados bajo su propia responsabilidad."
            },
            {
                "title": "Modificación de Términos",
                "content": "Nos reservamos el derecho de modificar este Descargo de Responsabilidad en cualquier momento. Los términos modificados entrarán en vigor inmediatamente tras su publicación. El uso continuado de la App implica la aceptación de los términos modificados."
            },
            {
                "title": "Acuerdo Completo",
                "content": "Este Descargo de Responsabilidad constituye el acuerdo completo entre usted y nosotros respecto al uso de la App, y reemplaza cualquier comunicación, representación o entendimiento previo, ya sea escrito u oral, relacionado con la App."
            }
        ]
    },
    "fr": {
        "title": "Avis de Non-Responsabilité",
        "intro": "Bienvenue sur notre application de mise en miroir d’écran (ci-après dénommée 'l’Application'). Avant d’utiliser l’Application, veuillez lire attentivement l’avis de non-responsabilité suivant. Toute utilisation de l’Application constitue votre reconnaissance, compréhension et acceptation des termes suivants.",
        "sections": [
            {
                "title": "Limitation de Responsabilité",
                "content": "L’Application permet de mettre en miroir le contenu d’un appareil à un autre. Nous ne fournissons aucune garantie expresse ou implicite concernant l’exactitude, l’exhaustivité, la fiabilité, l’adéquation ou la disponibilité du contenu mis en miroir. Les utilisateurs sont responsables de s’assurer de la légalité et de la conformité du contenu mis en miroir et assument toutes les responsabilités associées."
            },
            {
                "title": "Droits d’Auteur et Propriété Intellectuelle",
                "content": "Tout contenu mis en miroir via l’Application, y compris, mais sans s’y limiter, les vidéos, audios, images et textes, doit être utilisé avec des droits légaux ou une autorisation nécessaire. Les utilisateurs ne doivent pas utiliser l’Application pour enfreindre les droits d’auteur, marques déposées, brevets ou autres droits de propriété intellectuelle de tiers. Les utilisateurs assument l’entière responsabilité légale pour toute violation."
            },
            {
                "title": "Protection de la Confidentialité",
                "content": "Nous respectons votre vie privée. Toutes les informations fournies lors de l’utilisation de l’Application seront protégées conformément à notre Politique de Confidentialité. Les utilisateurs doivent comprendre et accepter que le contenu mis en miroir via l’Application peut être reçu et vu par d’autres appareils ou utilisateurs."
            },
            {
                "title": "Interruption ou Résiliation du Service",
                "content": "Nous nous réservons le droit d’interrompre ou de résilier les services de l’Application à tout moment, temporairement ou définitivement, sans responsabilité pour les dommages causés aux utilisateurs ou à des tiers en raison de cette interruption ou résiliation."
            },
            {
                "title": "Liens vers des Tiers",
                "content": "L’Application peut inclure des liens vers des sites ou services tiers. Nous ne sommes pas responsables du contenu, des politiques de confidentialité ou des pratiques de ces sites ou services tiers. Les utilisateurs accèdent et utilisent ces sites ou services liés à leurs propres risques."
            },
            {
                "title": "Modification des Termes",
                "content": "Nous nous réservons le droit de modifier cet Avis de Non-Responsabilité à tout moment. Les termes modifiés prennent effet immédiatement après leur publication. L’utilisation continue de l’Application implique l’acceptation des termes modifiés."
            },
            {
                "title": "Accord Intégral",
                "content": "Cet Avis de Non-Responsabilité constitue l’accord intégral entre vous et nous concernant l’utilisation de l’Application, et remplace toute communication, représentation ou compréhension préalable, écrite ou orale, concernant l’Application."
            }
        ]
    },
    "it": {
        "title": "Esclusione di Responsabilità",
        "intro": "Benvenuto nella nostra applicazione di mirroring dello schermo (di seguito denominata 'l’App'). Prima di utilizzare l’App, leggi attentamente la seguente esclusione di responsabilità. Qualsiasi utilizzo dell’App implica che hai letto, compreso e accettato i seguenti termini.",
        "sections": [
            {
                "title": "Limitazione di Responsabilità",
                "content": "L’App consente di duplicare contenuti da un dispositivo a un altro. Non forniamo garanzie espresse o implicite riguardo all’accuratezza, completezza, affidabilità, idoneità o disponibilità dei contenuti duplicati. Gli utenti sono responsabili di garantire la legalità e la conformità dei contenuti duplicati e assumono tutte le responsabilità associate."
            },
            {
                "title": "Diritti d’Autore e Proprietà Intellettuale",
                "content": "Tutti i contenuti duplicati tramite l’App, inclusi, ma non limitati a, video, audio, immagini e testi, devono essere utilizzati con diritti legali o autorizzazioni necessarie. Gli utenti non devono utilizzare l’App per violare i diritti d’autore, marchi registrati, brevetti o altri diritti di proprietà intellettuale di terzi. Gli utenti assumono la piena responsabilità legale per eventuali violazioni."
            },
            {
                "title": "Protezione della Privacy",
                "content": "Rispettiamo la tua privacy. Tutte le informazioni fornite durante l’uso dell’App saranno protette in conformità con la nostra Informativa sulla Privacy. Gli utenti devono comprendere e accettare che i contenuti duplicati tramite l’App possono essere ricevuti e visualizzati da altri dispositivi o utenti."
            },
            {
                "title": "Interruzione o Cessazione del Servizio",
                "content": "Ci riserviamo il diritto di interrompere o terminare i servizi dell’App in qualsiasi momento, temporaneamente o permanentemente, senza responsabilità per eventuali danni causati agli utenti o a terzi a seguito di tale interruzione o cessazione."
            },
            {
                "title": "Link a Terzi",
                "content": "L’App può includere collegamenti a siti web o servizi di terzi. Non siamo responsabili per i contenuti, le politiche sulla privacy o le pratiche di questi siti o servizi di terzi. Gli utenti accedono e utilizzano questi siti o servizi collegati a proprio rischio."
            },
            {
                "title": "Modifica dei Termini",
                "content": "Ci riserviamo il diritto di modificare questa Esclusione di Responsabilità in qualsiasi momento. I termini modificati entrano in vigore immediatamente dopo la pubblicazione. L’uso continuato dell’App implica l’accettazione dei termini modificati."
            },
            {
                "title": "Accordo Completo",
                "content": "Questa Esclusione di Responsabilità costituisce l’intero accordo tra te e noi riguardo all’uso dell’App, e sostituisce qualsiasi comunicazione, rappresentazione o intesa precedente, sia scritta che orale, relativa all’App."
            }
        ]
    },
    "ja": {
        "title": "免責事項",
        "intro": "当社のスクリーンミラーリングアプリケーション（以下「本アプリ」と称します）へようこそ。本アプリを使用する前に、以下の免責事項をよくお読みください。本アプリの使用は、以下の条件を読み、理解し、同意したものとみなされます。",
        "sections": [
            {
                "title": "責任の制限",
                "content": "本アプリは、あるデバイスから別のデバイスへコンテンツをミラーリングする機能を提供します。ミラーリングされたコンテンツの正確性、完全性、信頼性、適合性、または可用性について、明示的または黙示的な保証は行いません。ユーザーは、ミラーリングするコンテンツの合法性と適合性を確保する責任を負い、それに関連するすべての責任を負います。"
            },
            {
                "title": "著作権および知的財産",
                "content": "本アプリを通じてミラーリングされるすべてのコンテンツ（ビデオ、オーディオ、画像、テキストなどを含むがこれに限定されない）は、合法的な使用権または必要な許可を得て使用する必要があります。ユーザーは、本アプリを使用して第三者の著作権、商標、特許、その他の知的財産権を侵害してはなりません。違反した場合、ユーザーはすべての法的責任を負います。"
            },
            {
                "title": "プライバシー保護",
                "content": "当社はユーザーのプライバシーを尊重します。本アプリの使用中に提供されるすべての情報は、当社のプライバシーポリシーに従って保護されます。ユーザーは、本アプリを通じてミラーリングされたコンテンツが他のデバイスまたはユーザーによって受信および表示される可能性があることを理解し、同意する必要があります。"
            },
            {
                "title": "サービスの中断または終了",
                "content": "当社は、本アプリのサービスを一時的または恒久的に中断または終了する権利を留保し、そのような中断または終了によりユーザーまたは第三者に生じた損害について責任を負いません。"
            },
            {
                "title": "サードパーティのリンク",
                "content": "本アプリには、サードパーティのウェブサイトまたはサービスへのリンクが含まれる場合があります。当社は、これらのサードパーティのウェブサイトまたはサービスのコンテンツ、プライバシーポリシー、または慣行について責任を負いません。ユーザーは、これらのリンクされたウェブサイトまたはサービスにアクセスし使用する際、自己の判断と責任で行います。"
            },
            {
                "title": "条件の変更",
                "content": "当社は、本免責事項をいつでも変更する権利を留保します。変更された条件は公開と同時に効力を生じます。本アプリの継続的な使用は、変更された条件の受諾を意味します。"
            },
            {
                "title": "完全な合意",
                "content": "本免責事項は、本アプリの使用に関するユーザーと当社との間の完全な合意を構成し、本アプリに関する書面または口頭による以前のすべての連絡、表明、または理解に取って代わります。"
            }
        ]
    },
    "ko": {
        "title": "면책 조항",
        "intro": "저희 스크린 미러링 애플리케이션(이하 '본 앱')에 오신 것을 환영합니다. 본 앱을 사용하기 전에 아래 면책 조항을 주의 깊게 읽어주시기 바랍니다. 본 앱의 사용은 아래 조건을 읽고, 이해하고, 동의한 것으로 간주됩니다.",
        "sections": [
            {
                "title": "책임 제한",
                "content": "본 앱은 한 기기에서 다른 기기로 콘텐츠를 미러링하는 기능을 제공합니다. 미러링된 콘텐츠의 정확성, 완전성, 신뢰성, 적합성 또는 가용성에 대해 명시적 또는 묵시적인 보증을 제공하지 않습니다. 사용자는 미러링하는 콘텐츠의 적법성과 규정 준수를 보장할 책임이 있으며, 이에 따른 모든 책임을 부담합니다."
            },
            {
                "title": "저작권 및 지적 재산권",
                "content": "본 앱을 통해 미러링되는 모든 콘텐츠(비디오, 오디오, 이미지, 텍스트 등을 포함하나 이에 국한되지 않음)는 합법적인 사용 권한 또는 필요한 승인을 받아 사용해야 합니다. 사용자는 본 앱을 사용하여 제3자의 저작권, 상표, 특허 또는 기타 지적 재산권을 침해해서는 안 됩니다. 위반 시 사용자는 모든 법적 책임을 부담합니다."
            },
            {
                "title": "개인정보 보호",
                "content": "저희는 사용자의 개인정보를 존중합니다. 본 앱 사용 중 제공되는 모든 정보는 저희 개인정보 처리방침에 따라 보호됩니다. 사용자는 본 앱을 통해 미러링된 콘텐츠가 다른 기기 또는 사용자에 의해 수신 및 열람될 수 있음을 이해하고 동의해야 합니다."
            },
            {
                "title": "서비스 중단 또는 종료",
                "content": "저희는 본 앱의 서비스를 일시적 또는 영구적으로 중단하거나 종료할 권리를 보유하며, 이러한 중단 또는 종료로 인해 사용자 또는 제3자에게 발생한 손해에 대해 책임을 지지 않습니다."
            },
            {
                "title": "제3자 링크",
                "content": "본 앱은 제3자 웹사이트 또는 서비스로의 링크를 포함할 수 있습니다. 저희는 이러한 제3자 웹사이트 또는 서비스의 콘텐츠, 개인정보 처리방침 또는 관행에 대해 책임을 지지 않습니다. 사용자는 이러한 링크된 웹사이트 또는 서비스에 접근하고 사용할 때 자신의 판단과 책임 하에 수행합니다."
            },
            {
                "title": "조건 수정",
                "content": "저희는 본 면책 조항을 언제든지 수정할 권리를 보유합니다. 수정된 조건은 게시 즉시 효력을 발생합니다. 본 앱의 지속적인 사용은 수정된 조건의 수락을 의미합니다."
            },
            {
                "title": "완전한 합의",
                "content": "본 면책 조항은 본 앱 사용과 관련하여 사용자와 저희 간의 완전한 합의를 구성하며, 본 앱과 관련된 서면 또는 구두의 이전 모든 통신, 진술 또는 이해를 대체합니다."
            }
        ]
    },
    "ru": {
        "title": "Отказ от ответственности",
        "intro": "Добро пожаловать в наше приложение для зеркалирования экрана (далее именуемое 'Приложение'). Перед использованием Приложения, пожалуйста, внимательно ознакомьтесь с данным отказом от ответственности. Любое использование Приложения означает, что вы прочитали, поняли и приняли следующие условия.",
        "sections": [
            {
                "title": "Ограничение ответственности",
                "content": "Приложение предоставляет функцию зеркалирования контента с одного устройства на другое. Мы не предоставляем никаких явных или подразумеваемых гарантий относительно точности, полноты, надежности, пригодности или доступности зеркалируемого контента. Пользователи несут ответственность за обеспечение законности и соответствия зеркалируемого контента и несут все связанные с этим обязанности."
            },
            {
                "title": "Авторские права и интеллектуальная собственность",
                "content": "Весь контент, зеркалируемый через Приложение, включая, но не ограничиваясь, видео, аудио, изображениями и текстами, должен использоваться с законными правами или необходимыми разрешениями. Пользователи не должны использовать Приложение для нарушения авторских прав, товарных знаков, патентов или других прав интеллектуальной собственности третьих лиц. Пользователи несут полную юридическую ответственность за любые нарушения."
            },
            {
                "title": "Защита конфиденциальности",
                "content": "Мы уважаем вашу конфиденциальность. Все данные, предоставленные при использовании Приложения, будут защищены в соответствии с нашей Политикой конфиденциальности. Пользователи должны понимать и соглашаться с тем, что зеркалируемый контент через Приложение может быть получен и просмотрен другими устройствами или пользователями."
            },
            {
                "title": "Прерывание или прекращение обслуживания",
                "content": "Мы оставляем за собой право приостановить или прекратить предоставление услуг Приложения в любое время, временно или навсегда, без ответственности за ущерб, причиненный пользователям или третьим лицам в результате такого прерывания или прекращения."
            },
            {
                "title": "Ссылки на сторонние ресурсы",
                "content": "Приложение может содержать ссылки на веб-сайты или услуги третьих лиц. Мы не несем ответственности за содержимое, политику конфиденциальности или практики этих сторонних сайтов или услуг. Пользователи заходят и используют эти связанные сайты или услуги на свой страх и риск."
            },
            {
                "title": "Изменение условий",
                "content": "Мы оставляем за собой право изменять этот Отказ от ответственности в любое время. Измененные условия вступают в силу сразу после публикации. Продолжение использования Приложения означает принятие измененных условий."
            },
            {
                "title": "Полное соглашение",
                "content": "Этот Отказ от ответственности составляет полное соглашение между вами и нами относительно использования Приложения и заменяет любые предыдущие коммуникации, представления или договоренности, письменные или устные, касающиеся Приложения."
            }
        ]
    },
    "zh-CN": {
        "title": "免责声明",
        "intro": "欢迎使用我们的投屏应用（以下简称“本应用”）。在您使用本应用之前，请仔细阅读以下免责声明。您对本应用的任何使用均视为您已阅读、理解并同意接受以下条款。",
        "sections": [
            {
                "title": "责任限制",
                "content": "本应用提供的功能是允许用户将内容从一个设备投屏到另一个设备。我们不对投屏内容的准确性、完整性、可靠性、适用性或可用性作任何明示或暗示的保证。用户使用本应用投屏的内容应确保其合法性、合规性，并自行承担由此产生的所有责任。"
            },
            {
                "title": "版权和知识产权",
                "content": "用户通过本应用投屏的所有内容，包括但不限于视频、音频、图片、文本等，应确保其拥有合法的使用权或已获得必要的授权。用户不得使用本应用侵犯任何第三方的版权、商标、专利或其他知识产权。如有违反，用户应自行承担全部法律责任。"
            },
            {
                "title": "隐私保护",
                "content": "我们尊重用户的隐私权。用户在使用本应用时提供的所有信息，我们将按照隐私政策进行保护。用户应理解并同意，在使用投屏服务时，所投屏的内容可能会被其他设备或用户所接收和查看。"
            },
            {
                "title": "服务中断或终止",
                "content": "我们保留随时中断或终止本应用服务的权利，不论是暂时的还是永久的，且不承担因服务中断或终止而对用户或任何第三方造成的任何损害赔偿责任。"
            },
            {
                "title": "第三方链接",
                "content": "本应用可能会提供指向第三方网站或服务的链接。我们不对这些第三方网站或服务的内容、隐私政策或实践负责。用户访问和使用这些链接提供的网站或服务，需自行判断并承担风险。"
            },
            {
                "title": "条款修改",
                "content": "我们保留随时修改本免责声明的权利。修改后的条款一旦公布，即刻生效。用户继续使用本应用即表示接受修改后的条款。"
            },
            {
                "title": "完整协议",
                "content": "本免责声明构成了您与我们之间关于本应用使用的完整协议，并取代了您与我们之间关于本应用的任何先前的沟通、声明或理解，无论是书面还是口头。"
            }
        ]
    },
    "zh-TW": {
        "title": "免責聲明",
        "intro": "歡迎使用我們的投屏應用（以下簡稱「本應用」）。在使用本應用前，請仔細閱讀以下免責聲明。您對本應用的任何使用均視為您已閱讀、理解並同意接受以下條款。",
        "sections": [
            {
                "title": "責任限制",
                "content": "本應用提供的功能是允許用戶將內容從一個設備投屏到另一個設備。我們對投屏內容的準確性、完整性、可靠性、適用性或可用性不作任何明示或暗示的保證。用戶使用本應用投屏的內容應確保其合法性、合規性，並自行承擔由此產生的所有責任。"
            },
            {
                "title": "版權與智慧財產權",
                "content": "用戶通過本應用投屏的所有內容，包括但不限於視頻、音頻、圖片、文字等，應確保其擁有合法的使用權或已獲得必要的授權。用戶不得使用本應用侵犯任何第三方的版權、商標、專利或其他智慧財產權。如有違反，用戶應自行承擔全部法律責任。"
            },
            {
                "title": "隱私保護",
                "content": "我們尊重用戶的隱私權。用戶在使用本應用時提供的所有資訊，我們將依據隱私政策進行保護。用戶應理解並同意，在使用投屏服務時，所投屏的內容可能會被其他設備或用戶接收及檢視。"
            },
            {
                "title": "服務中斷或終止",
                "content": "我們保留隨時中斷或終止本應用服務的權利，無論是暫時的還是永久的，且不承擔因服務中斷或終止而對用戶或任何第三方造成的任何損害賠償責任。"
            },
            {
                "title": "第三方連結",
                "content": "本應用可能提供指向第三方網站或服務的連結。我們對這些第三方網站或服務的內容、隱私政策或做法不承擔責任。用戶訪問及使用這些連結提供的網站或服務，需自行判斷並承擔風險。"
            },
            {
                "title": "條款修改",
                "content": "我們保留隨時修改本免責聲明的權利。修改後的條款一經公布，即刻生效。用戶繼續使用本應用即表示接受修改後的條款。"
            },
            {
                "title": "完整協議",
                "content": "本免責聲明構成了您與我們之間關於本應用使用的完整協議，並取代了您與我們之間關於本應用的任何先前溝通、聲明或理解，無論是書面還是口頭。"
            }
        ]
    }
};

function getLangFromUrl() {
    const params = new URLSearchParams(window.location.search);
    return params.get('lang') || 'en'; // 默认英语
}

function loadLanguage(lang) {
    try {
        const data = translations[lang] || translations['en'];
        const source = document.getElementById('disclaimer-template').innerHTML;
        const template = Handlebars.compile(source);
        document.getElementById('disclaimer-container').innerHTML = template(data);
        document.getElementById('page-title').textContent = data.title;
        document.documentElement.lang = lang;
    } catch (error) {
        console.error('Language rendering error:', error);
        loadLanguage('en');
    }
}

// 暴露给 Android 原生调用的函数
window.switchLanguage = function(lang) {
    loadLanguage(lang || 'en');
};

// 根据 URL 参数加载语言
const lang = getLangFromUrl();
loadLanguage(lang);