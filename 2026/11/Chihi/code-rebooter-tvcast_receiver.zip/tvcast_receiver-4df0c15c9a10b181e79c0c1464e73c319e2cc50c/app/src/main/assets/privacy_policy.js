 // 语言数据嵌入 HTML
    const translations = {
      "en": {
        "title": "Privacy Policy",
        "effective_date": "Effective Date of this Privacy Policy: March 24, 2025",
        "version": "Version of this Privacy Policy: 2025V1.0",
        "intro": "Welcome to our services. This Privacy Policy explains how we collect, use, store, and protect your personal information in accordance with the General Data Protection Regulation (GDPR) and applicable laws. By using our services, you agree to the terms of this policy. We are committed to processing your information in a transparent, lawful, and secure manner, using it only when necessary.",
        "sections": [
          {
            "title": "Personal Information We Collect",
            "content": "To provide and optimize our services, we may collect the following personal information: 1) Information you voluntarily provide, such as username, email address, or contact details during registration; 2) Automatically collected information, including device information (e.g., device model, IP address, operating system version) and usage data (e.g., access time, page interaction records); 3) Information obtained through authorized third-party services, such as social media account data.",
            "subcontent": "We adhere to the principle of data minimization, collecting only the information necessary for service purposes. All data processing is based on legal grounds defined by GDPR, including contract performance, legitimate interests, your consent, or legal obligations."
          },
          {
            "title": "Purposes of Information Use",
            "content": "We use your personal information to: 1) provide and maintain service functionality; 2) improve user experience and performance; 3) provide customer support; 4) analyze service usage; 5) ensure service security and prevent fraud or abuse.",
            "subcontent": "If we need to use your information for other purposes (e.g., marketing), we will obtain your explicit consent in advance. You may withdraw consent at any time, without affecting the lawfulness of processing prior to withdrawal."
          },
          {
            "title": "Cookies and Similar Technologies",
            "content": "We use cookies, pixel tags, and similar technologies to collect anonymous data to optimize services, analyze traffic, and provide personalized content. Cookies are small files stored on your device, typically containing unique identifiers.",
            "list": [
              "Necessary Cookies: Support core service functions, such as user login;",
              "Analytics Cookies: Help us understand user behavior and improve the service;",
              "Functional Cookies: Enable personalized features, such as saving preference settings."
            ],
            "subcontent": "You can accept or reject cookies through your browser settings. Rejecting non-essential cookies may affect some service functions. See our Cookies Policy for more details."
          },
          {
            "title": "Third-Party Services",
            "content": "We may engage third-party service providers to process data to support service operations. These providers include:",
            "list": [
              "Google Play Services (for app distribution)",
              "Google Analytics (for data analysis)",
              "Firebase Analytics (for performance monitoring)",
              "Crashlytics (for error log collection)"
            ],
            "subcontent": "Third parties process data only under our instructions and are bound by Data Processing Agreements (DPAs) compliant with GDPR requirements, prohibiting use of your information for other purposes."
          },
          {
            "title": "Data Sharing and International Transfers",
            "content": "We do not sell your personal information or share it with third parties without your consent, except: 1) when necessary to provide the service; 2) to comply with legal obligations; 3) to protect our legitimate interests (e.g., fraud prevention).",
            "subcontent": "If data is transferred outside the EU, we ensure its protection through Standard Contractual Clauses (SCCs) or other GDPR-recognized mechanisms, such as when using servers in the United States."
          },
          {
            "title": "Your Rights",
            "content": "Under GDPR, you have the following rights: 1) access your personal information; 2) correct inaccurate data; 3) delete personal information (‘right to be forgotten’); 4) restrict or object to processing; 5) data portability; 6) withdraw consent.",
            "subcontent": "To exercise these rights, contact us via the channels below. We will respond within 30 days (extendable to 90 days in special cases). If dissatisfied with our processing, you may lodge a complaint with your country’s data protection authority."
          },
          {
            "title": "Data Security",
            "content": "We implement industry-standard security measures (e.g., encryption, access controls) to protect your personal information from unauthorized access or disclosure. In case of a data breach, we will notify supervisory authorities and affected users within 72 hours, as required by GDPR.",
            "subcontent": "Despite reasonable measures, no internet transmission or storage is 100% secure, and we cannot guarantee absolute security."
          },
          {
            "title": "Children’s Privacy",
            "content": "Our services are not directed to children under 16. We do not knowingly collect personal information from children under this age. If such data is discovered, we will delete it immediately. If you are a parent or guardian and believe your child has provided personal information, please contact us."
          },
          {
            "title": "Third-Party Website Links",
            "content": "Our services may contain links to third-party websites. We are not responsible for their privacy practices or content. Please review their privacy policies to understand how your data is processed."
          },
          {
            "title": "Policy Updates",
            "content": "We may update this Privacy Policy from time to time. The updated version will be posted on this page with a new effective date. Significant changes will be communicated via in-service notifications or email. We recommend reviewing this policy regularly.",
            "subcontent": "Continued use of the service implies acceptance of the updated policy."
          },
          {
            "title": "Contact Us",
            "content": "If you have questions about this Privacy Policy or data processing, or wish to exercise your rights, please submit your request through the ‘Contact Us’ function within the service or via the help center. We will respond promptly and comply with GDPR’s transparency and accountability requirements."
          }
        ]
      },
      "ar": {
        "title": "اتفاقية الخصوصية",
        "effective_date": "تاريخ سريان اتفاقية الخصوصية: 24 مارس 2025",
        "version": "إصدار اتفاقية الخصوصية: 2025V1.0",
        "intro": "مرحبًا بكم في استخدام خدماتنا. توضح اتفاقية الخصوصية هذه كيفية جمعنا واستخدامنا وتخزيننا وحماية معلوماتكم الشخصية وفقًا للائحة العامة لحماية البيانات (GDPR) والقوانين ذات الصلة. باستخدامكم لخدماتنا، فإنكم توافقون على شروط هذه الاتفاقية. نحن ملتزمون بمعالجة معلوماتكم بطريقة شفافة وقانونية وآمنة، واستخدامها فقط عند الضرورة.",
        "sections": [
          {
            "title": "المعلومات الشخصية التي نجمعها",
            "content": "لتوفير خدماتنا وتحسينها، قد نجمع المعلومات الشخصية التالية: 1) المعلومات التي تقدمونها طوعًا، مثل اسم المستخدم أو البريد الإلكتروني أو تفاصيل الاتصال عند التسجيل؛ 2) المعلومات التي يتم جمعها تلقائيًا، بما في ذلك معلومات الجهاز (مثل طراز الجهاز، عنوان IP، إصدار نظام التشغيل) وبيانات الاستخدام (مثل وقت الزيارة، سجل التفاعل مع الصفحات)؛ 3) المعلومات التي يتم الحصول عليها من خلال خدمات الطرف الثالث المصرح بها، مثل بيانات حسابات التواصل الاجتماعي.",
            "subcontent": "نلتزم بمبدأ تقليل البيانات، ونجمع فقط المعلومات الضرورية لتحقيق أغراض الخدمة. تتم معالجة جميع البيانات بناءً على الأسس القانونية المنصوص عليها في اللائحة العامة لحماية البيانات، بما في ذلك تنفيذ العقد، المصالح المشروعة، موافقتكم، أو الالتزامات القانونية."
          },
          {
            "title": "أغراض استخدام المعلومات",
            "content": "نستخدم معلوماتكم الشخصية لأغراض: 1) توفير وظائف الخدمة وصيانتها؛ 2) تحسين تجربة المستخدم والأداء؛ 3) تقديم الدعم للعملاء؛ 4) تحليل استخدام الخدمة؛ 5) ضمان أمان الخدمة ومنع الاحتيال أو إساءة الاستخدام.",
            "subcontent": "إذا لزم استخدام معلوماتكم لأغراض أخرى (مثل التسويق)، سنحصل على موافقتكم الصريحة مسبقًا. يمكنكم سحب الموافقة في أي وقت، دون التأثير على قانونية المعالجة قبل السحب."
          },
          {
            "title": "ملفات تعريف الارتباط والتقنيات المشابهة",
            "content": "نستخدم ملفات تعريف الارتباط (Cookies) والتقنيات المشابهة، مثل علامات البكسل، لجمع بيانات مجهولة المصدر لتحسين الخدمات، تحليل الحركة، وتوفير محتوى مخصص. ملفات تعريف الارتباط هي ملفات صغيرة تُخزن على جهازكم وتحتوي عادةً على معرفات فريدة.",
            "list": [
              "ملفات تعريف الارتباط الضرورية: تدعم الوظائف الأساسية للخدمة، مثل تسجيل الدخول؛",
              "ملفات تعريف الارتباط التحليلية: تساعدنا على فهم سلوك المستخدم وتحسين الخدمة؛",
              "ملفات تعريف الارتباط الوظيفية: تمكّن الوظائف المخصصة، مثل حفظ إعدادات التفضيل."
            ],
            "subcontent": "يمكنكم قبول أو رفض ملفات تعريف الارتباط من خلال إعدادات المتصفح. رفض ملفات تعريف الارتباط غير الضرورية قد يؤثر على بعض وظائف الخدمة. لمزيد من التفاصيل، راجعوا سياسة ملفات تعريف الارتباط الخاصة بنا."
          },
          {
            "title": "خدمات الطرف الثالث",
            "content": "قد نكلف مزودي خدمات من الطرف الثالث بمعالجة البيانات لدعم تشغيل الخدمة. تشمل هذه الخدمات:",
            "list": [
              "خدمات Google Play (لتوزيع التطبيقات)",
              "Google Analytics (لتحليل البيانات)",
              "Firebase Analytics (لمراقبة الأداء)",
              "Crashlytics (لتجميع سجلات الأخطاء)"
            ],
            "subcontent": "يعالج الطرف الثالث البيانات فقط بناءً على تعليماتنا، وهو ملزم باتفاقيات معالجة البيانات (DPA) وفقًا لمتطلبات GDPR، ولا يجوز له استخدام معلوماتكم لأغراض أخرى."
          },
          {
            "title": "مشاركة البيانات والنقل عبر الحدود",
            "content": "لن نبيع معلوماتكم الشخصية أو نشاركها مع أطراف ثالثة دون موافقتكم، إلا في الحالات التالية: 1) عند الضرورة لتوفير الخدمة؛ 2) للامتثال للالتزامات القانونية؛ 3) لحماية مصالحنا المشروعة (مثل منع الاحتيال).",
            "subcontent": "في حالة نقل البيانات إلى خارج الاتحاد الأوروبي، سنضمن حماية البيانات من خلال الشروط التعاقدية القياسية (SCC) أو آليات أخرى معتمدة بموجب GDPR، مثل عند استخدام خوادم في الولايات المتحدة."
          },
          {
            "title": "حقوقكم",
            "content": "بموجب GDPR، لكم الحق في: 1) الوصول إلى معلوماتكم الشخصية؛ 2) تصحيح البيانات غير الدقيقة؛ 3) حذف المعلومات الشخصية (‘الحق في النسيان’)؛ 4) تقييد المعالجة أو الاعتراض عليها؛ 5) نقل البيانات؛ 6) سحب الموافقة.",
            "subcontent": "للاستفادة من هذه الحقوق، يرجى التواصل معنا عبر قنوات الاتصال الموضحة أدناه. سنرد خلال 30 يومًا (قابلة للتمديد إلى 90 يومًا في حالات خاصة). إذا كنتم غير راضين عن معالجتنا، يمكنكم تقديم شكوى إلى هيئة حماية البيانات في بلدكم."
          },
          {
            "title": "أمان البيانات",
            "content": "نستخدم تدابير أمان قياسية في الصناعة (مثل التشفير ومراقبة الوصول) لحماية معلوماتكم الشخصية من الوصول غير المصرح به أو التسريب. في حالة حدوث خرق للبيانات، سنخطر الجهات التنظيمية والمستخدمين المتضررين خلال 72 ساعة وفقًا لمتطلبات GDPR.",
            "subcontent": "على الرغم من اتخاذنا تدابير معقولة، لا يمكن ضمان أمان أي نقل أو تخزين عبر الإنترنت بنسبة 100%."
          },
          {
            "title": "خصوصية الأطفال",
            "content": "خدماتنا ليست موجهة للأطفال دون سن 16 عامًا. لن نجمع عن قصد معلومات شخصية من الأطفال دون هذا العمر. إذا اكتشفنا وجود مثل هذه البيانات، سنقوم بحذفها فورًا. إذا كنتم والدين أو أوصياء وتعتقدون أن طفلكم قدم معلومات شخصية، يرجى التواصل معنا."
          },
          {
            "title": "روابط مواقع الطرف الثالث",
            "content": "قد تحتوي خدماتنا على روابط لمواقع طرف ثالث. نحن لسنا مسؤولين عن ممارسات الخصوصية أو المحتوى لهذه المواقع. يرجى مراجعة سياسات الخصوصية الخاصة بها لفهم كيفية معالجة بياناتكم."
          },
          {
            "title": "تحديثات الاتفاقية",
            "content": "قد نحدّث اتفاقية الخصوصية هذه من وقت لآخر. سيتم نشر النسخة المحدثة على هذه الصفحة مع تاريخ سريان جديد. سنخطركم بالتغييرات الجوهرية عبر إشعارات داخل الخدمة أو البريد الإلكتروني. نوصي بمراجعة هذه الاتفاقية بانتظام.",
            "subcontent": "استمراركم في استخدام الخدمة يعني قبولكم للاتفاقية المحدثة."
          },
          {
            "title": "اتصلوا بنا",
            "content": "إذا كانت لديكم أي أسئلة حول اتفاقية الخصوصية هذه أو معالجة البيانات، أو رغبتم في ممارسة حقوقكم، يرجى تقديم طلبكم عبر وظيفة 'الاتصال بنا' داخل الخدمة أو مركز المساعدة. سنرد بسرعة ونلتزم بمتطلبات الشفافية والمسؤولية بموجب GDPR."
          }
        ]
      },
      "de": {
        "title": "Datenschutzrichtlinie",
        "effective_date": "Datum des Inkrafttretens dieser Datenschutzrichtlinie: 24. März 2025",
        "version": "Version der Datenschutzrichtlinie: 2025V1.0",
        "intro": "Willkommen bei der Nutzung unserer Dienste. Diese Datenschutzrichtlinie erläutert, wie wir Ihre personenbezogenen Daten gemäß der Datenschutz-Grundverordnung (DSGVO) und den geltenden Gesetzen erheben, verwenden, speichern und schützen. Durch die Nutzung unserer Dienste stimmen Sie den Bedingungen dieser Richtlinie zu. Wir verpflichten uns, Ihre Daten transparent, rechtmäßig und sicher zu verarbeiten und sie nur bei Bedarf zu verwenden.",
        "sections": [
          {
            "title": "Von uns erhobene personenbezogene Daten",
            "content": "Um unsere Dienste bereitzustellen und zu optimieren, erheben wir möglicherweise die folgenden personenbezogenen Daten: 1) Von Ihnen freiwillig bereitgestellte Informationen, wie Benutzername, E-Mail-Adresse oder Kontaktdaten bei der Registrierung; 2) Automatisch erhobene Informationen, einschließlich Geräteinformationen (z. B. Gerätemodell, IP-Adresse, Betriebssystemversion) und Nutzungsdaten (z. B. Zugriffszeit, Interaktionsprotokolle); 3) Informationen, die über von Ihnen autorisierte Drittdienste erhalten werden, wie z. B. Daten von Social-Media-Konten.",
            "subcontent": "Wir halten uns an das Prinzip der Datenminimierung und erheben nur die für die Erfüllung der Dienstzwecke erforderlichen Informationen. Jegliche Datenverarbeitung basiert auf den in der DSGVO festgelegten Rechtsgrundlagen, einschließlich Vertragserfüllung, berechtigten Interessen, Ihrer Einwilligung oder gesetzlichen Verpflichtungen."
          },
          {
            "title": "Zwecke der Datenverwendung",
            "content": "Wir verwenden Ihre personenbezogenen Daten, um: 1) Dienstfunktionen bereitzustellen und zu warten; 2) die Benutzererfahrung und Leistung zu verbessern; 3) Kundensupport anzubieten; 4) die Nutzung der Dienste zu analysieren; 5) die Sicherheit der Dienste zu gewährleisten und Betrug oder Missbrauch zu verhindern.",
            "subcontent": "Falls Ihre Daten für andere Zwecke (z. B. Marketing) verwendet werden sollen, holen wir Ihre ausdrückliche Einwilligung ein. Sie können Ihre Einwilligung jederzeit widerrufen, ohne dass die Rechtmäßigkeit der vorherigen Verarbeitung beeinträchtigt wird."
          },
          {
            "title": "Cookies und ähnliche Technologien",
            "content": "Wir verwenden Cookies, Pixel-Tags und ähnliche Technologien, um anonyme Daten zu sammeln, die unsere Dienste optimieren, den Datenverkehr analysieren und personalisierte Inhalte bereitstellen. Cookies sind kleine Dateien, die auf Ihrem Gerät gespeichert werden und in der Regel eindeutige Identifikatoren enthalten.",
            "list": [
              "Notwendige Cookies: Unterstützen Kernfunktionen des Dienstes, wie z. B. die Anmeldung;",
              "Analyse-Cookies: Helfen uns, das Nutzerverhalten zu verstehen und den Dienst zu verbessern;",
              "Funktionale Cookies: Ermöglichen personalisierte Funktionen, wie das Speichern von Präferenzeinstellungen."
            ],
            "subcontent": "Sie können Cookies über die Browsereinstellungen akzeptieren oder ablehnen. Das Ablehnen nicht notwendiger Cookies kann einige Dienstfunktionen beeinträchtigen. Weitere Details finden Sie in unserer Cookie-Richtlinie."
          },
          {
            "title": "Drittdienste",
            "content": "Wir können Drittdienstleister beauftragen, Daten zu verarbeiten, um den Betrieb unserer Dienste zu unterstützen. Zu diesen Anbietern gehören:",
            "list": [
              "Google Play-Dienste (für App-Verteilung)",
              "Google Analytics (für Datenanalyse)",
              "Firebase Analytics (für Leistungsüberwachung)",
              "Crashlytics (für Fehlerprotokollierung)"
            ],
            "subcontent": "Dritte verarbeiten Daten nur nach unseren Anweisungen und sind durch Datenverarbeitungsvereinbarungen (DPA) an die DSGVO-Anforderungen gebunden. Sie dürfen Ihre Daten nicht für andere Zwecke verwenden."
          },
          {
            "title": "Datenweitergabe und grenzüberschreitende Übermittlung",
            "content": "Wir verkaufen Ihre personenbezogenen Daten nicht und geben sie ohne Ihre Zustimmung nicht an Dritte weiter, außer: 1) wenn es für die Bereitstellung des Dienstes erforderlich ist; 2) zur Erfüllung gesetzlicher Verpflichtungen; 3) zum Schutz unserer berechtigten Interessen (z. B. zur Betrugsprävention).",
            "subcontent": "Bei einer Datenübermittlung außerhalb der EU stellen wir den Datenschutz durch Standardvertragsklauseln (SCC) oder andere von der DSGVO anerkannte Mechanismen sicher, z. B. bei der Nutzung von Servern in den USA."
          },
          {
            "title": "Ihre Rechte",
            "content": "Nach der DSGVO haben Sie folgende Rechte: 1) Zugang zu Ihren personenbezogenen Daten; 2) Berichtigung unrichtiger Daten; 3) Löschung Ihrer Daten (‘Recht auf Vergessenwerden’); 4) Einschränkung oder Widerspruch gegen die Verarbeitung; 5) Datenportabilität; 6) Widerruf der Einwilligung.",
            "subcontent": "Um diese Rechte auszuüben, kontaktieren Sie uns über die unten angegebenen Kanäle. Wir werden innerhalb von 30 Tagen (in besonderen Fällen bis zu 90 Tagen) antworten. Wenn Sie mit unserer Verarbeitung unzufrieden sind, können Sie sich bei der Datenschutzbehörde Ihres Landes beschweren."
          },
          {
            "title": "Datensicherheit",
            "content": "Wir setzen branchenübliche Sicherheitsmaßnahmen (wie Verschlüsselung und Zugriffskontrollen) ein, um Ihre personenbezogenen Daten vor unbefugtem Zugriff oder Offenlegung zu schützen. Im Falle einer Datenpanne benachrichtigen wir die Aufsichtsbehörden und betroffenen Nutzer innerhalb von 72 Stunden gemäß der DSGVO.",
            "subcontent": "Trotz angemessener Maßnahmen kann keine Datenübertragung oder -speicherung über das Internet zu 100 % sicher sein."
          },
          {
            "title": "Datenschutz für Kinder",
            "content": "Unsere Dienste richten sich nicht an Kinder unter 16 Jahren. Wir sammeln wissentlich keine personenbezogenen Daten von Kindern unter diesem Alter. Falls solche Daten entdeckt werden, löschen wir sie umgehend. Wenn Sie ein Elternteil oder Erziehungsberechtigter sind und glauben, dass Ihr Kind uns personenbezogene Daten bereitgestellt hat, kontaktieren Sie uns bitte."
          },
          {
            "title": "Links zu Websites Dritter",
            "content": "Unsere Dienste können Links zu Websites Dritter enthalten. Wir sind nicht verantwortlich für die Datenschutzpraktiken oder Inhalte dieser Websites. Bitte überprüfen Sie deren Datenschutzrichtlinien, um zu verstehen, wie Ihre Daten verarbeitet werden."
          },
          {
            "title": "Änderungen der Datenschutzrichtlinie",
            "content": "Wir können diese Datenschutzrichtlinie von Zeit zu Zeit aktualisieren. Die aktualisierte Version wird auf dieser Seite veröffentlicht, mit einem neuen Inkrafttretensdatum. Wesentliche Änderungen werden Sie über In-Dienst-Benachrichtigungen oder E-Mail informieren. Wir empfehlen, diese Richtlinie regelmäßig zu überprüfen.",
            "subcontent": "Die fortgesetzte Nutzung des Dienstes bedeutet Ihre Zustimmung zur aktualisierten Richtlinie."
          },
          {
            "title": "Kontaktieren Sie uns",
            "content": "Bei Fragen zu dieser Datenschutzrichtlinie oder zur Datenverarbeitung oder wenn Sie Ihre Rechte ausüben möchten, reichen Sie Ihre Anfrage über die Funktion ‚Kontaktieren Sie uns‘ im Dienst oder über das Hilfe-Center ein. Wir werden schnell reagieren und die Anforderungen an Transparenz und Rechenschaftspflicht gemäß der DSGVO einhalten."
          }
        ]
      },
      "es": {
        "title": "Política de Privacidad",
        "effective_date": "Fecha de entrada en vigor de esta Política de Privacidad: 24 de marzo de 2025",
        "version": "Versión de la Política de Privacidad: 2025V1.0",
        "intro": "Bienvenido a nuestros servicios. Esta Política de Privacidad explica cómo recopilamos, usamos, almacenamos y protegemos su información personal de acuerdo con el Reglamento General de Protección de Datos (RGPD) y las leyes aplicables. Al utilizar nuestros servicios, usted acepta los términos de esta política. Nos comprometemos a procesar su información de manera transparente, legal y segura, utilizándola solo cuando sea necesario.",
        "sections": [
          {
            "title": "Información personal que recopilamos",
            "content": "Para proporcionar y optimizar nuestros servicios, podemos recopilar la siguiente información personal: 1) Información que usted proporciona voluntariamente, como nombre de usuario, correo electrónico o datos de contacto al registrarse; 2) Información recopilada automáticamente, incluyendo datos del dispositivo (como modelo del dispositivo, dirección IP, versión del sistema operativo) y datos de uso (como hora de acceso, registros de interacción con páginas); 3) Información obtenida a través de servicios de terceros autorizados, como datos de cuentas de redes sociales.",
            "subcontent": "Seguimos el principio de minimización de datos, recopilando solo la información necesaria para los fines del servicio. Todo procesamiento de datos se basa en las bases legales establecidas por el RGPD, incluyendo la ejecución de contratos, intereses legítimos, su consentimiento o obligaciones legales."
          },
          {
            "title": "Finalidades del uso de la información",
            "content": "Usamos su información personal para: 1) proporcionar y mantener las funciones del servicio; 2) mejorar la experiencia y el rendimiento del usuario; 3) ofrecer soporte al cliente; 4) analizar el uso del servicio; 5) garantizar la seguridad del servicio y prevenir fraudes o abusos.",
            "subcontent": "Si necesitamos usar su información para otros fines (como marketing), obtendremos su consentimiento explícito previamente. Puede retirar su consentimiento en cualquier momento, sin afectar la legalidad del procesamiento previo al retiro."
          },
          {
            "title": "Cookies y tecnologías similares",
            "content": "Utilizamos cookies, etiquetas de píxeles y tecnologías similares para recopilar datos anónimos que optimizan nuestros servicios, analizan el tráfico y proporcionan contenido personalizado. Las cookies son pequeños archivos almacenados en su dispositivo que suelen contener identificadores únicos.",
            "list": [
              "Cookies necesarias: soportan funciones esenciales del servicio, como el inicio de sesión;",
              "Cookies analíticas: nos ayudan a entender el comportamiento del usuario y mejorar el servicio;",
              "Cookies funcionales: permiten funciones personalizadas, como guardar preferencias."
            ],
            "subcontent": "Puede aceptar o rechazar las cookies a través de la configuración de su navegador. Rechazar cookies no esenciales puede afectar algunas funciones del servicio. Consulte nuestra política de cookies para más detalles."
          },
          {
            "title": "Servicios de terceros",
            "content": "Podemos encargar a proveedores de servicios de terceros que procesen datos para apoyar el funcionamiento de nuestros servicios. Estos proveedores incluyen:",
            "list": [
              "Servicios de Google Play (para distribución de aplicaciones)",
              "Google Analytics (para análisis de datos)",
              "Firebase Analytics (para monitoreo de rendimiento)",
              "Crashlytics (para recolección de registros de errores)"
            ],
            "subcontent": "Los terceros procesan datos solo bajo nuestras instrucciones y están sujetos a acuerdos de procesamiento de datos (DPA) conforme a los requisitos del RGPD, no pudiendo usar su información para otros fines."
          },
          {
            "title": "Compartición de datos y transferencias internacionales",
            "content": "No vendemos su información personal ni la compartimos con terceros sin su consentimiento, salvo: 1) cuando sea necesario para proporcionar el servicio; 2) para cumplir con obligaciones legales; 3) para proteger nuestros intereses legítimos (como prevenir fraudes).",
            "subcontent": "Si los datos se transfieren fuera de la UE, garantizaremos su protección mediante cláusulas contractuales estándar (SCC) u otros mecanismos reconocidos por el RGPD, como al usar servidores en los EE. UU."
          },
          {
            "title": "Sus derechos",
            "content": "Según el RGPD, usted tiene los siguientes derechos: 1) acceder a su información personal; 2) corregir datos inexactos; 3) eliminar su información personal (‘derecho al olvido’); 4) restringir u oponerse al procesamiento; 5) portabilidad de datos; 6) retirar el consentimiento.",
            "subcontent": "Para ejercer estos derechos, contáctenos a través de los canales indicados a continuación. Responderemos en un plazo de 30 días (extensible a 90 días en casos especiales). Si no está satisfecho con nuestro procesamiento, puede presentar una queja ante la autoridad de protección de datos de su país."
          },
          {
            "title": "Seguridad de los datos",
            "content": "Adoptamos medidas de seguridad estándar de la industria (como cifrado y controles de acceso) para proteger su información personal contra accesos no autorizados o divulgaciones. En caso de una brecha de datos, notificaremos a las autoridades supervisoras y a los usuarios afectados dentro de las 72 horas, según lo requiere el RGPD.",
            "subcontent": "A pesar de tomar medidas razonables, ninguna transmisión o almacenamiento de datos en internet es 100% seguro."
          },
          {
            "title": "Privacidad de los menores",
            "content": "Nuestros servicios no están dirigidos a menores de 16 años. No recopilamos intencionadamente información personal de menores de esta edad. Si descubrimos dichos datos, los eliminaremos de inmediato. Si es padre o tutor y cree que su hijo nos ha proporcionado información personal, contáctenos."
          },
          {
            "title": "Enlaces a sitios web de terceros",
            "content": "Nuestros servicios pueden contener enlaces a sitios web de terceros. No somos responsables de las prácticas de privacidad o el contenido de estos sitios. Revise sus políticas de privacidad para entender cómo procesan sus datos."
          },
          {
            "title": "Actualizaciones de la política",
            "content": "Podemos actualizar esta Política de Privacidad de vez en cuando. La versión actualizada se publicará en esta página con una nueva fecha de entrada en vigor. Las modificaciones sustanciales se notificarán mediante notificaciones dentro del servicio o por correo electrónico. Recomendamos revisar esta política regularmente.",
            "subcontent": "El uso continuado del servicio implica la aceptación de la política actualizada."
          },
          {
            "title": "Contáctenos",
            "content": "Si tiene alguna pregunta sobre esta Política de Privacidad o el procesamiento de datos, o desea ejercer sus derechos, envíe su solicitud a través de la función ‘Contáctenos’ en el servicio o el centro de ayuda. Responderemos rápidamente y cumpliremos con los requisitos de transparencia y responsabilidad del RGPD."
          }
        ]
      },
      "fr": {
        "title": "Politique de Confidentialité",
        "effective_date": "Date d'entrée en vigueur de cette politique de confidentialité : 24 mars 2025",
        "version": "Version de la politique de confidentialité : 2025V1.0",
        "intro": "Bienvenue sur nos services. Cette politique de confidentialité explique comment nous collectons, utilisons, stockons et protégeons vos informations personnelles conformément au Règlement Général sur la Protection des Données (RGPD) et aux lois applicables. En utilisant nos services, vous acceptez les termes de cette politique. Nous nous engageons à traiter vos informations de manière transparente, légale et sécurisée, en les utilisant uniquement lorsque cela est nécessaire.",
        "sections": [
          {
            "title": "Informations personnelles collectées",
            "content": "Pour fournir et optimiser nos services, nous pouvons collecter les informations personnelles suivantes : 1) Informations que vous fournissez volontairement, telles que nom d'utilisateur, adresse e-mail ou coordonnées lors de l'inscription ; 2) Informations collectées automatiquement, y compris les informations sur l'appareil (comme le modèle de l'appareil, l'adresse IP, la version du système d'exploitation) et les données d'utilisation (comme l'heure d'accès, les journaux d'interaction avec les pages) ; 3) Informations obtenues via des services tiers autorisés, comme les données de comptes de réseaux sociaux.",
            "subcontent": "Nous respectons le principe de minimisation des données, en ne collectant que les informations nécessaires aux finalités du service. Tout traitement des données repose sur les bases légales définies par le RGPD, y compris l'exécution de contrats, les intérêts légitimes, votre consentement ou les obligations légales."
          },
          {
            "title": "Finalités de l'utilisation des informations",
            "content": "Nous utilisons vos informations personnelles pour : 1) fournir et maintenir les fonctionnalités du service ; 2) améliorer l'expérience utilisateur et les performances ; 3) offrir un support client ; 4) analyser l'utilisation du service ; 5) garantir la sécurité du service et prévenir les fraudes ou abus.",
            "subcontent": "Si nous devons utiliser vos informations à d'autres fins (comme le marketing), nous obtiendrons votre consentement explicite préalable. Vous pouvez retirer votre consentement à tout moment, sans affecter la légalité du traitement effectué avant le retrait."
          },
          {
            "title": "Cookies et technologies similaires",
            "content": "Nous utilisons des cookies, des balises de pixels et des technologies similaires pour collecter des données anonymes afin d'optimiser nos services, analyser le trafic et fournir un contenu personnalisé. Les cookies sont de petits fichiers stockés sur votre appareil, contenant généralement des identifiants uniques.",
            "list": [
              "Cookies nécessaires : soutiennent les fonctions essentielles du service, comme la connexion ;",
              "Cookies analytiques : nous aident à comprendre le comportement des utilisateurs et à améliorer le service ;",
              "Cookies fonctionnels : permettent des fonctionnalités personnalisées, comme la sauvegarde des préférences."
            ],
            "subcontent": "Vous pouvez accepter ou refuser les cookies via les paramètres de votre navigateur. Refuser les cookies non essentiels peut affecter certaines fonctionnalités du service. Consultez notre politique de cookies pour plus de détails."
          },
          {
            "title": "Services tiers",
            "content": "Nous pouvons confier le traitement des données à des fournisseurs de services tiers pour soutenir le fonctionnement de nos services. Ces fournisseurs incluent :",
            "list": [
              "Services Google Play (pour la distribution d'applications)",
              "Google Analytics (pour l'analyse de données)",
              "Firebase Analytics (pour la surveillance des performances)",
              "Crashlytics (pour la collecte des journaux d'erreurs)"
            ],
            "subcontent": "Les tiers traitent les données uniquement selon nos instructions et sont soumis à des accords de traitement de données (DPA) conformes aux exigences du RGPD, ne pouvant utiliser vos informations à d'autres fins."
          },
          {
            "title": "Partage des données et transferts internationaux",
            "content": "Nous ne vendons pas vos informations personnelles ni ne les partageons avec des tiers sans votre consentement, sauf : 1) lorsque cela est nécessaire pour fournir le service ; 2) pour respecter des obligations légales ; 3) pour protéger nos intérêts légitimes (comme prévenir les fraudes).",
            "subcontent": "En cas de transfert de données en dehors de l'UE, nous garantissons leur protection par des clauses contractuelles types (CCT) ou d'autres mécanismes reconnus par le RGPD, par exemple lors de l'utilisation de serveurs aux États-Unis."
          },
          {
            "title": "Vos droits",
            "content": "Conformément au RGPD, vous disposez des droits suivants : 1) accéder à vos informations personnelles ; 2) corriger les données inexactes ; 3) supprimer vos informations personnelles (‘droit à l’oubli’) ; 4) restreindre ou vous opposer au traitement ; 5) portabilité des données ; 6) retirer votre consentement.",
            "subcontent": "Pour exercer ces droits, contactez-nous via les canaux indiqués ci-dessous. Nous répondrons dans un délai de 30 jours (extensible à 90 jours dans des cas particuliers). Si vous n'êtes pas satisfait de notre traitement, vous pouvez déposer une plainte auprès de l'autorité de protection des données de votre pays."
          },
          {
            "title": "Sécurité des données",
            "content": "Nous adoptons des mesures de sécurité conformes aux normes de l'industrie (comme le chiffrement et les contrôles d'accès) pour protéger vos informations personnelles contre tout accès ou divulgation non autorisés. En cas de violation de données, nous informerons les autorités de contrôle et les utilisateurs concernés dans les 72 heures, conformément au RGPD.",
            "subcontent": "Malgré des mesures raisonnables, aucune transmission ou stockage de données sur Internet n'est sécurisé à 100 %."
          },
          {
            "title": "Confidentialité des mineurs",
            "content": "Nos services ne s'adressent pas aux mineurs de moins de 16 ans. Nous ne collectons pas sciemment d'informations personnelles de mineurs de cet âge. Si de telles données sont découvertes, nous les supprimerons immédiatement. Si vous êtes parent ou tuteur et pensez que votre enfant nous a fourni des informations personnelles, contactez-nous."
          },
          {
            "title": "Liens vers des sites tiers",
            "content": "Nos services peuvent contenir des liens vers des sites tiers. Nous ne sommes pas responsables des pratiques de confidentialité ou du contenu de ces sites. Veuillez consulter leurs politiques de confidentialité pour comprendre comment vos données sont traitées."
          },
          {
            "title": "Mises à jour de la politique",
            "content": "Nous pouvons mettre à jour cette politique de confidentialité de temps à autre. La version mise à jour sera publiée sur cette page avec une nouvelle date d'entrée en vigueur. Les modifications substantielles vous seront notifiées via des notifications dans le service ou par e-mail. Nous vous recommandons de consulter régulièrement cette politique.",
            "subcontent": "L'utilisation continue du service implique votre acceptation de la politique mise à jour."
          },
          {
            "title": "Contactez-nous",
            "content": "Si vous avez des questions concernant cette politique de confidentialité ou le traitement des données, ou si vous souhaitez exercer vos droits, veuillez soumettre votre demande via la fonction ‘Contactez-nous’ dans le service ou le centre d'aide. Nous répondrons rapidement et respecterons les exigences de transparence et de responsabilité du RGPD."
          }
        ]
      },
      "it": {
        "title": "Informativa sulla Privacy",
        "effective_date": "Data di entrata in vigore di questa Informativa sulla Privacy: 24 marzo 2025",
        "version": "Versione dell'Informativa sulla Privacy: 2025V1.0",
        "intro": "Benvenuto nei nostri servizi. Questa Informativa sulla Privacy spiega come raccogliamo, utilizziamo, conserviamo e proteggiamo le tue informazioni personali in conformità al Regolamento Generale sulla Protezione dei Dati (GDPR) e alle leggi applicabili. Utilizzando i nostri servizi, accetti i termini di questa informativa. Ci impegniamo a trattare le tue informazioni in modo trasparente, legale e sicuro, utilizzandole solo quando necessario.",
        "sections": [
          {
            "title": "Informazioni personali raccolte",
            "content": "Per fornire e ottimizzare i nostri servizi, possiamo raccogliere le seguenti informazioni personali: 1) Informazioni fornite volontariamente, come nome utente, indirizzo e-mail o dettagli di contatto durante la registrazione; 2) Informazioni raccolte automaticamente, inclusi dati del dispositivo (come modello del dispositivo, indirizzo IP, versione del sistema operativo) e dati di utilizzo (come orario di accesso, registri di interazione con le pagine); 3) Informazioni ottenute tramite servizi di terze parti autorizzati, come dati di account di social media.",
            "subcontent": "Seguiamo il principio di minimizzazione dei dati, raccogliendo solo le informazioni necessarie per gli scopi del servizio. Ogni trattamento dei dati si basa sulle basi giuridiche stabilite dal GDPR, inclusa l'esecuzione di contratti, interessi legittimi, il tuo consenso o obblighi legali."
          },
          {
            "title": "Finalità dell'uso delle informazioni",
            "content": "Utilizziamo le tue informazioni personali per: 1) fornire e mantenere le funzionalità del servizio; 2) migliorare l'esperienza utente e le prestazioni; 3) offrire supporto clienti; 4) analizzare l'uso del servizio; 5) garantire la sicurezza del servizio e prevenire frodi o abusi.",
            "subcontent": "Se dobbiamo utilizzare le tue informazioni per altri scopi (come il marketing), otterremo il tuo consenso esplicito in anticipo. Puoi revocare il consenso in qualsiasi momento, senza pregiudicare la legalità del trattamento precedente alla revoca."
          },
          {
            "title": "Cookie e tecnologie simili",
            "content": "Utilizziamo cookie, tag di pixel e tecnologie simili per raccogliere dati anonimi al fine di ottimizzare i nostri servizi, analizzare il traffico e fornire contenuti personalizzati. I cookie sono piccoli file memorizzati sul tuo dispositivo, che di solito contengono identificatori unici.",
            "list": [
              "Cookie necessari: supportano le funzioni essenziali del servizio, come l'accesso;",
              "Cookie analitici: ci aiutano a comprendere il comportamento degli utenti e a migliorare il servizio;",
              "Cookie funzionali: consentono funzionalità personalizzate, come il salvataggio delle preferenze."
            ],
            "subcontent": "Puoi accettare o rifiutare i cookie tramite le impostazioni del browser. Rifiutare i cookie non essenziali potrebbe influire su alcune funzionalità del servizio. Consulta la nostra politica sui cookie per maggiori dettagli."
          },
          {
            "title": "Servizi di terze parti",
            "content": "Possiamo incaricare fornitori di servizi di terze parti di elaborare dati per supportare il funzionamento dei nostri servizi. Questi fornitori includono:",
            "list": [
              "Servizi Google Play (per la distribuzione di applicazioni)",
              "Google Analytics (per l'analisi dei dati)",
              "Firebase Analytics (per il monitoraggio delle prestazioni)",
              "Crashlytics (per la raccolta di log di errori)"
            ],
            "subcontent": "Le terze parti elaborano i dati solo su nostre istruzioni e sono vincolate da accordi di trattamento dei dati (DPA) conformi ai requisiti del GDPR, non potendo utilizzare le tue informazioni per altri scopi."
          },
          {
            "title": "Condivisione dei dati e trasferimenti internazionali",
            "content": "Non vendiamo le tue informazioni personali né le condividiamo con terze parti senza il tuo consenso, salvo: 1) quando necessario per fornire il servizio; 2) per adempiere a obblighi legali; 3) per proteggere i nostri interessi legittimi (come prevenire frodi).",
            "subcontent": "In caso di trasferimento di dati al di fuori dell'UE, garantiamo la loro protezione tramite clausole contrattuali standard (SCC) o altri meccanismi riconosciuti dal GDPR, ad esempio quando utilizziamo server negli Stati Uniti."
          },
          {
            "title": "I tuoi diritti",
            "content": "Secondo il GDPR, hai i seguenti diritti: 1) accedere alle tue informazioni personali; 2) correggere dati inesatti; 3) eliminare le tue informazioni personali (‘diritto all’oblio’); 4) limitare o opporti al trattamento; 5) portabilità dei dati; 6) revocare il consenso.",
            "subcontent": "Per esercitare questi diritti, contattaci tramite i canali indicati di seguito. Risponderemo entro 30 giorni (estensibili a 90 giorni in casi particolari). Se non sei soddisfatto del nostro trattamento, puoi presentare un reclamo all’autorità di protezione dei dati del tuo paese."
          },
          {
            "title": "Sicurezza dei dati",
            "content": "Adottiamo misure di sicurezza standard del settore (come crittografia e controlli di accesso) per proteggere le tue informazioni personali da accessi o divulgazioni non autorizzati. In caso di violazione dei dati, notificheremo le autorità di controllo e gli utenti interessati entro 72 ore, come richiesto dal GDPR.",
            "subcontent": "Nonostante le misure ragionevoli adottate, nessuna trasmissione o archiviazione di dati su Internet è sicura al 100%."
          },
          {
            "title": "Privacy dei minori",
            "content": "I nostri servizi non sono destinati a minori di 16 anni. Non raccogliamo consapevolmente informazioni personali da minori di questa età. Se tali dati vengono rilevati, li elimineremo immediatamente. Se sei un genitore o tutore e ritieni che tuo figlio ci abbia fornito informazioni personali, contattaci."
          },
          {
            "title": "Link a siti di terze parti",
            "content": "I nostri servizi possono contenere link a siti di terze parti. Non siamo responsabili delle pratiche di privacy o dei contenuti di questi siti. Ti invitiamo a consultare le loro informative sulla privacy per capire come vengono trattati i tuoi dati."
          },
          {
            "title": "Aggiornamenti dell'informativa",
            "content": "Possiamo aggiornare questa Informativa sulla Privacy di tanto in tanto. La versione aggiornata sarà pubblicata su questa pagina con una nuova data di entrata in vigore. Le modifiche sostanziali ti saranno notificate tramite notifiche nel servizio o via e-mail. Ti consigliamo di rivedere regolarmente questa informativa.",
            "subcontent": "L’uso continuato del servizio implica l’accettazione dell’informativa aggiornata."
          },
          {
            "title": "Contattaci",
            "content": "In caso di domande su questa Informativa sulla Privacy o sul trattamento dei dati, o se desideri esercitare i tuoi diritti, invia la tua richiesta tramite la funzione ‘Contattaci’ nel servizio o il centro di assistenza. Risponderemo rapidamente e rispetteremo i requisiti di trasparenza e responsabilità del GDPR."
          }
        ]
      },
      "ja": {
        "title": "プライバシーポリシー",
        "effective_date": "本プライバシーポリシーの発効日：2025年3月24日",
        "version": "本プライバシーポリシーのバージョン：2025V1.0",
        "intro": "当社のサービスをご利用いただきありがとうございます。本プライバシーポリシーは、一般データ保護規則（GDPR）および関連法令に基づき、個人情報の収集、使用、保存、保護の方法を説明します。サービスを利用することで、本ポリシーの条件に同意したものとみなされます。私たちは透明性、合法性、安全性を確保し、必要な場合にのみ個人情報を利用します。",
        "sections": [
          {
            "title": "収集する個人情報",
            "content": "サービスを提供および最適化するため、以下の個人情報を収集する場合があります：1) ユーザーが自発的に提供する情報（例：登録時のユーザー名、メールアドレス、連絡先情報）；2) 自動的に収集される情報（例：デバイスのモデル、IPアドレス、OSバージョンなどのデバイス情報、アクセス時間やページ操作記録などの使用データ）；3) ユーザーが許可した第三者サービス（例：ソーシャルメディアアカウント）から取得する情報。",
            "subcontent": "データ最小化の原則に従い、サービス目的に必要な情報のみを収集します。すべてのデータ処理は、GDPRで定められた法的根拠（契約履行、正当な利益、同意、法的義務など）に基づいて行われます。"
          },
          {
            "title": "情報利用の目的",
            "content": "個人情報は以下の目的で使用されます：1) サービス機能の提供および維持；2) ユーザー体験とパフォーマンスの向上；3) カスタマーサポートの提供；4) サービス利用状況の分析；5) サービスのセキュリティ確保および詐欺や不正利用の防止。",
            "subcontent": "他の目的（例：マーケティング）で情報を使用する場合、事前に明確な同意を得ます。同意はいつでも撤回可能であり、撤回前の処理の合法性には影響しません。"
          },
          {
            "title": "クッキーおよび類似技術",
            "content": "当社はクッキーやピクセルタグなどの技術を使用して、匿名データを収集し、サービスの最適化、トラフィック分析、個人化コンテンツの提供を行います。クッキーは、通常一意の識別子を含む、デバイスに保存される小さなファイルです。",
            "list": [
              "必須クッキー：ログインなどのサービスの中核機能をサポート；",
              "分析クッキー：ユーザー行動を理解し、サービスを改善；",
              "機能クッキー：設定保存などの個人化機能を有効化。"
            ],
            "subcontent": "ブラウザ設定でクッキーの受け入れまたは拒否を選択できます。必須でないクッキーを拒否すると、サービスの一部の機能に影響する場合があります。詳細はクッキーポリシーを参照してください。"
          },
          {
            "title": "第三者サービス",
            "content": "サービス運営を支援するため、第三者サービスプロバイダにデータ処理を委託する場合があります。これらのプロバイダには以下が含まれます：",
            "list": [
              "Google Playサービス（アプリ配布用）",
              "Google Analytics（データ分析用）",
              "Firebase Analytics（パフォーマンス監視用）",
              "Crashlytics（エラーログ収集用）"
            ],
            "subcontent": "第三者は当社の指示に従ってのみデータを処理し、GDPRの要件を遵守するデータ処理契約（DPA）に拘束されます。他の目的での情報使用は禁止されています。"
          },
          {
            "title": "データ共有および国際移転",
            "content": "個人情報を販売したり、同意なく第三者と共有したりしません。ただし、以下の場合は除きます：1) サービス提供に必要な場合；2) 法的義務の遵守；3) 正当な利益の保護（例：詐欺防止）。",
            "subcontent": "EU外へのデータ移転が必要な場合、標準契約条項（SCC）またはGDPRで認められた他のメカニズム（例：米国のサーバー使用時）を通じてデータの安全を確保します。"
          },
          {
            "title": "あなたの権利",
            "content": "GDPRに基づき、以下の権利があります：1) 個人情報へのアクセス；2) 不正確なデータの修正；3) 個人情報の削除（「忘れられる権利」）；4) 処理の制限または反対；5) データポータビリティ；6) 同意の撤回。",
            "subcontent": "これらの権利を行使するには、以下に記載の連絡先までご連絡ください。30日以内（特別な場合は90日まで延長可能）に回答します。処理に不満がある場合、お住まいの国のデータ保護機関に苦情を申し立てることができます。"
          },
          {
            "title": "データセキュリティ",
            "content": "暗号化やアクセス制御など、業界標準のセキュリティ対策を採用し、個人情報の不正アクセスや漏洩を防ぎます。データ侵害が発生した場合、GDPRの要件に従い、72時間以内に監督当局および影響を受けるユーザーに通知します。",
            "subcontent": "合理的な対策を講じていますが、インターネット上のデータ送信や保存は100%安全ではありません。"
          },
          {
            "title": "子供のプライバシー",
            "content": "当社のサービスは16歳未満の子供を対象としていません。16歳未満の子供の個人情報を意図的に収集することはありません。このようなデータが発見された場合、即座に削除します。保護者または後見人で、お子さんが個人情報を提供したと思われる場合は、ご連絡ください。"
          },
          {
            "title": "第三者のウェブサイトへのリンク",
            "content": "当社のサービスには第三者のウェブサイトへのリンクが含まれる場合があります。これらのサイトのプライバシー慣行やコンテンツには責任を負いません。データ処理の詳細については、そのプライバシーポリシーを確認してください。"
          },
          {
            "title": "ポリシーの更新",
            "content": "本プライバシーポリシーは随時更新される場合があります。更新版は本ページに掲載され、新しい発効日が記載されます。重要な変更は、サービス内通知またはメールで通知されます。定期的に本ポリシーを確認することをお勧めします。",
            "subcontent": "サービスの継続利用は、更新されたポリシーへの同意を意味します。"
          },
          {
            "title": "お問い合わせ",
            "content": "本プライバシーポリシーやデータ処理に関する質問、または権利行使をご希望の場合、サービス内の「お問い合わせ」機能またはヘルプセンターを通じてご依頼ください。迅速に対応し、GDPRの透明性と説明責任の要件を遵守します。"
          }
        ]
      },
      "ko": {
        "title": "개인정보 처리방침",
        "effective_date": "본 개인정보 처리방침의 발효일: 2025년 3월 24일",
        "version": "본 개인정보 처리방침 버전: 2025V1.0",
        "intro": "저희 서비스를 이용해 주셔서 감사합니다. 본 개인정보 처리방침은 일반 데이터 보호 규정(GDPR) 및 관련 법률에 따라 개인정보를 수집, 사용, 저장, 보호하는 방법을 설명합니다. 서비스를 이용함으로써 본 방침의 조건에 동의하는 것으로 간주됩니다. 저희는 투명하고 합법적이며 안전한 방식으로 귀하의 정보를 처리하며, 필요한 경우에만 개인정보를 사용합니다.",
        "sections": [
          {
            "title": "수집하는 개인정보",
            "content": "서비스를 제공하고 최적화하기 위해 다음과 같은 개인정보를 수집할 수 있습니다: 1) 사용자가 자발적으로 제공하는 정보(예: 등록 시 사용자 이름, 이메일 주소, 연락처 정보); 2) 자동으로 수집되는 정보(예: 기기 모델, IP 주소, 운영체제 버전 등의 기기 정보, 접속 시간, 페이지 상호작용 기록 등의 사용 데이터); 3) 사용자가 승인한 제3자 서비스(예: 소셜 미디어 계정)에서 얻은 정보.",
            "subcontent": "저희는 데이터 최소화 원칙을 준수하며, 서비스 목적에 필요한 최소한의 정보만 수집합니다. 모든 데이터 처리는 GDPR에서 정한 법적 근거(계약 이행, 정당한 이익, 동의, 법적 의무 등)에 따라 수행됩니다."
          },
          {
            "title": "정보 사용 목적",
            "content": "귀하의 개인정보는 다음 목적으로 사용됩니다: 1) 서비스 기능 제공 및 유지; 2) 사용자 경험 및 성능 개선; 3) 고객 지원 제공; 4) 서비스 사용 분석; 5) 서비스 보안 확보 및 사기 또는 오용 방지.",
            "subcontent": "다른 목적(예: 마케팅)으로 정보를 사용해야 하는 경우, 사전에 명시적 동의를 얻습니다. 귀하는 언제든지 동의를 철회할 수 있으며, 이는 철회 전 동의 기반 처리의 합법성에 영향을 미치지 않습니다."
          },
          {
            "title": "쿠키 및 유사 기술",
            "content": "저희는 쿠키, 픽셀 태그 등의 기술을 사용하여 익명 데이터를 수집하여 서비스를 최적화하고, 트래픽을 분석하며, 맞춤 콘텐츠를 제공합니다. 쿠키는 일반적으로 고유 식별자를 포함하며 귀하의 기기에 저장되는 작은 파일입니다.",
            "list": [
              "필수 쿠키: 로그인 등 서비스의 핵심 기능을 지원;",
              "분석 쿠키: 사용자 행동을 이해하고 서비스를 개선;",
              "기능 쿠키: 설정 저장 등 맞춤 기능을 활성화."
            ],
            "subcontent": "브라우저 설정을 통해 쿠키를 수락하거나 거부할 수 있습니다. 비필수 쿠키를 거부하면 서비스의 일부 기능에 영향을 미칠 수 있습니다. 자세한 내용은 쿠키 정책을 참조하세요."
          },
          {
            "title": "제3자 서비스",
            "content": "서비스 운영을 지원하기 위해 제3자 서비스 제공업체에 데이터 처리를 위탁할 수 있습니다. 이러한 제공업체는 다음과 같습니다:",
            "list": [
              "Google Play 서비스(앱 배포용)",
              "Google Analytics(데이터 분석용)",
              "Firebase Analytics(성능 모니터링용)",
              "Crashlytics(오류 로그 수집용)"
            ],
            "subcontent": "제3자는 저희 지시에 따라 데이터만 처리하며, GDPR 요구사항을 준수하는 데이터 처리 계약(DPA)에 구속됩니다. 귀하의 정보를 다른 목적으로 사용할 수 없습니다."
          },
          {
            "title": "데이터 공유 및 국제 전송",
            "content": "저희는 귀하의 개인정보를 판매하거나 동의 없이 제3자와 공유하지 않습니다. 다만, 다음의 경우는 제외됩니다: 1) 서비스 제공에 필요한 경우; 2) 법적 의무 준수; 3) 정당한 이익 보호(예: 사기 방지).",
            "subcontent": "EU 외 지역으로 데이터 전송이 필요한 경우, 표준계약조항(SCC) 또는 GDPR에서 인정된 다른 메커니즘(예: 미국 서버 사용 시)을 통해 데이터 안전을 보장합니다."
          },
          {
            "title": "귀하의 권리",
            "content": "GDPR에 따라 귀하는 다음 권리를 가집니다: 1) 개인정보 접근; 2) 부정확한 데이터 수정; 3) 개인정보 삭제(‘잊힐 권리’); 4) 처리 제한 또는 반대; 5) 데이터 이동성; 6) 동의 철회.",
            "subcontent": "이 권리를 행사하려면 아래 연락처로 문의하세요. 30일 이내(특별한 경우 90일까지 연장 가능)에 응답합니다. 처리에 불만이 있는 경우, 귀하의 국가 데이터 보호 기관에 불만을 제기할 수 있습니다."
          },
          {
            "title": "데이터 보안",
            "content": "암호화, 접근 제어 등 업계 표준 보안 조치를 채택하여 개인정보를 무단 접근이나 유출로부터 보호합니다. 데이터 침해가 발생할 경우, GDPR 요구사항에 따라 72시간 이내에 감독 기관 및 영향을 받는 사용자에게 알립니다.",
            "subcontent": "합리적인 조치를 취하고 있지만, 인터넷을 통한 데이터 전송이나 저장은 100% 안전하지 않습니다."
          },
          {
            "title": "아동 개인정보",
            "content": "저희 서비스는 16세 미만 아동을 대상으로 하지 않습니다. 16세 미만 아동의 개인정보를 의도적으로 수집하지 않습니다. 이러한 데이터가 발견되면 즉시 삭제합니다. 부모 또는 보호자로서 자녀가 개인정보를 제공했다고 생각되면 문의해 주세요."
          },
          {
            "title": "제3자 웹사이트 링크",
            "content": "저희 서비스에는 제3자 웹사이트 링크가 포함될 수 있습니다. 이들 사이트의 개인정보 처리 관행이나 콘텐츠에 대해 책임지지 않습니다. 데이터 처리 방법을 이해하려면 해당 사이트의 개인정보 처리방침을 확인하세요."
          },
          {
            "title": "방침 업데이트",
            "content": "본 개인정보 처리방침은 수시로 업데이트될 수 있습니다. 업데이트된 버전은 본 페이지에 게시되며, 새로운 발효일이 명시됩니다. 중대한 변경은 서비스 내 알림 또는 이메일로 알려드립니다. 본 방침을 정기적으로 검토할 것을 권장합니다.",
            "subcontent": "서비스를 계속 사용하면 업데이트된 방침에 동의한 것으로 간주됩니다."
          },
          {
            "title": "문의하기",
            "content": "본 개인정보 처리방침이나 데이터 처리에 대한 질문이 있거나 권리를 행사하고 싶을 경우, 서비스 내 ‘문의하기’ 기능 또는 헬프센터를 통해 요청을 제출해 주세요. 신속히 응답하며 GDPR의 투명성과 책임 요구사항을 준수합니다."
          }
        ]
      },
      "ru": {
        "title": "Политика конфиденциальности",
        "effective_date": "Дата вступления в силу данной Политики конфиденциальности: 24 марта 2025 года",
        "version": "Версия Политики конфиденциальности: 2025V1.0",
        "intro": "Добро пожаловать в наши сервисы. Настоящая Политика конфиденциальности объясняет, как мы собираем, используем, храним и защищаем ваши персональные данные в соответствии с Общим регламентом по защите данных (GDPR) и применимыми законами. Используя наши сервисы, вы соглашаетесь с условиями данной политики. Мы стремимся обрабатывать вашу информацию прозрачно, законно и безопасно, используя её только при необходимости.",
        "sections": [
          {
            "title": "Персональные данные, которые мы собираем",
            "content": "Для предоставления и оптимизации наших сервисов мы можем собирать следующие персональные данные: 1) Информация, предоставленная вами добровольно, например, имя пользователя, адрес электронной почты или контактные данные при регистрации; 2) Автоматически собираемая информация, включая данные об устройстве (например, модель устройства, IP-адрес, версия операционной системы) и данные об использовании (например, время доступа, записи взаимодействия со страницами); 3) Информация, полученная через авторизованные сторонние сервисы, например, данные учетных записей в социальных сетях.",
            "subcontent": "Мы придерживаемся принципа минимизации данных, собирая только информацию, необходимую для целей сервиса. Обработка всех данных осуществляется на законных основаниях, предусмотренных GDPR, включая выполнение контракта, законные интересы, ваше согласие или юридические обязательства."
          },
          {
            "title": "Цели использования информации",
            "content": "Мы используем ваши персональные данные для: 1) предоставления и поддержки функций сервиса; 2) улучшения пользовательского опыта и производительности; 3) оказания поддержки клиентам; 4) анализа использования сервиса; 5) обеспечения безопасности сервиса и предотвращения мошенничества или злоупотреблений.",
            "subcontent": "Если нам потребуется использовать вашу информацию для других целей (например, маркетинга), мы получим ваше явное согласие заранее. Вы можете отозвать согласие в любое время, что не повлияет на законность обработки до отзыва."
          },
          {
            "title": "Файлы cookie и аналогичные технологии",
            "content": "Мы используем файлы cookie, пиксельные теги и аналогичные технологии для сбора анонимных данных, чтобы оптимизировать наши сервисы, анализировать трафик и предоставлять персонализированный контент. Файлы cookie — это небольшие файлы, хранящиеся на вашем устройстве, обычно содержащие уникальные идентификаторы.",
            "list": [
              "Необходимые cookie: поддерживают основные функции сервиса, такие как вход в систему;",
              "Аналитические cookie: помогают нам понимать поведение пользователей и улучшать сервис;",
              "Функциональные cookie: позволяют использовать персонализированные функции, такие как сохранение настроек."
            ],
            "subcontent": "Вы можете принять или отклонить файлы cookie через настройки браузера. Отказ от необязательных cookie может повлиять на некоторые функции сервиса. Подробности см. в нашей политике cookie."
          },
          {
            "title": "Сторонние сервисы",
            "content": "Мы можем поручать обработку данных сторонним поставщикам услуг для поддержки работы наших сервисов. Эти поставщики включают:",
            "list": [
              "Сервисы Google Play (для распространения приложений)",
              "Google Analytics (для анализа данных)",
              "Firebase Analytics (для мониторинга производительности)",
              "Crashlytics (для сбора логов ошибок)"
            ],
            "subcontent": "Сторонние поставщики обрабатывают данные только по нашим инструкциям и обязаны соблюдать соглашения об обработке данных (DPA) в соответствии с требованиями GDPR, не используя вашу информацию в других целях."
          },
          {
            "title": "Передача данных и международные трансферы",
            "content": "Мы не продаем ваши персональные данные и не передаем их третьим лицам без вашего согласия, за исключением случаев: 1) когда это необходимо для предоставления сервиса; 2) для выполнения юридических обязательств; 3) для защиты наших законных интересов (например, предотвращения мошенничества).",
            "subcontent": "При передаче данных за пределы ЕС мы обеспечиваем их защиту с помощью стандартных договорных условий (SCC) или других механизмов, признанных GDPR, например, при использовании серверов в США."
          },
          {
            "title": "Ваши права",
            "content": "Согласно GDPR, вы имеете следующие права: 1) доступ к вашим персональным данным; 2) исправление неточных данных; 3) удаление персональных данных (‘право на забвение’); 4) ограничение или возражение против обработки; 5) переносимость данных; 6) отзыв согласия.",
            "subcontent": "Чтобы воспользоваться этими правами, свяжитесь с нами через указанные ниже каналы. Мы ответим в течение 30 дней (в особых случаях до 90 дней). Если вы недовольны нашей обработкой данных, вы можете подать жалобу в орган по защите данных вашей страны."
          },
          {
            "title": "Безопасность данных",
            "content": "Мы применяем стандартные отраслевые меры безопасности (например, шифрование и контроль доступа) для защиты ваших персональных данных от несанкционированного доступа или разглашения. В случае утечки данных мы уведомим надзорные органы и затронутых пользователей в течение 72 часов, как того требует GDPR.",
            "subcontent": "Несмотря на разумные меры, ни одна передача или хранение данных в Интернете не является на 100% безопасной."
          },
          {
            "title": "Конфиденциальность детей",
            "content": "Наши сервисы не предназначены для детей младше 16 лет. Мы сознательно не собираем персональные данные детей младше этого возраста. Если такие данные обнаруживаются, мы немедленно их удаляем. Если вы родитель или опекун и считаете, что ваш ребенок предоставил нам персональные данные, свяжитесь с нами."
          },
          {
            "title": "Ссылки на сторонние сайты",
            "content": "Наши сервисы могут содержать ссылки на сторонние сайты. Мы не несем ответственности за их практики конфиденциальности или контент. Пожалуйста, ознакомьтесь с их политиками конфиденциальности, чтобы понять, как обрабатываются ваши данные."
          },
          {
            "title": "Обновления политики",
            "content": "Мы можем время от времени обновлять эту Политику конфиденциальности. Обновленная версия будет опубликована на этой странице с новой датой вступления в силу. О существенных изменениях мы уведомим вас через уведомления в сервисе или по электронной почте. Рекомендуем регулярно проверять эту политику.",
            "subcontent": "Продолжение использования сервиса означает ваше согласие с обновленной политикой."
          },
          {
            "title": "Свяжитесь с нами",
            "content": "Если у вас есть вопросы по поводу этой Политики конфиденциальности или обработки данных, или вы хотите воспользоваться своими правами, отправьте запрос через функцию ‘Связаться с нами’ в сервисе или через центр помощи. Мы ответим быстро и будем соблюдать требования GDPR к прозрачности и подотчетности."
          }
        ]
      },
      "zh-CN": {
              "title": "隐私协议",
              "effective_date": "本隐私协议生效日期：2025年3月24日",
              "version": "本隐私协议版本：2025V1.0",
              "intro": "欢迎使用我们的服务。本隐私协议说明我们如何根据《通用数据保护条例》（GDPR）及相关法律收集、使用、存储和保护您的个人信息。使用我们的服务即表示您同意本协议的条款。我们致力于以透明、合法和安全的方式处理您的信息，仅在必要时使用您的个人信息。",
              "sections": [
                {
                  "title": "我们收集的个人信息",
                  "content": "为提供和优化我们的服务，我们可能收集以下个人信息：1) 您主动提供的信息，如注册时的用户名、电子邮件地址或联系方式；2) 自动收集的信息，包括设备信息（例如设备型号、IP地址、操作系统版本）、使用数据（例如访问时间、页面交互记录）；3) 通过您授权的第三方服务获取的信息，例如社交媒体账户数据。",
                  "subcontent": "我们遵循数据最小化原则，仅收集为实现服务目的所需的信息。所有数据处理均基于GDPR规定的合法依据，包括履行合同、合法利益、您的同意或法律义务。"
                },
                {
                  "title": "信息使用目的",
                  "content": "我们使用您的个人信息以：1) 提供和维护服务功能；2) 改进用户体验和性能；3) 提供客户支持；4) 分析服务使用情况；5) 确保服务安全，防止欺诈或滥用行为。",
                  "subcontent": "如需将您的信息用于其他目的（例如营销），我们将在获得您明确同意后进行。您可随时撤回同意，且不影响撤回前基于同意的处理合法性。"
                },
                {
                  "title": "Cookies 和类似技术",
                  "content": "我们使用Cookies、像素标签等技术收集匿名数据，以优化服务、分析流量和提供个性化内容。Cookies是存储在您设备上的小型文件，通常包含唯一标识符。",
                  "list": [
                    "必要Cookies：支持服务核心功能，如用户登录；",
                    "分析Cookies：帮助我们了解用户行为，改进服务；",
                    "功能Cookies：启用个性化功能，如保存偏好设置。"
                  ],
                  "subcontent": "您可通过浏览器设置接受或拒绝Cookies。拒绝非必要Cookies可能影响部分服务功能。详细信息请参阅我们的Cookies政策。"
                },
                {
                  "title": "第三方服务",
                  "content": "我们可能委托第三方服务提供商处理数据，以支持服务运营。这些提供商包括：",
                  "list": [
                    "Google Play 服务（用于应用分发）",
                    "Google Analytics（用于数据分析）",
                    "Firebase Analytics（用于性能监控）",
                    "Crashlytics（用于错误日志收集）"
                  ],
                  "subcontent": "第三方仅在我们的指示下处理数据，并受数据处理协议（DPA）约束，遵守GDPR要求，不得将您的信息用于其他目的。"
                },
                {
                  "title": "数据共享与跨境传输",
                  "content": "我们不会出售您的个人信息或未经同意与第三方共享，除非：1) 为提供服务所需；2) 遵守法律义务；3) 保护我们的合法权益（如防止欺诈）。",
                  "subcontent": "如需将数据传输至欧盟以外地区，我们将通过标准合同条款（SCC）或GDPR认可的其他机制确保数据安全，例如使用位于美国的云服务时。"
                },
                {
                  "title": "您的权利",
                  "content": "根据GDPR，您享有以下权利：1) 访问您的个人信息；2) 更正不准确数据；3) 删除个人信息（‘被遗忘权’）；4) 限制或反对数据处理；5) 数据可携权；6) 撤回同意。",
                  "subcontent": "如需行使权利，请通过本协议末尾的联系方式与我们联系。我们将在30天内（特殊情况可延长至90天）响应。如对我们的处理不满意，您可向您所在国家的数据保护机构投诉。"
                },
                {
                  "title": "数据安全",
                  "content": "我们采用加密、访问控制等行业标准措施保护您的个人信息，防止未经授权的访问或泄露。如发生数据泄露，我们将根据GDPR在72小时内通知监管机构和受影响用户。",
                  "subcontent": "尽管我们采取合理措施，但任何网络传输或存储均无法100%安全，我们无法保证绝对安全。"
                },
                {
                  "title": "儿童隐私",
                  "content": "我们的服务不面向16岁以下儿童。我们不会故意收集16岁以下儿童的个人信息。如发现此类数据，我们将立即删除。如您是父母或监护人，发现孩子提供了个人信息，请联系我们。"
                },
                {
                  "title": "第三方网站链接",
                  "content": "我们的服务可能包含第三方网站链接。我们不对这些网站的隐私实践或内容负责。请审阅其隐私政策以了解其数据处理方式。"
                },
                {
                  "title": "协议更新",
                  "content": "我们可能不时更新本隐私协议。更新版本将在本页面发布，并注明新生效日期。重大变更将通过服务内通知或电子邮件告知您。建议定期查看本协议。",
                  "subcontent": "继续使用服务即表示您接受更新后的协议。"
                },
                {
                  "title": "联系我们",
                  "content": "如对本隐私协议或数据处理有任何疑问，或需行使您的权利，请通过我们服务内的‘联系我们’功能或帮助中心提交您的请求。我们将尽快响应，并确保遵守GDPR的透明度和问责制要求。"
                }
              ]
            },
      "zh-TW": {
          "title": "隱私政策",
          "effective_date": "本隱私政策生效日期：2025年3月24日",
          "version": "本隱私政策版本：2025V1.0",
          "intro": "歡迎使用我們的服務。本隱私政策說明我們如何依據《通用資料保護規範》（GDPR）及相關法律收集、使用、儲存和保護您的個人資料。使用我們的服務即表示您同意本政策的條款。我們致力於以透明、合法和安全的方式處理您的資料，僅在必要時使用您的個人資料。",
          "sections": [
            {
              "title": "我們收集的個人資料",
              "content": "為提供和優化我們的服務，我們可能收集以下個人資料：1) 您主動提供的資料，如註冊時的用戶名稱、電子郵件地址或聯繫方式；2) 自動收集的資料，包括設備資訊（例如設備型號、IP地址、作業系統版本）、使用資料（例如訪問時間、頁面互動記錄）；3) 通過您授權的第三方服務取得的資料，例如社群媒體帳戶資料。",
              "subcontent": "我們遵循資料最小化原則，僅收集實現服務目的所需的資料。所有資料處理均基於GDPR規定的合法依據，包括履行合同、合法利益、您的同意或法律義務。"
            },
            {
              "title": "資料使用目的",
              "content": "我們使用您的個人資料以：1) 提供和維護服務功能；2) 改善用戶體驗和效能；3) 提供客戶支援；4) 分析服務使用情況；5) 確保服務安全，防止詐欺或濫用行為。",
              "subcontent": "如需將您的資料用於其他目的（例如行銷），我們將事先取得您的明確同意。您可隨時撤回同意，且不影響撤回前基於同意的處理合法性。"
            },
            {
              "title": "Cookies 及類似技術",
              "content": "我們使用Cookies、像素標籤等技術收集匿名資料，以優化服務、分析流量並提供個人化內容。Cookies是儲存在您設備上的小型檔案，通常包含唯一識別碼。",
              "list": [
                "必要Cookies：支援服務核心功能，如用戶登錄；",
                "分析Cookies：幫助我們了解用戶行為，改善服務；",
                "功能Cookies：啟用個人化功能，如儲存偏好設定。"
              ],
              "subcontent": "您可透過瀏覽器設定接受或拒絕Cookies。拒絕非必要Cookies可能影響部分服務功能。詳細資訊請參閱我們的Cookies政策。"
            },
            {
              "title": "第三方服務",
              "content": "我們可能委託第三方服務提供者處理資料，以支援服務運營。這些提供者包括：",
              "list": [
                "Google Play 服務（用於應用分發）",
                "Google Analytics（用於資料分析）",
                "Firebase Analytics（用於效能監控）",
                "Crashlytics（用於錯誤日誌收集）"
              ],
              "subcontent": "第三方僅依我們的指示處理資料，並受資料處理協議（DPA）約束，遵守GDPR要求，不得將您的資料用於其他目的。"
            },
            {
              "title": "資料共享與跨境傳輸",
              "content": "我們不會出售您的個人資料或未經同意與第三方共享，除非：1) 為提供服務所需；2) 遵守法律義務；3) 保護我們的合法權益（如防止詐欺）。",
              "subcontent": "如需將資料傳輸至歐盟以外地區，我們將通過標準合同條款（SCC）或GDPR認可的其他機制確保資料安全，例如使用位於美國的伺服器時。"
            },
            {
              "title": "您的權利",
              "content": "根據GDPR，您享有以下權利：1) 訪問您的個人資料；2) 更正不準確資料；3) 刪除個人資料（‘被遺忘權’）；4) 限制或反對資料處理；5) 資料可攜權；6) 撤回同意。",
              "subcontent": "如需行使權利，請通過本政策末尾的聯繫方式與我們聯繫。我們將在30天內（特殊情況可延長至90天）回應。如對我們的處理不滿意，您可向您所在國家的資料保護機構投訴。"
            },
            {
              "title": "資料安全",
              "content": "我們採用加密、存取控制等行業標準措施保護您的個人資料，防止未經授權的存取或洩露。如發生資料外洩，我們將根據GDPR要求在72小時內通知監管機構和受影響用戶。",
              "subcontent": "儘管我們採取合理措施，但任何網路傳輸或儲存均無法100%安全，我們無法保證絕對安全。"
            },
            {
              "title": "兒童隱私",
              "content": "我們的服務不面向16歲以下兒童。我們不會故意收集16歲以下兒童的個人資料。如發現此類資料，我們將立即刪除。如您是父母或監護人，發現孩子提供了個人資料，請聯繫我們。"
            },
            {
              "title": "第三方網站連結",
              "content": "我們的服務可能包含第三方網站連結。我們不對這些網站的隱私做法或內容負責。請審閱其隱私政策以了解其資料處理方式。"
            },
            {
              "title": "政策更新",
              "content": "我們可能不時更新本隱私政策。更新版本將在本頁面發布，並註明新生效日期。重大變更將通過服務內通知或電子郵件告知您。建議定期審閱本政策。",
              "subcontent": "繼續使用服務即表示您接受更新後的政策。"
            },
            {
              "title": "聯繫我們",
              "content": "如對本隱私政策或資料處理有任何疑問，或需行使您的權利，請通過我們服務內的‘聯繫我們’功能或幫助中心提交您的請求。我們將盡快回應，並確保遵守GDPR的透明度和問責制要求。"
            }
          ]
        }
      };

    function getLangFromUrl() {
    const params = new URLSearchParams(window.location.search);
    return params.get('lang') || 'en'; // 默认中文
  }

  function loadLanguage(lang) {
    try {
      const data = translations[lang] || translations['en'];

      const source = document.getElementById('privacy-agreement-template').innerHTML;
      const template = Handlebars.compile(source);

      document.getElementById('privacy-agreement-container').innerHTML = template(data);

      document.getElementById('page-title').textContent = data.title;
      document.documentElement.lang = lang;
    } catch (error) {
      console.error('Language rendering error:', error);
      loadLanguage('en');
    }
  }

  // 暴露给 Android 原生调用的函数
  window.switchLanguage = function(lang) {
    loadLanguage(lang || 'en');
  };

  // 根据 URL 参数加载语言
  const lang = getLangFromUrl();
  loadLanguage(lang);