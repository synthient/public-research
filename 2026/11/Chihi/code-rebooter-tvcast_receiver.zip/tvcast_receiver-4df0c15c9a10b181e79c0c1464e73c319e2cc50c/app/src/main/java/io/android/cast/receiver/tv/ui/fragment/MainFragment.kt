package io.android.cast.receiver.tv.ui.fragment

import androidx.lifecycle.lifecycleScope
import io.android.cast.receiver.tv.AppCache
import io.android.cast.receiver.tv.AppCache.downloadUrl
import io.android.cast.receiver.tv.R
import io.android.cast.receiver.tv.databinding.FragmentMainBinding
import io.android.cast.receiver.tv.ext.getConnectedWifiInfo
import io.android.cast.receiver.tv.ext.setQRCode
import io.android.cast.receiver.tv.ext.startAllService
import io.android.cast.receiver.tv.ui.activity.SettingEmtActivity
import io.android.cast.receiver.tv.ui.viewmodel.MainViewModel
import io.android.code.lib_base.AppCacheBase
import io.android.code.lib_base.appContext
import io.android.code.lib_base.base.BaseVMFragment
import io.android.code.lib_base.ext.clickNoRepeatWithAnim
import io.android.code.lib_base.ext.killChildProcesses
import io.android.code.lib_base.ext.startKtxActivity
import io.android.code.lib_base.ext.stringValueWithFormat
import io.android.code.lib_cast.config.CastConfig
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

class MainFragment : BaseVMFragment<FragmentMainBinding, MainViewModel>() {


    override fun initView() {
        val (ssid, ip) = appContext.getConnectedWifiInfo()
        mBind.tvWifiName.text = R.string.wlan_name_mask.stringValueWithFormat(ssid)
        mBind.tvIp.text = R.string.ip_mask.stringValueWithFormat(ip)

        mBind.tvDlnaName.text = CastConfig.getDlnaServerName()
        mBind.tvAirplayName.text = CastConfig.getAirPlayServerName()

        mBind.ivSetting.requestFocus()

        if (downloadUrl.isNotEmpty()) {
            mBind.ivQrcodeDownload.setQRCode(downloadUrl, qrVersion = 10) {
            }
        }
        mViewModel.reqSenderInfo { url ->
            if (downloadUrl != url) {
                downloadUrl = url
                mBind.ivQrcodeDownload.setQRCode(downloadUrl, qrVersion = 10) {
                }
            }
        }

        mBind.ivQrcodeConnect.setQRCode(ip) {

        }

        lifecycleScope.launch {
            while (isActive) {
                delay(30000)
                if (!AppCacheBase.isWebVisible) appContext.killChildProcesses()
            }
        }


    }

    override fun onStart() {
        super.onStart()
        lifecycleScope.launch {
            //delay(2500)
            appContext.startAllService()
        }
    }

    override fun initClick() {
        mBind.ivSetting.clickNoRepeatWithAnim {
            startKtxActivity<SettingEmtActivity>()
        }
    }




}