package io.android.cast.receiver.tv.net

import io.android.cast.receiver.tv.BuildConfig


object UrlManager {
    private const val BASEURL = BuildConfig.BASE_URL
    const val GET_SENDER_DOWNLOAD_URL = "${BASEURL}appapi/mirrcast/geturl"
}