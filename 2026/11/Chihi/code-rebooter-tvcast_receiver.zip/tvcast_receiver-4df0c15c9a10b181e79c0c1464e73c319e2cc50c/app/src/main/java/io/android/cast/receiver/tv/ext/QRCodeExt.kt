package io.android.cast.receiver.tv.ext

import android.graphics.Bitmap
import android.widget.ImageView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.lifecycleScope
import com.google.zxing.BarcodeFormat
import com.google.zxing.WriterException
import com.google.zxing.common.BitMatrix
import com.google.zxing.qrcode.QRCodeWriter
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import androidx.core.graphics.createBitmap
import androidx.core.graphics.set
import androidx.lifecycle.lifecycleScope
import com.google.zxing.EncodeHintType
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel

// 扩展函数：为 ImageView 添加生成并显示二维码的功能
fun ImageView.setQRCode(
    content: String,
    size: Int = 300,
    margin: Int = 0,
    qrVersion: Int = 5,
    errorCorrection: ErrorCorrectionLevel = ErrorCorrectionLevel.H,
    result: () -> Unit
) {
    (context as? FragmentActivity)?.lifecycleScope?.launch {
        try {
            val bitmap = withContext(Dispatchers.IO) {
                generateQRCode(content, size, size, margin, qrVersion, errorCorrection)
            }
            setImageBitmap(bitmap)
            result.invoke()
        } catch (e: Exception) {
            //Toast.makeText(context, "生成二维码失败", Toast.LENGTH_SHORT).show()
            //println("生成二维码失败")
        }
    } ?: run {
        //Toast.makeText(context, "无法生成二维码：上下文不支持协程", Toast.LENGTH_SHORT).show()
        //println("无法生成二维码：上下文不支持协程")
    }
}

// 生成二维码的私有函数，支持版本和纠错级别
private fun generateQRCode(
    content: String,
    width: Int,
    height: Int,
    margin: Int,
    qrVersion: Int,
    errorCorrection: ErrorCorrectionLevel
): Bitmap {
    val writer = QRCodeWriter()
    try {
        // 设置编码参数：边距、版本、纠错级别
        val hints = mapOf(
            EncodeHintType.MARGIN to margin,
            EncodeHintType.QR_VERSION to qrVersion,
            EncodeHintType.ERROR_CORRECTION to errorCorrection
        )
        val bitMatrix: BitMatrix = writer.encode(content, BarcodeFormat.QR_CODE, width, height, hints)
        val bitmap = createBitmap(width, height, Bitmap.Config.RGB_565)
        for (x in 0 until width) {
            for (y in 0 until height) {
                bitmap[x, y] = if (bitMatrix[x, y]) 0xFF000000.toInt() else 0xFFFFFFFF.toInt()
            }
        }
        return bitmap
    } catch (e: WriterException) {
        throw RuntimeException("QR Code generation failed", e)
    }
}