package io.android.cast.receiver.tv.net

import android.content.Context
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.content.edit

object DomainCacheResetPolicy {
    private const val APP_PREFERENCES = "AppPreferences"
    private const val BASE_URL_KEY = "baseUrl"
    private const val LAST_HANDLED_UPDATE_TIME_KEY = "lastHandledUpdateTime"

    private val domainCacheKeys = listOf(
        BASE_URL_KEY,
        "backupDomain",
        "randomUrl",
        "successfullDomain",
        "randomDomainMD5",
        "domainList",
        "primaryDomainFailTime",
        "backupDomainFailTime",
        "lastPingDomainTime",
        "allow_fetch_randomdomain"
    )

    fun resetIfNeeded(context: Context, currentBaseUrl: String) {
        val packageInfo = context.currentPackageInfo()
        val preferences = context.getSharedPreferences(APP_PREFERENCES, Context.MODE_PRIVATE)
        val cachedBaseUrl = preferences.getString(BASE_URL_KEY, null)
        val lastHandledUpdateTime = preferences.getLong(LAST_HANDLED_UPDATE_TIME_KEY, -1L)

        if (
            shouldResetDomainCache(
                firstInstallTime = packageInfo.firstInstallTime,
                lastUpdateTime = packageInfo.lastUpdateTime,
                lastHandledUpdateTime = lastHandledUpdateTime,
                cachedBaseUrl = cachedBaseUrl,
                currentBaseUrl = currentBaseUrl
            )
        ) {
            preferences.edit {
                domainCacheKeys.forEach(::remove)
            }
        }

        preferences.edit {
            putLong(LAST_HANDLED_UPDATE_TIME_KEY, packageInfo.lastUpdateTime)
        }
    }

    fun shouldResetDomainCache(
        firstInstallTime: Long,
        lastUpdateTime: Long,
        lastHandledUpdateTime: Long,
        cachedBaseUrl: String?,
        currentBaseUrl: String
    ): Boolean {
        val isUpdatedInstall = lastUpdateTime > firstInstallTime
        val isFirstLaunchAfterCurrentUpdate = lastHandledUpdateTime != lastUpdateTime
        val baseUrlChanged = cachedBaseUrl != currentBaseUrl

        return isUpdatedInstall && isFirstLaunchAfterCurrentUpdate && baseUrlChanged
    }

    private fun Context.currentPackageInfo(): PackageInfo {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            packageManager.getPackageInfo(packageName, PackageManager.PackageInfoFlags.of(0))
        } else {
            @Suppress("DEPRECATION")
            packageManager.getPackageInfo(packageName, 0)
        }
    }
}
