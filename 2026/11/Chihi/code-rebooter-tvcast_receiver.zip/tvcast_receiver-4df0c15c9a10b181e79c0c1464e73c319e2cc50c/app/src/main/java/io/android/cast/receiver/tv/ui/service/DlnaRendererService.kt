package io.android.cast.receiver.tv.ui.service

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.PendingIntentCompat.send
import androidx.fragment.app.FragmentActivity
import io.android.cast.receiver.tv.constants.DLNA_STOPED
import io.android.cast.receiver.tv.ui.dialog.DlnaRendererDialog
import io.android.cast.receiver.tv.ui.dialog.base.showDialog
import io.android.code.lib_base.currentActivity
import io.android.code.lib_base.event.sendLiveEventData
import io.android.code.lib_cast.dlna.UpnpAndroidService
import io.android.code.lib_cast.manager.DlnaRendererManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import org.fourthline.cling.android.AndroidUpnpService
import kotlin.jvm.java

class DlnaRendererService : Service(), DlnaRendererManager.Listener {

    companion object {
        const val CHANNEL_ID = "dlna_renderer_channel"
        const val NOTIF_ID = 2001
    }

    private var upnpService: AndroidUpnpService? = null

    private val connection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, binder: IBinder?) {
            upnpService = (binder as? AndroidUpnpService)
            upnpService?.let { DlnaRendererManager.init(it, this@DlnaRendererService) }
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            upnpService = null
        }
    }

    override fun onCreate() {
        super.onCreate()
        startForegroundCompat()

        DlnaRendererManager.setListener(this)

        val intent = Intent(this, UpnpAndroidService::class.java)
        bindService(intent, connection, Context.BIND_AUTO_CREATE)
    }

    private fun startForegroundCompat() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "DLNA Renderer", NotificationManager.IMPORTANCE_LOW)
            )
        }

        val notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("A-Player")
            .setContentText("等待投屏设备连接...")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()

        startForeground(NOTIF_ID, notification)
    }

    private var job: Job? = null
    private var dialog: DlnaRendererDialog? = null

    // 🔹 DLNA 播放控制回调
    override fun onSetAVTransportURI(uri: String) {
        //println("[Service] 播放地址: $uri")
        // 取消上一个任务,主要是考虑任务耗时长，但是第二次又触发了，导致同时运行的情况
        job?.cancel()
        job = CoroutineScope(Dispatchers.Main).launch {
            dialog?.dismiss()
            dialog = null
            dialog = (currentActivity as FragmentActivity).showDialog(DlnaRendererDialog()) {
                videoUrlDate.value = uri
            }
        }

    }

    override fun onPlay() {
        // println("[Service] 播放开始")
    }

    override fun onPause() {
        // println("[Service] 播放暂停")
    }

    override fun onStop() {
        //println("[Service] 播放停止")
        //sendLiveEventData(DLNA_STOPED,true)
        dialog?.dismiss()
        dialog = null
        job?.cancel()
    }

    override fun onDestroy() {
        super.onDestroy()
        DlnaRendererManager.release()
        unbindService(connection)
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
