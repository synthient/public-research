package io.android.cast.receiver.tv.ui.service

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.Binder
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.fragment.app.FragmentActivity
import io.android.cast.receiver.tv.constants.MIRROER_DISCONNECT
import io.android.cast.receiver.tv.ui.dialog.AirPlayMirrorDialog
import io.android.cast.receiver.tv.ui.dialog.DlnaRendererDialog
import io.android.cast.receiver.tv.ui.dialog.base.showDialog
import io.android.cast.receiver.tv.ui.view.MirrorReceiver
import io.android.code.lib_base.currentActivity
import io.android.code.lib_base.event.sendLiveEventData
import io.android.code.lib_cast.manager.AirPlayManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class AirPlayService : Service() {

    companion object {
        const val CHANNEL_ID = "airplay_service_channel"
        const val NOTIF_ID = 2002
    }

    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    private val binder = MirrorReceiverBinder()

    private  var mirrorReceiver: MirrorReceiver ?=null

    override fun onBind(intent: Intent?): IBinder {
        return binder
    }

    override fun onCreate() {
        super.onCreate()
        startForegroundCompat()
        scope.launch {
            mirrorReceiver = MirrorReceiver()
            startAirPlayReceiver()
        }
    }

    private fun startForegroundCompat() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "AirPlay Service", NotificationManager.IMPORTANCE_LOW)
            )
        }

        val notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("A-Player")
            .setContentText("AirPlay 服务运行中...")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()

        startForeground(NOTIF_ID, notification)
    }

    private var dialog: AirPlayMirrorDialog? = null
    private suspend fun startAirPlayReceiver() = withContext(Dispatchers.IO) {
        AirPlayManager.start(
            onVideo = { video ->
                // 收到视频数据
                mirrorReceiver?.onVideo(video)
            },
            onAudio = { audio ->
                // 收到音频数据
                mirrorReceiver?.onAudio(audio)
            },
            onDataDisconnect = {
                //IOS镜像流断开
                sendLiveEventData(MIRROER_DISCONNECT, true)
            },
            onVideoFormat = {
                //IOS镜像流连接成功
                mirrorReceiver?.createPlayer()
                dialog?.dismiss()
                dialog = null
                dialog = (currentActivity as FragmentActivity).showDialog(AirPlayMirrorDialog()) {}
            }
        )
    }


    override fun onDestroy() {
        AirPlayManager.stop()
        mirrorReceiver?.unbindSurfaceView()
        mirrorReceiver?.release()
        mirrorReceiver = null
        scope.cancel()
        super.onDestroy()
    }

    inner class MirrorReceiverBinder : Binder() {
        fun getMirrorReceiver(): MirrorReceiver = mirrorReceiver!!
    }

}