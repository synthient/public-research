package io.android.cast.receiver.tv.ui.dialog

import android.os.Bundle
import androidx.constraintlayout.widget.ConstraintSet
import androidx.core.view.isVisible
import io.android.cast.receiver.tv.R
import io.android.cast.receiver.tv.databinding.DialogCenterCommonBinding
import io.android.cast.receiver.tv.ui.dialog.base.BaseDialogFragment
import io.android.code.lib_base.ext.clickNoRepeatWithAnim

class CenterCommonDialog : BaseDialogFragment<DialogCenterCommonBinding>() {


    override fun initView(savedInstanceState: Bundle?) {
        binding.tvOk.clickNoRepeatWithAnim(shrinkScale = 0.96f) {
            invokeOKAction()
            dismiss()
        }
        binding.tvCancle.clickNoRepeatWithAnim(shrinkScale = 0.96f) {
            dismiss()
        }
        binding.tvConfirm.clickNoRepeatWithAnim(shrinkScale = 0.96f) {
            dismiss()
            invokeConfirmAction()
        }
        textTip.observe(this) {
            binding.tvDesc.text = it
        }
        textOK.observe(this) {
            binding.tvOk.text = it
        }
        textCancle.observe(this) {
            binding.tvCancle.text = it
        }
        isShowSingleBtn.observe(this) {
            binding.tvOk.isVisible = !it
            binding.tvCancle.isVisible = !it
            binding.tvConfirm.isVisible = it
            // 创建 ConstraintSet 并克隆当前布局约束
            val constraintSet = ConstraintSet()
            constraintSet.clone(binding.container)

            // 修改 tv_desc 的底部约束：从 tv_ok 的顶部改为其他视图（如 parent 或其他视图）
            constraintSet.connect(
                R.id.tv_desc,                     // 目标视图 ID
                ConstraintSet.BOTTOM,             // 目标视图的边（底部）
                R.id.tv_confirm,                       // 约束目标的视图 ID（可改为其他视图或 ConstraintSet.PARENT_ID）
                ConstraintSet.TOP,                // 约束目标的边（顶部）
            )

            // 应用修改后的约束
            constraintSet.applyTo(binding.container)

            binding.tvConfirm.requestFocus()
        }

        isShowNoneBtn.observe(this) {
            binding.tvOk.isVisible = !it
            binding.tvCancle.isVisible = !it
            binding.tvConfirm.isVisible = !it
        }
        binding.tvOk.requestFocus()
    }
}