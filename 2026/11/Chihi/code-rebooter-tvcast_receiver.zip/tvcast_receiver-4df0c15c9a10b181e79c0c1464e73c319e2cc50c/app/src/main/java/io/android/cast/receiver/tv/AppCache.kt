package io.android.cast.receiver.tv

import android.annotation.SuppressLint
import preference

@SuppressLint("StaticFieldLeak")
object AppCache {
    var isPrivacyPolicyAgreed: Boolean by preference("is_privacy_policy_agreed", false)
    var downloadUrl: String by preference("download_url", "")

}