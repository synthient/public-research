package io.android.cast.receiver.tv.ui.viewmodel

import io.android.cast.receiver.tv.bean.SenderInfoDto
import io.android.cast.receiver.tv.net.UrlManager
import io.android.code.lib_base.base.BaseViewModel
import com.speed.net.NetworkHelper
import com.speed.net.enum.RequestMethod


class MainViewModel: BaseViewModel() {
    fun reqSenderInfo(url:(String)->Unit){
        NetworkHelper.makeRequest<SenderInfoDto>(
            UrlManager.GET_SENDER_DOWNLOAD_URL,
            RequestMethod.GET,
            hashMapOf(),
            isForm = true,
            isEncryted = false,
        ) { dto, error: Throwable? ->

            if (error == null) {
                dto?.let {
                    // 完成请求，返回结果
                    it.downloadurl?.let {
                        url.invoke(it)
                    }
                }

            } else {
                //println("当前返回失败了---${error.message}")

            }
        }
    }
}
