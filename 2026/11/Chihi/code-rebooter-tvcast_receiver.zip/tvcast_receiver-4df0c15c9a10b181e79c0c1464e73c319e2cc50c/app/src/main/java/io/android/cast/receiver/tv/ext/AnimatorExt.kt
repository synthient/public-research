package io.android.cast.receiver.tv.ext

import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.LayerDrawable
import android.view.View
import android.view.animation.DecelerateInterpolator

/**
 * 扩展函数：为View添加缩放动画
 * @param scale 目标缩放比例
 */
fun View.scaleAnimation(hasFocus: Boolean, scale: Float = 1.15f,animDuration:Long = 300) {
    // 根据焦点状态选择缩放比例
    val targetScale = if (hasFocus) scale else 1.0f

    // 创建X轴和Y轴缩放动画
    val scaleX = ObjectAnimator.ofFloat(this, View.SCALE_X, targetScale)
    val scaleY = ObjectAnimator.ofFloat(this, View.SCALE_Y, targetScale)

    // 使用AnimatorSet组合动画
    AnimatorSet().apply {
        playTogether(scaleX, scaleY)
        duration = animDuration
        start()
    }
}


 fun View.animateTitle( hasFocus: Boolean,scale: Float = 1.8f) {

    val animatorSet = AnimatorSet()
    val scale = if (hasFocus) scale else 1.0f // 放大1.8倍或恢复
    val translationX = 0f
    val translationY = if (hasFocus) -15f else 0f // 向上平移15像素或恢复，增加与HorizontalGridView的间距

    // 设置缩放锚点为左侧
    this.pivotX = 0f // 固定左侧对齐


    val scaleX = ObjectAnimator.ofFloat(this, "scaleX", scale)
    val scaleY = ObjectAnimator.ofFloat(this, "scaleY", scale)
    val translateX = ObjectAnimator.ofFloat(this, "translationX", translationX)
    val translateY = ObjectAnimator.ofFloat(this, "translationY", translationY)

    animatorSet.duration = 400 // 动画时长400ms
    animatorSet.interpolator = DecelerateInterpolator() // 减速插值器
    animatorSet.play(scaleX).with(scaleY).with(translateX).with(translateY)
    animatorSet.start()
}




