package io.android.cast.receiver.tv.ui.view

class MirrorReceiver(
    private var surfaceView: VideoSurfaceView? = null
) {


    private var videoPlayer: MirrorVideoPlayer? = null
    private var audioPlayer: MirrorAudioPlayer? = null

    fun createPlayer() {
        videoPlayer = MirrorVideoPlayer()
        audioPlayer = MirrorAudioPlayer()
    }

    private fun bindSurfaceView(surfaceView: VideoSurfaceView) {
        this.surfaceView = surfaceView
        videoPlayer?.bindSurfaceView(surfaceView)
        audioPlayer?.start() // 音频在绑定 SurfaceView 时启动
        //println("MirrorReceiver bound SurfaceView: $surfaceView")
    }

    fun unbindSurfaceView() {
        videoPlayer?.unbindSurfaceView()
        audioPlayer?.stop()
        surfaceView = null
        //println("MirrorReceiver unbound SurfaceView")
    }

    fun start(surfaceView: VideoSurfaceView) {
        bindSurfaceView(surfaceView)
    }

    fun onVideo(h264: ByteArray) {
        videoPlayer?.feedVideo(h264)
    }

    fun onAudio(aac: ByteArray) {
        audioPlayer?.write(aac)
    }

    fun release() {
        videoPlayer?.release()
        audioPlayer?.release()
        unbindSurfaceView()
        videoPlayer = null
        audioPlayer = null
        //println("MirrorReceiver released")
    }
}