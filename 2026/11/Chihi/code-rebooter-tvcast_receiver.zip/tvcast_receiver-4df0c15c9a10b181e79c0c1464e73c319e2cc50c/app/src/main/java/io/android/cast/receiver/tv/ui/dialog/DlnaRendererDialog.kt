package io.android.cast.receiver.tv.ui.dialog

import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.view.WindowManager
import androidx.annotation.OptIn
import androidx.lifecycle.MutableLiveData
import androidx.media3.common.util.UnstableApi
import io.android.cast.receiver.tv.databinding.DialogDlnaRendererBinding
import io.android.cast.receiver.tv.ui.dialog.base.BaseDialogFragment

class DlnaRendererDialog : BaseDialogFragment<DialogDlnaRendererBinding>(){

    val videoUrlDate = MutableLiveData<String>()

    override val dialogGravity: Int = Gravity.CENTER
    override val dialogWidth: Int = ViewGroup.LayoutParams.MATCH_PARENT
    override val dialogHeight: Int = ViewGroup.LayoutParams.MATCH_PARENT


    @OptIn(UnstableApi::class)
    override fun initView(savedInstanceState: Bundle?) {
        // TV 优化：屏幕常亮
        requireActivity().window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        binding.videoPlayerView.start()
        initObServer()
    }


    @OptIn(UnstableApi::class)
    private fun initObServer() {
        videoUrlDate.observe(viewLifecycleOwner){
            binding.videoPlayerView.playUrl(it)
        }

    }

    @OptIn(UnstableApi::class)
    override fun onDestroyView() {
        binding.videoPlayerView.release()
        requireActivity().window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        super.onDestroyView()
    }

}