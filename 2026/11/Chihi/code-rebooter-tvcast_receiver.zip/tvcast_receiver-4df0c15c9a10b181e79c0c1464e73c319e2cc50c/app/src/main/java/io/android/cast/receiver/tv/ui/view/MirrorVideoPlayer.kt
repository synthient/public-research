package io.android.cast.receiver.tv.ui.view

import android.media.MediaCodec
import android.media.MediaFormat
import android.view.SurfaceHolder
import java.nio.ByteBuffer
import java.util.concurrent.*

class MirrorVideoPlayer {
    private var codec: MediaCodec? = null
    private val queue = LinkedBlockingDeque<ByteArray>() // 限制队列大小，防止内存溢出
    private val executor: ExecutorService = Executors.newSingleThreadExecutor()
    private var isRunning = false
    private var surfaceView: VideoSurfaceView? = null
    var isSurfaceReady = false

    // 绑定 SurfaceView
    fun bindSurfaceView(surfaceView: VideoSurfaceView) {
        this.surfaceView = surfaceView
        isSurfaceReady = true
        startCodec(surfaceView.holder)
        start() // Surface 准备好后启动解码
    }

    // 解绑 SurfaceView，防止内存泄漏
    fun unbindSurfaceView() {
        //surfaceView?.holder?.removeCallback(this)
        surfaceView = null
        if (isSurfaceReady) {
            release()
        }
    }

    // 接收视频数据，存入队列
    fun feedVideo(data: ByteArray) {
        if (data.isEmpty()) return
        // 队列满时丢弃旧帧，保证实时性
        if (!queue.offer(data.copyOf())) {
            queue.poll() // 丢弃最旧一帧
            queue.offer(data.copyOf())
        }

    }

    // 启动解码（由 surfaceCreated 或手动调用）
     fun start() {
        if (isRunning || !isSurfaceReady) return
        isRunning = true
        executor.execute(::decodeLoop)
    }

    // 释放资源
    fun release() {
        isRunning = false

        // 1. 停止解码线程
        executor.shutdownNow()
        try {
            if (!executor.awaitTermination(3, TimeUnit.SECONDS)) {
                //println("解码线程强制终止")
            }
        } catch (e: InterruptedException) {
            Thread.currentThread().interrupt()
        }

        // 2. 释放 MediaCodec
        stopCodec()

        // 3. 清空队列
        synchronized(queue) {
            queue.clear()
        }
    }

    // ====================== SurfaceHolder.Callback ======================

    /* override fun surfaceCreated(holder: SurfaceHolder) {
         println("surface创建完成")
         isSurfaceReady = true
         startCodec(holder)
         start() // Surface 准备好后启动解码
     }

     override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {}

     override fun surfaceDestroyed(holder: SurfaceHolder) {
         isSurfaceReady = false
         release()
     }*/

    // ====================== MediaCodec ======================

    private fun startCodec(holder: SurfaceHolder) {
        try {
            codec = MediaCodec.createDecoderByType("video/avc")
            val format = MediaFormat.createVideoFormat("video/avc", 1280, 720)
            format.setInteger(MediaFormat.KEY_COLOR_FORMAT, 0x7F000789)
            codec?.configure(format, holder.surface, null, 0)
            codec?.start()
            //println("MediaCodec 启动成功")
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun stopCodec() {
        try {
            codec?.stop()
        } catch (e: Exception) {
        }
        try {
            codec?.release()
        } catch (e: Exception) {
        }
        codec = null
    }

    // ====================== 解码循环 ======================

    private fun decodeLoop() {
        while (isRunning && !Thread.currentThread().isInterrupted) {
            try {
                val data = synchronized(queue) { queue.take() } // 阻塞等待
                onFrame(data)
            } catch (e: InterruptedException) {
                //println("线程中断--${e.message}")
                Thread.currentThread().interrupt()
                break
            } catch (e: Exception) {
                //println("线程异常--${e.message}")
                e.printStackTrace()
            }
        }
    }

    private fun onFrame(buf: ByteArray) {
        val codec = this.codec ?: return
        // 输入
        val inputIndex = codec.dequeueInputBuffer(-1)
        if (inputIndex >= 0) {
            val buffer: ByteBuffer = codec.getInputBuffer(inputIndex) ?: return
            buffer.clear()
            buffer.put(buf)
            codec.queueInputBuffer(inputIndex, 0, buf.size, 0, 0)
        }

        // 输出
        val info = MediaCodec.BufferInfo()
        var outputIndex = codec.dequeueOutputBuffer(info, 0)
        while (outputIndex >= 0) {
            val shouldRender = info.size != 0
            codec.releaseOutputBuffer(outputIndex, shouldRender)
            outputIndex = codec.dequeueOutputBuffer(info, 0)
        }

        // 监听格式变化
        if (outputIndex == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
            val format = codec.outputFormat
            val w = format.getInteger(MediaFormat.KEY_WIDTH)
            val h = format.getInteger(MediaFormat.KEY_HEIGHT)
            surfaceView?.post {
                surfaceView?.setVideoSize(w, h)
            }
        }
    }
}