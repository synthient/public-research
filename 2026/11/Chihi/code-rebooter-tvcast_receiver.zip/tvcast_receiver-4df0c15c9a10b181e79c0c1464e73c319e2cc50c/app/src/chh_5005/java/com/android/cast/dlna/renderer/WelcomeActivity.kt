package com.android.cast.dlna.renderer

import io.android.cast.receiver.tv.MainActivity
import io.android.cast.receiver.tv.databinding.ActivityCommonEmtBinding
import io.android.code.lib_base.base.BaseVMActivity
import io.android.code.lib_base.base.BaseViewModel
import io.android.code.lib_base.ext.startKtxActivity

class WelcomeActivity : BaseVMActivity<ActivityCommonEmtBinding, BaseViewModel>() {
    override fun initView() {
        startKtxActivity<MainActivity>()
        finish()
    }
}