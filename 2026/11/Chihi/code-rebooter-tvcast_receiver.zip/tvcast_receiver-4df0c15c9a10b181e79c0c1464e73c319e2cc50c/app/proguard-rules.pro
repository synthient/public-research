# Add project specific ProGuard rules here.
# You can control the set of applied configuration files using the
# proguardFiles setting in build.gradle.
#
# For more details, see
#   http://developer.android.com/guide/developing/tools/proguard.html

# If your project uses WebView with JS, uncomment the following
# and specify the fully qualified class name to the JavaScript interface
# class:
#-keepclassmembers class fqcn.of.javascript.interface.for.webview {
#   public *;
#}

# Uncomment this to preserve the line number information for
# debugging stack traces.
#-keepattributes SourceFile,LineNumberTable

# If you keep the line number information, uncomment this to
# hide the original source file name.
#-renamesourcefileattribute SourceFile

# Viewbinding 如果用的反射就会有混淆问题，需要加入混淆
-keep class * implements androidx.viewbinding.ViewBinding {
    *;
}

# ========== ShapeView ==========
-keep class com.hjq.shape.** {*;}

# ========== AgentWeb ==========
-keep class com.just.agentweb.** { *; }
-dontwarn com.just.agentweb.**

# 保护BaseVMActivity及其子类的泛型信息
-keep class * extends io.android.code.lib_base.base.BaseVMActivity {
    <fields>;
    <methods>;
}
-keep class * extends io.android.code.lib_base.base.BaseActivity {
    <fields>;
    <methods>;
}
-keep class * extends io.android.code.lib_base.base.BaseVMFragment {
    <fields>;
    <methods>;
}
-keep class * extends io.android.code.lib_base.base.BaseFragment {
    <fields>;
    <methods>;
}


-keep class com.speed.bean.** { *; }
-keep class com.speed.ad.bean.** { *; }
-keep class com.speed.net.ApiResponse { *; }



# 保留 javax.enterprise 相关类（CDI 相关）
-keep class javax.enterprise.context.** { *; }
-keep class javax.enterprise.inject.** { *; }
-keep class javax.inject.** { *; }

# 保留 Log4j 相关类
-keep class org.apache.log4j.** { *; }
-dontwarn org.apache.log4j.**

# 保留 Log4j2 相关类
-keep class org.apache.logging.log4j.** { *; }
-dontwarn org.apache.logging.log4j.**

# 保留 JUnit API 相关类
-keep class org.apiguardian.api.** { *; }
-dontwarn org.apiguardian.api.**

# 保留 SLF4J 相关类
-keep class org.slf4j.** { *; }
-dontwarn org.slf4j.**

# 保留 Reactor BlockHound 相关类
-keep class reactor.blockhound.** { *; }
-dontwarn reactor.blockhound.**

# 保留 sun.security.x509 相关类
-keep class sun.security.x509.** { *; }
-dontwarn sun.security.x509.**


# 忽略 java.awt 相关的类（因为 Android 不支持）
-dontwarn java.awt.**
-keep class java.awt.** { *; }

# 忽略 javax.swing 相关的类（因为 Android 不支持）
-dontwarn javax.swing.**
-keep class javax.swing.** { *; }

# 忽略 org.seamless.swing 相关的类（可能来自 Cling 调试工具）
-dontwarn org.seamless.swing.**
-keep class org.seamless.swing.** { *; }


############################################################
## 🧩 Netty (io.netty)
############################################################
-keep class io.netty.** { *; }
-dontwarn io.netty.**

############################################################
## 🌐 Jetty (org.eclipse.jetty)
############################################################
-keep class org.eclipse.jetty.** { *; }
-dontwarn org.eclipse.jetty.**
-keepclassmembers class org.eclipse.jetty.** { *; }

############################################################
## 📡 Cling DLNA (org.fourthline.cling)
############################################################
-keep class org.fourthline.cling.** { *; }
-dontwarn org.fourthline.cling.**
-keepclassmembers class org.fourthline.cling.** { *; }

############################################################
## 🎵 ExoPlayer
############################################################
-keep class com.google.android.exoplayer2.** { *; }
-dontwarn com.google.android.exoplayer2.**
-keep class androidx.media3.** { *; }
-dontwarn androidx.media3.**

############################################################
## 🧬 Curve25519 + EdDSA (加密算法)
############################################################
-keep class org.whispersystems.curve25519.** { *; }
-dontwarn org.whispersystems.curve25519.**

-keep class net.i2p.crypto.eddsa.** { *; }
-dontwarn net.i2p.crypto.eddsa.**

############################################################
## 🍎 dd-plist (Apple Property List)
############################################################
-keep class com.dd.plist.** { *; }
-dontwarn com.dd.plist.**

############################################################
## 🌍 JmDNS (Bonjour / AirPlay 设备发现)
############################################################
-keep class javax.jmdns.** { *; }
-keep class org.jmdns.** { *; }
-dontwarn javax.jmdns.**
-dontwarn org.jmdns.**

############################################################
## 🧠 Javax Servlet API
############################################################
-keep class javax.servlet.** { *; }
-dontwarn javax.servlet.**


# 保留你自定义的 DLNA 服务类（路径已按你给的类修改）
-keep class io.android.code.lib_cast.dlna.** { *; }
-keep class io.android.cast.receiver.tv.bean.** { *; }

