import test_assets.prepare as prepare
import time
import sys
from datetime import datetime
from deploy import DeployService

prepare.exec(clean=False)

if __name__ == "__main__":

    print(f"{sys.argv}")

    formatted_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    print("当前时间:", formatted_time)
    DeployService("./test_assets/server/a0-x_device.yaml", prepare.OverrideFilePath)
